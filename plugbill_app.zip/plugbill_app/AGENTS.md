# Instructions for AI assistants working on this project
Read SIGNING.md first and obey it. In short: do not touch the keystore, alias, passwords, EXPECTED_SHA256.txt or applicationId;
keep the GitHub workflow that unzips plugbill_app.zip, builds with Gradle 8.11.1 / JDK 17, and verifies the signature;
deliver changes as an updated plugbill_app.zip with one top-level folder.

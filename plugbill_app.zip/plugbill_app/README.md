# PlugBill (Android)

Native Kotlin + Jetpack Compose app. Backend: the PlugBill PHP API (see data/ApiConfig.kt for the base URL).

- applicationId `com.plugbill.linexware.app`, targetSdk 36 (Google Play requirement), minSdk 24 (Android 7.0).
- Signing and cloud build: read SIGNING.md and KEYSTORE-DETAILS.txt.
- Play Store checklist and what was fixed: PLAY-STORE.md.

package com.example.walletapp.data

/** Kotlin port of formatNaturalErrorMessage() in the web app's api.ts (same wording). */
object ErrorText {
    const val NO_NETWORK = "Unable to reach the server. Please check your internet connection and try again."

    fun format(raw: String?, status: Int? = null): String {
        if (raw == null || raw.trim().isEmpty()) {
            if (status == 401) return "Your session has expired. Please sign in again."
            if (status == 403) return "You do not have permission to perform this action."
            if (status == 404) return "The requested service is temporarily unavailable. Please try again."
            if (status != null && status >= 500) return "Our servers are experiencing a momentary delay. Please try again shortly."
            return "Something went wrong while processing your request. Please try again."
        }
        val trimmed = raw.trim()
        val lower = trimmed.lowercase()
        val crash = listOf(
            "pdoexception", "sqlstate", "syntaxerror", "unexpected token", "is not valid json", "valid json", "<br", "<html",
            "<!doctype", "500 internal", "fatal error", "call to undefined", "stack trace", "uncaught exception", "econnrefused",
            "cannot read properties", "undefined is not", "null pointer"
        ).any { lower.contains(it) } || trimmed.startsWith("<")
        if (crash) {
            if (status == 401 || lower.contains("unauthorized") || lower.contains("token") || lower.contains("expired"))
                return "Your session has expired. Please sign in again."
            if (lower.contains("network") || lower.contains("fetch") || lower.contains("connect") || lower.contains("timeout"))
                return NO_NETWORK
            return "We encountered a momentary delay while processing your request. Please try again in a moment."
        }
        if (lower in setOf("error", "unknown error", "an error occurred", "server error", "network error", "invalid server response"))
            return "Something went wrong while completing your request. Please try again."
        return trimmed.replaceFirstChar { it.uppercaseChar() }
    }
}

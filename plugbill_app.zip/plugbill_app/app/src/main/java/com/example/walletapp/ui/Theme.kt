package com.example.walletapp.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import com.example.walletapp.R
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object AppColors {
    /** PlugBill green, sampled from the app logo (#00B875). */
    val Accent = Color(0xFF00B875)
    val GreenLight = Color(0xFF2ED39A)
    val GreenDeep = Color(0xFF008F5A)
    val ArrowUp = Color(0xFFEF4444)      // debit
    val ArrowDown = Color(0xFF00B875)    // credit
}

@Immutable
class Palette(
    val dark: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val text: Color,
    val textSecondary: Color,
    val textLight: Color,
    val divider: Color,
    val bar: Color,
    val shadow: Color,
    val highlight: Color
)

val LightPalette = Palette(
    false, Color(0xFFF4F4F4), Color(0xFFE9E9E9), Color.White, Color(0xFF1C1C1E), Color(0xFF9A9A9A),
    Color(0xFFC4C4C4), Color(0xFFD6D6D6), Color(0xFFFAFAFA), Color(0x1F000000), Color(0xE6FFFFFF)
)
val DarkPalette = Palette(
    true, Color(0xFF2A2B38), Color(0xFF1A1B24), Color(0xFF2B2C39), Color(0xFFF2F2F5), Color(0xFF9A9CAB),
    Color(0xFF6E7080), Color(0xFF3A3B4A), Color(0xFF262733), Color(0x66000000), Color(0x12FFFFFF)
)
val LocalPalette = staticCompositionLocalOf { LightPalette }

@Composable
@ReadOnlyComposable
fun pal(): Palette = LocalPalette.current

/** Outfit, used for every piece of text in the app (files live in res/font). */
val AppFont: FontFamily = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_medium, FontWeight.Medium),
    Font(R.font.outfit_semibold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold)
)

@Composable
fun screenBackground(): Brush {
    val p = pal()
    return Brush.verticalGradient(listOf(p.bgTop, p.bgBottom))
}

/** One design unit: (min(screenWidth, 430dp) / 360). */
val LocalU = compositionLocalOf { 1.dp }

@Composable
@ReadOnlyComposable
fun Number.u(): Dp = LocalU.current * this.toFloat()

@Composable
@ReadOnlyComposable
fun Number.usp(): TextUnit = (LocalU.current.value * this.toFloat()).sp

@Composable
fun T(
    text: String,
    size: Float,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    spacing: Float = 0f,
    maxLines: Int = Int.MAX_VALUE,
    underline: Boolean = false,
    lineHeight: Float? = null
) {
    val c = if (color == Color.Unspecified) pal().text else color
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = c,
            fontSize = size.usp(),
            fontWeight = weight,
            fontFamily = AppFont,
            textAlign = align ?: TextAlign.Unspecified,
            letterSpacing = spacing.sp,
            textDecoration = if (underline) TextDecoration.Underline else null,
            lineHeight = lineHeight?.usp() ?: TextUnit.Unspecified
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

/** Press animation: scale to [scaleTo] while pressed. */
fun Modifier.pressable(scaleTo: Float = 0.96f, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) scaleTo else 1f, tween(90), label = "press")
    this
        .graphicsLayer {
            scaleX = s
            scaleY = s
        }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

/** Blurred shadow that follows any [Shape] (also custom path shapes). */
fun Modifier.softShadow(shape: Shape, shadowColor: Color, blur: Dp, dx: Dp, dy: Dp): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    val androidPath = when (outline) {
        is Outline.Rectangle -> android.graphics.Path().apply { addRect(outline.rect.left, outline.rect.top, outline.rect.right, outline.rect.bottom, android.graphics.Path.Direction.CW) }
        is Outline.Rounded -> android.graphics.Path().apply {
            val r = outline.roundRect
            addRoundRect(
                r.left, r.top, r.right, r.bottom,
                floatArrayOf(
                    r.topLeftCornerRadius.x, r.topLeftCornerRadius.y,
                    r.topRightCornerRadius.x, r.topRightCornerRadius.y,
                    r.bottomRightCornerRadius.x, r.bottomRightCornerRadius.y,
                    r.bottomLeftCornerRadius.x, r.bottomLeftCornerRadius.y
                ),
                android.graphics.Path.Direction.CW
            )
        }
        is Outline.Generic -> outline.path.asAndroidPath()
    }
    drawIntoCanvas { canvas ->
        val androidPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.TRANSPARENT
            setShadowLayer(blur.toPx(), dx.toPx(), dy.toPx(), shadowColor.toArgb())
        }
        canvas.nativeCanvas.drawPath(androidPath, androidPaint)
    }
}

/** White floating neumorphic surface (gray drop shadow + white highlight shadow). */
@Composable
fun FloatSurface(
    modifier: Modifier,
    shape: Shape,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val base = if (onClick != null) modifier.pressable(onClick = onClick) else modifier
    Box(
        modifier = base
            .softShadow(shape, pal().shadow, 14.u(), 0.dp, 6.u())
            .softShadow(shape, pal().highlight, 10.u(), (-4).u(), (-4).u())
            .background(pal().surface, shape),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** Scales an SVG path (given in a vw x vh viewBox) to the size of the shape. */
class SvgPathShape(private val d: String, private val vw: Float, private val vh: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = PathParser().parsePathString(d).toPath()
        path.transform(Matrix().apply { scale(size.width / vw, size.height / vh) })
        return Outline.Generic(path)
    }
}

/** Bottom bar: 72 design-units tall, any width, circular scoop (r=38, centre 6 below top edge) in the middle. */
class BarShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val s = size.height / 72f
        val w = size.width / s
        val cx = w / 2f
        val d = "M28 0 H${cx - 37.5f} A38 38 0 1 0 ${cx + 37.5f} 0 H${w - 28f} " +
            "Q$w 0 $w 28 V44 Q$w 72 ${w - 28f} 72 H28 Q0 72 0 44 V28 Q0 0 28 0 Z"
        val path = PathParser().parsePathString(d).toPath()
        path.transform(Matrix().apply { scale(s, s) })
        return Outline.Generic(path)
    }
}

const val CARD_PATH =
    "M34 0 H95.6 A41 41 0 0 0 176.4 0 H238 Q258 0 260 20 L271 127 Q272 155 244 155 H28 Q0 155 1 127 L12 20 Q14 0 34 0 Z"

/** One segment of a 24x24 icon. */
data class Seg(val d: String, val fill: Boolean = false, val color: Color? = null, val width: Float? = null)

fun icon(vararg d: String): List<Seg> = d.map { Seg(it) }

fun rr(x: Float, y: Float, w: Float, h: Float, r: Float): String =
    "M${x + r} ${y}H${x + w - r}A$r $r 0 0 1 ${x + w} ${y + r}V${y + h - r}A$r $r 0 0 1 ${x + w - r} ${y + h}" +
        "H${x + r}A$r $r 0 0 1 $x ${y + h - r}V${y + r}A$r $r 0 0 1 ${x + r} ${y}Z"

@Composable
fun SvgIcon(segs: List<Seg>, dp: Dp, color: Color, stroke: Float = 2f, modifier: Modifier = Modifier) {
    val parsed = remember(segs) { segs.map { PathParser().parsePathString(it.d).toPath() } }
    Canvas(modifier.size(dp)) {
        val s = this.size.width / 24f
        scale(s, s, pivot = Offset.Zero) {
            segs.forEachIndexed { i, seg ->
                val c = seg.color ?: color
                if (seg.fill) {
                    drawPath(parsed[i], c)
                } else {
                    drawPath(
                        parsed[i], c,
                        style = Stroke(width = seg.width ?: stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
        }
    }
}

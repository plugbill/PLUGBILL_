package com.example.walletapp.ui

import kotlinx.coroutines.launch
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

sealed interface Overlay {
    data object None : Overlay
    data object Menu : Overlay
    data object Logout : Overlay
    data object Delete : Overlay
}

private data class MenuTile(val label: String, val icon: List<Seg>, val service: ServiceType?, val soon: Boolean = false)

private val menuTiles = listOf(
    MenuTile("Airtime", AppIcons.Airtime, ServiceType.Airtime),
    MenuTile("Data", AppIcons.Data, ServiceType.Data),
    MenuTile("Electricity", AppIcons.Electricity, ServiceType.Electricity),
    MenuTile("TV", AppIcons.Tv, ServiceType.Tv),
    MenuTile("Flights", AppIcons.Flight, null, soon = true),
    MenuTile("Education", AppIcons.Education, null, soon = true)
)

@Composable
fun MainShell(
    tab: Tab,
    onTab: (Tab) -> Unit,
    dark: Boolean,
    onDark: (Boolean) -> Unit,
    onFund: () -> Unit,
    onHistory: () -> Unit,
    onNotifications: () -> Unit,
    onExpenses: () -> Unit,
    onSecurity: () -> Unit,
    onReferral: () -> Unit,
    onAccount: () -> Unit,
    onSupport: () -> Unit,
    onService: (ServiceType) -> Unit,
    onLock: () -> Unit,
    onLogout: () -> Unit
) {
    val ctx = LocalContext.current
    var overlay by remember { mutableStateOf<Overlay>(Overlay.None) }
    // keep the last overlay so its content survives the exit animation
    var shown by remember { mutableStateOf<Overlay>(Overlay.None) }
    if (overlay !is Overlay.None) shown = overlay
    val menuOpen = overlay is Overlay.Menu
    val sheetOpen = overlay !is Overlay.None && overlay !is Overlay.Menu
    BackHandler(enabled = overlay !is Overlay.None) { overlay = Overlay.None }

    // iOS-style backdrop blur (API 31+; older devices fall back to the darker scrim)
    val blurRadius by animateDpAsState(if (overlay !is Overlay.None && Build.VERSION.SDK_INT >= 31) 24.dp else 0.dp, tween(260), label = "blur")

    Box(Modifier.fillMaxSize().background(screenBackground())) {
        Box(Modifier.fillMaxSize().blur(blurRadius)) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    val toProfile = targetState == Tab.Profile
                    (fadeIn(tween(280, delayMillis = 70)) + slideInHorizontally(tween(320)) { if (toProfile) it / 12 else -it / 12 }) togetherWith
                        (fadeOut(tween(130)) + slideOutHorizontally(tween(240)) { if (toProfile) -it / 12 else it / 12 })
                },
                label = "tabs"
            ) { t ->
                when (t) {
                    Tab.Home -> HomeScreen(onFund = onFund, onHistory = onHistory, onNotifications = onNotifications, onLock = onLock)
                    Tab.Profile -> ProfileScreen(
                        dark = dark, onDark = onDark, onHistory = onHistory, onFund = onFund,
                        onNotifications = onNotifications, onExpenses = onExpenses, onSecurity = onSecurity, onReferral = onReferral,
                        onAccount = onAccount, onSupport = onSupport, onLogout = { overlay = Overlay.Logout }
                    )
                }
            }
        }

        // scrim for the pop-up menu
        AnimatedVisibility(menuOpen, enter = fadeIn(tween(220)), exit = fadeOut(tween(200))) {
            Box(
                Modifier.fillMaxSize()
                    .background(Color(if (dark) 0x99000000 else 0x4D000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { overlay = Overlay.None }
            )
        }

        // ── glass pop-up with the arrow pointing at the centre button ──
        Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 122.u())) {
            AnimatedVisibility(
                visible = menuOpen,
                enter = scaleIn(spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.4f, transformOrigin = TransformOrigin(0.5f, 1f)) +
                    fadeIn(tween(180)) + slideInVertically(spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow)) { it / 5 },
                exit = scaleOut(tween(170), targetScale = 0.5f, transformOrigin = TransformOrigin(0.5f, 1f)) + fadeOut(tween(140)) +
                    slideOutVertically(tween(170)) { it / 6 }
            ) {
                val cr = 30.u(); val aw = 26.u(); val ah = 13.u()
                val bubble = remember(cr, aw, ah) { BubbleShape(cr, aw, ah) }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Zara, the AI agent: its own glass card floating above the quick-pay card
                ZaraCard(Modifier.width(318.u())) {
                    overlay = Overlay.None
                    com.example.walletapp.ZaraActivity.open(ctx)
                }
                Spacer(Modifier.height(12.u()))
                Column(
                    Modifier
                        .width(318.u())
                        .glass(bubble)
                        .then(noRipple)
                        .padding(start = 16.u(), end = 16.u(), top = 18.u(), bottom = 13.u() + 18.u())
                ) {
                    T("Quick pay", 12.5f, FontWeight.SemiBold, pal().textSecondary, Modifier.padding(start = 6.u(), bottom = 12.u()))
                    menuTiles.chunked(3).forEachIndexed { r, row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.u())) {
                            row.forEach { tile ->
                                MenuTileView(tile, Modifier.weight(1f)) {
                                    val s = tile.service
                                    if (s != null) { overlay = Overlay.None; onService(s) }
                                    else AppToast.info("${tile.label} is coming soon")
                                }
                            }
                        }
                        if (r == 0) Spacer(Modifier.height(10.u()))
                    }
                }
                }
            }
        }

        // navigation bar slides away while a bottom sheet is open and pops back on the dashboard
        AnimatedVisibility(
            visible = !sheetOpen,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(220)),
            exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(180))
        ) {
            BottomBar(
                modifier = Modifier,
                tab = tab,
                open = menuOpen,
                onTab = { overlay = Overlay.None; onTab(it) },
                onCenter = { overlay = if (menuOpen) Overlay.None else Overlay.Menu }
            )
        }

        // ── the only bottom sheet left on the dashboard: the log-out confirmation ──
        GlassSheet(visible = sheetOpen, onDismiss = { overlay = Overlay.None }) {
            if (shown is Overlay.Logout) LogoutContent(onCancel = { overlay = Overlay.None }, onConfirm = { overlay = Overlay.None; onLogout() })
        }
    }
}

private val ZaraArrow = icon("M5 12h14", "M13 6l6 6-6 6")

/** Zara (AI bill assistant) card: rounded-square photo, name, tagline and one plain arrow. Opens the chat later. */
@Composable
private fun ZaraCard(modifier: Modifier, onClick: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(26.u())
    Row(
        modifier.glass(shape).then(noRipple).pressable(0.97f, onClick).padding(horizontal = 14.u(), vertical = 14.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // the photo sits inside the same tile card style as Airtime / Data / Electricity
        val tile = RoundedCornerShape(20.u())
        Box(
            Modifier.size(88.u())
                .background(if (p.dark) Color(0x22FFFFFF) else Color(0x80FFFFFF), tile)
                .border(1.dp, if (p.dark) Color(0x22FFFFFF) else Color(0xCCFFFFFF), tile)
                .padding(4.u()),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(com.example.walletapp.R.drawable.zara_avatar),
                contentDescription = "Zara",
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(15.u()))
            )
        }
        Spacer(Modifier.width(14.u()))
        Column(Modifier.weight(1f)) {
            T("Zara", 24f, FontWeight.Bold)
            Spacer(Modifier.height(2.u()))
            T("Your personal bill management AI", 13f, FontWeight.Normal, p.textSecondary, lineHeight = 17f)
        }
        Spacer(Modifier.width(8.u()))
        // arrow sits in its own small round glass bubble so it reads as the thing to tap
        Box(
            Modifier.size(40.u())
                .background(AppColors.Accent.copy(alpha = if (p.dark) 0.22f else 0.16f), CircleShape)
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (p.dark) 0.30f else 0.90f), Color.White.copy(alpha = 0.06f))), CircleShape),
            contentAlignment = Alignment.Center
        ) { SvgIcon(ZaraArrow, 20.u(), AppColors.Accent, 2.2f) }
    }
}

@Composable
private fun MenuTileView(tile: MenuTile, modifier: Modifier, onClick: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(18.u())
    Column(
        modifier
            .pressable(0.94f, onClick)
            .background(if (p.dark) Color(0x22FFFFFF) else Color(0x80FFFFFF), shape)
            .border(1.dp, if (p.dark) Color(0x22FFFFFF) else Color(0xCCFFFFFF), shape)
            .padding(vertical = 14.u()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.graphicsLayer { alpha = if (tile.soon) 0.55f else 1f }) { GreenIcon(tile.icon, 44, 23) }
        Spacer(Modifier.height(8.u()))
        T(tile.label, 12f, FontWeight.SemiBold, if (tile.soon) p.textSecondary else p.text, maxLines = 1)
        if (tile.soon) T("Soon", 9.5f, FontWeight.Medium, AppColors.Accent)
        else Spacer(Modifier.height(11.u()))
    }
}

@Composable
private fun BottomBar(modifier: Modifier, tab: Tab, open: Boolean, onTab: (Tab) -> Unit, onCenter: () -> Unit) {
    val p = pal()
    val barShape = remember { BarShape() }
    val rot by animateFloatAsState(if (open) 90f else 0f, tween(260), label = "rot")

    Box(
        modifier
            .navigationBarsPadding()
            .padding(start = 21.u(), end = 21.u(), bottom = 16.u())
            .fillMaxWidth()
            .height(72.u())
    ) {
        Box(
            Modifier.fillMaxSize()
                .softShadow(barShape, if (p.dark) Color(0x66000000) else Color(0x1A000000), 24.u(), 0.dp, 8.u())
                .background(p.bar, barShape)
                .then(noRipple) // swallows taps on the bar itself so they never reach what is behind it
        )
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.weight(0.38f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                BarTab("Home", AppIcons.Home, tab == Tab.Home) { onTab(Tab.Home) }
            }
            Spacer(Modifier.weight(0.24f))
            Box(Modifier.weight(0.38f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                BarTab("Profile", AppIcons.Profile, tab == Tab.Profile) { onTab(Tab.Profile) }
            }
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-32).u()).size(74.u())
                .border(2.u(), if (p.dark) Color(0x1AFFFFFF) else Color(0xCCFFFFFF), CircleShape)
        )
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-28).u())
                .size(66.u())
                .pressable(onClick = onCenter)
                .softShadow(CircleShape, AppColors.Accent.copy(alpha = 0.40f), 18.u(), 0.dp, 10.u())
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(AppColors.GreenDeep, AppColors.GreenLight),
                        start = Offset(0f, Float.POSITIVE_INFINITY), end = Offset(Float.POSITIVE_INFINITY, 0f)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(
                    Brush.radialGradient(listOf(Color(0x4DFFFFFF), Color.Transparent), center = Offset(size.width * 0.7f, size.height * 0.75f), radius = size.width * 0.5f),
                    radius = size.width * 0.5f
                )
            }
            Box(Modifier.graphicsLayer { rotationZ = rot }) {
                Crossfade(targetState = open, animationSpec = tween(220), label = "centerIcon") { o ->
                    SvgIcon(if (o) AppIcons.Close else AppIcons.Bills, 26.u(), Color.White, 2.2f)
                }
            }
        }
    }
}

@Composable
private fun BarTab(label: String, icon: List<Seg>, active: Boolean, onClick: () -> Unit) {
    val col = if (active) AppColors.Accent else pal().text
    Column(Modifier.pressable(onClick = onClick).padding(horizontal = 12.u(), vertical = 6.u()), horizontalAlignment = Alignment.CenterHorizontally) {
        SvgIcon(icon, 24.u(), col, 1.8f)
        Spacer(Modifier.height(6.u()))
        T(label, 10f, if (active) FontWeight.SemiBold else FontWeight.Medium, col, maxLines = 1)
    }
}

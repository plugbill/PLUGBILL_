package com.example.walletapp.ui

import androidx.compose.ui.draw.blur
import android.app.Activity
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

enum class Screen { Splash, Welcome, Login, Register, Otp, Forgot, Reset, Success, CreatePasscode, CreatePin, Unlock, Main, Fund, History, Notifications, Expenses, Referral, Security, Profile, Support, Service, Onboarding }
enum class Tab { Home, Profile }

private val TERMS_URL = com.example.walletapp.data.ApiConfig.TERMS_URL
/** Show the "No internet" dialog on the splash screen when the phone is offline (set false to let the app open offline). */
private const val REQUIRE_INTERNET_AT_SPLASH = true
private val PRIVACY_URL = com.example.walletapp.data.ApiConfig.PRIVACY_URL



/** Navigation depth: deeper screens push in from the right, shallower ones pop back out. */
private fun Screen.depth(): Int = when (this) {
    Screen.Splash, Screen.Onboarding, Screen.Welcome, Screen.Unlock, Screen.Main -> 0
    Screen.Login, Screen.Register -> 1
    Screen.Forgot, Screen.Otp -> 2
    Screen.Reset, Screen.Success -> 3
    Screen.CreatePasscode, Screen.CreatePin -> 4
    else -> 1
}

private val NavEasing = androidx.compose.animation.core.CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

/** Theme + responsive unit frame, shared by every activity. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun AppFrame(content: @Composable (dark: Boolean, onDark: (Boolean) -> Unit) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    val system = isSystemInDarkTheme()
    var mode by remember { mutableIntStateOf(prefs.getInt("dark", -1)) } // -1 = follow system
    val dark = if (mode == -1) system else mode == 1
    val palette = if (dark) DarkPalette else LightPalette

    val view = LocalView.current
    SideEffect {
        val window = (ctx as Activity).window
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(
        LocalPalette provides palette,
        androidx.compose.foundation.LocalOverscrollConfiguration provides null
    ) {
        BoxWithConstraints(Modifier.fillMaxSize().background(screenBackground())) {
            val colW = if (maxWidth > 430.dp) 430.dp else maxWidth
            val unit = colW / 360f
            CompositionLocalProvider(LocalU provides unit) {
                val loadBlur by androidx.compose.animation.core.animateDpAsState(
                    if (AppLoading.active && android.os.Build.VERSION.SDK_INT >= 31) 20.dp else 0.dp, tween(220), label = "loadBlur"
                )
                val toastBackdrop = androidx.compose.ui.graphics.rememberGraphicsLayer()
                Box(
                    Modifier.align(Alignment.TopCenter).width(colW).fillMaxHeight().blur(loadBlur)
                        .then(if (android.os.Build.VERSION.SDK_INT >= 31) Modifier.captureInto(toastBackdrop) else Modifier)
                ) {
                    content(dark) {
                        mode = if (it) 1 else 0
                        prefs.edit().putInt("dark", mode).apply()
                    }
                }
                AppGateHost()
                LoadingOverlay()
                Box(Modifier.align(Alignment.TopCenter).width(colW)) { ToastHost(toastBackdrop) }
            }
        }
    }
}

@Composable
fun AppRoot() {
    AppFrame { dark, onDark -> Navigation(dark = dark, onDark = onDark) }
}

@Composable
private fun Navigation(dark: Boolean, onDark: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    remember { Session.load(ctx); com.example.walletapp.services.NotificationStore.load(ctx); 0 }
    var screen by rememberSaveable { mutableStateOf(Screen.Splash) }
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var otpFor by rememberSaveable { mutableStateOf("register") }
    var passFrom by rememberSaveable { mutableStateOf("register") }
    val onboardPrefs = remember { ctx.getSharedPreferences("plugbill_onboarding", android.content.Context.MODE_PRIVATE) }
    var service by rememberSaveable { mutableStateOf(ServiceType.Airtime) }

    BackHandler(enabled = screen !in listOf(Screen.Splash, Screen.Onboarding, Screen.Welcome, Screen.Main, Screen.Unlock, Screen.Success, Screen.CreatePin)) {
        screen = when (screen) {
            Screen.Login, Screen.Register -> Screen.Welcome
            Screen.Forgot, Screen.Reset -> Screen.Login
            Screen.Otp -> when (otpFor) { "reset" -> Screen.Forgot; "register" -> Screen.Register; else -> Screen.Login }
            Screen.CreatePasscode -> if (passFrom == "security") Screen.Security else Screen.Main
            else -> Screen.Main
        }
    }

    // splash -> first real screen (login / onboarding / unlock / dashboard)
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    /** Same decision order as the web App.tsx: maintenance -> no session (onboarding / sign in) -> passcode unlock -> dashboard. */
    suspend fun checkMaintenance() {
        val on = com.example.walletapp.data.SystemAPI.maintenanceMode()
        val was = AppGate.maintenance != null
        if (on == true) AppGate.maintenance = MaintenanceInfo()
        else if (on == false) {
            AppGate.maintenance = null
            if (was && Session.loggedIn) { // web: maintenance just ended -> force a fresh sign-in
                com.example.walletapp.data.AuthFlow.logout(ctx); tab = Tab.Home; screen = Screen.Login
            }
        }
    }
    fun leaveSplash() {
        scope.launch {
            checkMaintenance()
            // opening the app with a saved session: check the account right away so a disabled user is signed out at once
            if (Session.loggedIn && AppGate.maintenance == null && Network.isOnline(ctx)) {
                when (kotlinx.coroutines.withTimeoutOrNull(4000) { com.example.walletapp.data.Sync.refresh(ctx) }) {
                    com.example.walletapp.data.SyncResult.BLOCKED -> {
                        val st = Session.accountStatus
                        com.example.walletapp.data.AuthFlow.logout(ctx)
                        AppGate.showBlocked(st, com.example.walletapp.data.Sync.lastBlockMessage)
                    }
                    com.example.walletapp.data.SyncResult.EXPIRED -> AppToast.warning("Your login session has expired. Please sign in again.")
                    else -> {}
                }
            }
            screen = if (!Session.loggedIn && AppGate.blocked != null) Screen.Login
            else if (!Session.loggedIn) (if (onboardPrefs.getBoolean("seen", false)) Screen.Welcome else Screen.Onboarding)
            else if (Session.passcodeEnabled && Session.hasPasscode) Screen.Unlock else Screen.Main
        }
    }
    LaunchedEffect(Unit) { AppGate.onRetry = { scope.launch { checkMaintenance() } } }
    // live refresh: balance reconcile + history + profile on open, then every 5 s on dashboard / fund / history (as the web does)
    LaunchedEffect(screen, Session.loggedIn) {
        if (Session.loggedIn && (screen == Screen.Main || screen == Screen.Fund || screen == Screen.History)) {
            while (true) {
                when (com.example.walletapp.data.Sync.refresh(ctx)) {
                    com.example.walletapp.data.SyncResult.EXPIRED -> {
                        AppToast.warning("Your login session has expired. Please sign in again.")
                        tab = Tab.Home; screen = Screen.Login; break
                    }
                    com.example.walletapp.data.SyncResult.BLOCKED -> {
                        val st = Session.accountStatus
                        com.example.walletapp.data.AuthFlow.logout(ctx)
                        AppGate.showBlocked(st, com.example.walletapp.data.Sync.lastBlockMessage)
                        tab = Tab.Home; screen = Screen.Login; break
                    }
                    else -> {}
                }
                delay(5000)
            }
        }
    }
    var offline by remember { mutableStateOf(false) }
    var askExit by remember { mutableStateOf(false) }
    // back on the dashboard / welcome page: Profile tab goes to Home first, otherwise ask before leaving the app
    BackHandler(enabled = screen == Screen.Main || screen == Screen.Welcome) {
        if (screen == Screen.Main && tab == Tab.Profile) tab = Tab.Home else askExit = true
    }

    Box(Modifier.fillMaxSize()) {
    AnimatedContent(
        targetState = screen,
        transitionSpec = {
            // every screen change: old screen fades out quickly while sliding a little, new one fades in right after
            val from = initialState.depth(); val to = targetState.depth()
            val enterFade = fadeIn(tween(300, delayMillis = 80, easing = NavEasing))
            val exitFade = fadeOut(tween(140))
            when {
                to > from -> (enterFade + slideInHorizontally(tween(360, easing = NavEasing)) { it / 10 }) togetherWith
                    (exitFade + slideOutHorizontally(tween(260, easing = NavEasing)) { -it / 14 })
                to < from -> (enterFade + slideInHorizontally(tween(360, easing = NavEasing)) { -it / 14 }) togetherWith
                    (exitFade + slideOutHorizontally(tween(260, easing = NavEasing)) { it / 10 })
                else -> (enterFade + scaleIn(tween(320, easing = NavEasing), initialScale = 0.97f)) togetherWith exitFade
            }.apply { targetContentZIndex = if (to >= from) 1f else -1f }
        },
        label = "nav"
    ) { s ->
        when (s) {
            Screen.Splash -> SplashScreen {
                if (REQUIRE_INTERNET_AT_SPLASH && !Network.isOnline(ctx)) offline = true else leaveSplash()
            }
            Screen.Onboarding -> OnboardingScreen(onDone = { onboardPrefs.edit().putBoolean("seen", true).apply(); screen = Screen.Welcome })
            Screen.Welcome -> WelcomeScreen(
                onCreate = { screen = Screen.Register }, onLogin = { screen = Screen.Login },
                onTerms = { openUrl(ctx, TERMS_URL) }, onPrivacy = { openUrl(ctx, PRIVACY_URL) }
            )
            Screen.Login -> LoginScreen(
                onLoggedIn = { needsOtp -> if (needsOtp) { otpFor = "login"; screen = Screen.Otp } else screen = Screen.Main },
                onRegister = { screen = Screen.Register }, onForgot = { screen = Screen.Forgot },
                onBack = { screen = Screen.Welcome }
            )
            Screen.Register -> RegisterScreen(onBack = { screen = Screen.Welcome }, onNext = { screen = Screen.Success }, onLogin = { screen = Screen.Login })
            Screen.Forgot -> ForgotScreen(onBack = { screen = Screen.Login }, onNext = { otpFor = "reset"; screen = Screen.Otp })
            Screen.Otp -> OtpScreen(
                destination = Session.email.ifBlank { "your email" },
                type = if (otpFor == "reset") "password_reset" else "login",
                onBack = { screen = if (otpFor == "reset") Screen.Forgot else if (otpFor == "register") Screen.Register else Screen.Login },
                onVerified = { screen = when (otpFor) { "register" -> Screen.Success; "reset" -> Screen.Reset; else -> Screen.Main } }
            )
            Screen.Reset -> ResetScreen(onBack = { screen = Screen.Login }, onDone = {
                AppToast.success("Password updated. Please sign in.")
                screen = Screen.Login
            })
            Screen.Success -> SuccessScreen("Account created", "Your PlugBill wallet is ready.\nLet's secure it with a passcode.", "Continue") {
                passFrom = "register"; screen = Screen.CreatePin
            }
            Screen.CreatePasscode -> PasscodeScreen(
                mode = "create",
                onBack = if (passFrom == "security") ({ screen = Screen.Security }) else null,
                onSuccess = {
                    screen = if (passFrom == "security") Screen.Security else Screen.Main
                    if (passFrom == "prompt" && Biometrics.available(ctx)) {
                        Biometrics.prompt(ctx, "Enable fingerprint", "Touch the sensor to confirm") { ok ->
                            if (ok) { Session.biometricEnabled = true; Session.save(ctx) }
                        }
                    }
                },
                onSkip = if (passFrom == "prompt") ({ screen = Screen.Main }) else null
            )
            Screen.CreatePin -> PasscodeScreen(mode = "pin", onBack = null, onSuccess = { screen = Screen.Main }, onFail = { screen = Screen.Register })
            Screen.Unlock -> PasscodeScreen(mode = "verify", onBack = null, onSuccess = { screen = Screen.Main })
            Screen.Main -> MainShell(
                tab = tab, onTab = { tab = it }, dark = dark, onDark = onDark,
                onFund = { screen = Screen.Fund }, onHistory = { screen = Screen.History },
                onNotifications = { screen = Screen.Notifications }, onExpenses = { screen = Screen.Expenses },
                onSecurity = { screen = Screen.Security }, onReferral = { screen = Screen.Referral },
                onAccount = { screen = Screen.Profile },
                onSupport = { screen = Screen.Support },
                onService = { service = it; screen = Screen.Service },
                onLock = {
                    if (Session.hasPasscode && Session.passcodeEnabled) screen = Screen.Unlock
                    else { AppToast.warning("Set a passcode first"); screen = Screen.Security }
                },
                onLogout = { scope.launch { com.example.walletapp.data.AuthFlow.logout(ctx) }; tab = Tab.Home; screen = Screen.Login }
            )
            Screen.Profile -> ProfileDetailsScreen(onBack = { screen = Screen.Main })
            Screen.Support -> SupportScreen(onBack = { screen = Screen.Main })
            Screen.Service -> ServiceScreen(
                service = service, onBack = { screen = Screen.Main },
                onReceipt = { tx -> screen = Screen.Main; openReceipt(ctx, tx) }
            )
            Screen.Fund -> FundWalletScreen(onBack = { screen = Screen.Main })
            Screen.History -> HistoryScreen(onBack = { screen = Screen.Main })
            Screen.Notifications -> NotificationsScreen(onBack = { screen = Screen.Main })
            Screen.Expenses -> ExpensesScreen(onBack = { screen = Screen.Main })
            Screen.Referral -> ReferralScreen(onBack = { screen = Screen.Main })
            Screen.Security -> SecurityScreen(onBack = { screen = Screen.Main }, onSetPasscode = { passFrom = "security"; screen = Screen.CreatePasscode })
        }
    }
    AppAlertDialog(
        visible = askExit,
        title = "Exit PlugBill?",
        message = "Are you sure you want to exit the app?",
        icon = AppIcons.Logout, tone = AlertTone.Warning,
        primary = "Stay", onPrimary = { askExit = false },
        secondary = "Exit app", onSecondary = { askExit = false; ctx.closeApp() },
        dismissible = true, onDismiss = { askExit = false }
    )
    ConnectionErrorDialog(
        visible = offline && screen == Screen.Splash,
        onRetry = { if (Network.isOnline(ctx)) { offline = false; leaveSplash() } else AppToast.error("Still no connection. Check your internet and try again.") },
        onClose = { ctx.closeApp() }
    )
    if (screen == Screen.Main && Session.loggedIn && !Session.hasPasscode && !Session.securityPrompted) {
        SecurityPromptDialog(
            onEnable = { Session.securityPrompted = true; Session.save(ctx); passFrom = "prompt"; screen = Screen.CreatePasscode },
            onLater = { Session.securityPrompted = true; Session.save(ctx) }
        )
    }
    }
}

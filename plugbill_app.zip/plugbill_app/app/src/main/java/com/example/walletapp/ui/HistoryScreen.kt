package com.example.walletapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val p = pal()
    val ctx = LocalContext.current
    val lazy = rememberLazyListState()
    val pull = rememberPullUpState()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    FrostedScreen(
        "History", onBack,
        scrollOffset = { lazy.firstVisibleItemIndex * 100000 + lazy.firstVisibleItemScrollOffset }
    ) { top ->
        // 20 transactions at a time: pull the list up at its end to load the next 20 (never the whole history at once)
        Box(
            Modifier.fillMaxSize().pullUpToLoad(pull, enabled = TxStore.hasMore && TxStore.loaded) {
                com.example.walletapp.data.Sync.loadMoreHistory()
            }
        ) {
            LazyColumn(
                Modifier.fillMaxSize().graphicsLayer { translationY = -pull.offset.value },
                state = lazy,
                contentPadding = PaddingValues(start = 21.u(), end = 21.u(), top = top + 6.u(), bottom = 24.u() + navInset),
                verticalArrangement = Arrangement.spacedBy(12.u())
            ) {
                if (!TxStore.loaded && allTx.isEmpty()) {
                    items(8) { TxSkeletonRow() }
                } else if (allTx.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(top = 60.u()), contentAlignment = Alignment.Center) {
                            T("No transactions yet", 13f, FontWeight.Medium, p.textSecondary)
                        }
                    }
                }
                // a plain list: no date headings, each transaction carries its own date and time
                items(allTx) { tx -> HistoryRow(tx) { openReceipt(ctx, tx) } }
                if (allTx.isNotEmpty()) item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 14.u()), contentAlignment = Alignment.Center) {
                        T(
                            if (TxStore.hasMore) "Pull up to load ${TxStore.PAGE_SIZE} more" else "You're all caught up",
                            11f, FontWeight.Medium, p.textSecondary
                        )
                    }
                }
            }
            PullUpFooter(pull, TxStore.PAGE_SIZE, Modifier.align(Alignment.BottomCenter).padding(bottom = navInset))
        }
    }
}

/** "NOV 29 \u2022 11:36" for dated transactions; falls back to the stored text (e.g. "Today"). */
private fun dateLabel(tx: Tx): String {
    val md = try {
        java.time.LocalDate.parse(tx.shortDate, java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy", java.util.Locale.ENGLISH))
            .format(java.time.format.DateTimeFormatter.ofPattern("MMM dd", java.util.Locale.ENGLISH)).uppercase()
    } catch (_: Exception) { tx.shortDate }
    return if (tx.time.isBlank() || tx.time == "now") md else "$md \u2022 ${tx.time}"
}

@Composable
private fun HistoryRow(tx: Tx, onClick: () -> Unit) {
    val p = pal()
    val statusColor = when (tx.status.uppercase()) { "SUCCESSFUL" -> AppColors.Accent; "PENDING" -> Color(0xFFB7791F); else -> AppColors.ArrowUp }
    val statusLabel = when (tx.status.uppercase()) { "SUCCESSFUL" -> "Successful"; "PENDING" -> "Pending"; else -> "Failed" }
    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(20.u()), onClick) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.u(), vertical = 13.u()), verticalAlignment = Alignment.CenterVertically) {
            TxIcon(tx, size = 46, corner = 14)
            Spacer(Modifier.width(12.u()))
            Column(Modifier.weight(1f)) {
                T(tx.title, 12.5f, FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.height(4.u()))
                T(dateLabel(tx), 10f, FontWeight.Medium, p.textSecondary, maxLines = 1)
            }
            Spacer(Modifier.width(8.u()))
            Column(horizontalAlignment = Alignment.End) {
                T(
                    (if (tx.incoming) "+" else "-") + "\u20A6" + tx.amount, 13f, FontWeight.Bold,
                    if (tx.incoming) AppColors.ArrowDown else AppColors.ArrowUp, maxLines = 1
                )
                Spacer(Modifier.height(4.u()))
                T(statusLabel, 10f, FontWeight.SemiBold, statusColor, maxLines = 1)
            }
        }
    }
}

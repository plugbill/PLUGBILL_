package com.example.walletapp.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Mirrors the web ApiResponse. [data] is json.data if present, else the whole body (like normalizeResponse in api.ts). */
class ApiResult(
    val success: Boolean,
    val message: String,
    val data: Any?,
    val statusCode: Int,
    val errors: JSONObject? = null
) {
    val isUnauthorized: Boolean get() = statusCode == 401
    val obj: JSONObject? get() = data as? JSONObject
    val arr: JSONArray? get() = data as? JSONArray
}

/**
 * Port of apiRequest() from the web api.ts: same headers, same JSON normalisation, same HTML-contaminated-JSON recovery,
 * same friendly error wording. Differences (deliberate): no relative-proxy URLs on a phone, and money-moving POSTs are
 * NEVER retried ([idempotent] = false) so a flaky network can't double-charge.
 */
object ApiClient {
    @Volatile var token: String? = null

    suspend fun get(endpoint: String) = request(endpoint, "GET", null, true)
    suspend fun post(endpoint: String, body: JSONObject? = JSONObject(), idempotent: Boolean = true) = request(endpoint, "POST", body, idempotent)
    suspend fun delete(endpoint: String, body: JSONObject?) = request(endpoint, "DELETE", body, true)

    suspend fun request(endpoint: String, method: String, body: JSONObject?, idempotent: Boolean): ApiResult = withContext(Dispatchers.IO) {
        val clean = endpoint.removePrefix("/")
        val route = clean.replace(Regex("\\.php(\\?.*)?$"), "")
        val base = ApiConfig.BASE_URL
        // 1) direct  2) fallback query router (same as web fallbacks 4/5). Only for safe-to-repeat calls.
        val urls = if (idempotent) listOf("$base/$clean", "$base/index.php?route=$route") else listOf("$base/$clean")
        var lastStatus: Int? = null
        var lastText = ""
        var networkFailure = false
        val log = StringBuilder()
        for (u in urls) {
            try {
                val res = once(u, method, body)
                lastStatus = res.first; lastText = res.second
                networkFailure = false
                val text = res.second
                log.append("$method $u\n -> HTTP ${res.first}\n -> body: ${text.trim().take(700).ifEmpty { "(empty)" }}\n\n")
                if (text.isNotBlank()) {
                    parse(text)?.let {
                        if (res.first >= 500) ApiDebug.report("Server error HTTP ${res.first}", log.toString())
                        return@withContext normalize(it, res.first)
                    }
                }
                if (res.first >= 400) {
                    if (res.first >= 500) ApiDebug.report("Server error HTTP ${res.first}", log.toString())
                    return@withContext ApiResult(false, ErrorText.format(text, res.first), null, res.first)
                }
            } catch (e: Exception) {
                networkFailure = true
                lastText = ErrorText.NO_NETWORK
                log.append("$method $u\n -> EXCEPTION ${e.javaClass.name}: ${e.message}\n\n")
            }
        }
        val msg = if (networkFailure) ErrorText.NO_NETWORK else ErrorText.format(lastText, lastStatus ?: 503)
        ApiDebug.report(if (networkFailure) "Network failure" else "Server did not return valid JSON (HTTP ${lastStatus ?: "none"})", log.toString())
        ApiResult(false, msg, null, lastStatus ?: 503)
    }

    private fun once(url: String, method: String, body: JSONObject?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = ApiConfig.CONNECT_TIMEOUT_MS
            c.readTimeout = ApiConfig.READ_TIMEOUT_MS
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            token?.let { c.setRequestProperty("Authorization", "Bearer $it"); c.setRequestProperty("X-Auth-Token", it) }
            if (body != null && method != "GET") {
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally { c.disconnect() }
    }

    private fun parse(text: String): JSONObject? {
        try { return JSONObject(text) } catch (_: Exception) {}
        // PHP warnings / HTML around valid JSON: extract the outermost {...} block like the web does
        val s = text.indexOf('{'); val e = text.lastIndexOf('}')
        if (s >= 0 && e > s) try { return JSONObject(text.substring(s, e + 1)) } catch (_: Exception) {}
        return null
    }

    private fun normalize(j: JSONObject, http: Int): ApiResult {
        val ok = http in 200..299
        val status = j.opt("status") as? String
        val success = j.optBoolean("success", false) && j.opt("success") == true ||
            (status == "success") ||
            (status == null && !j.has("success") && ok && !j.has("error"))
        val raw = j.optString("message", "").ifBlank { if (success) "Success" else "An error occurred" }
        val d: Any? = if (j.has("data") && !j.isNull("data")) j.get("data") else if (j.has("data")) null else j
        return ApiResult(success, if (success) raw else ErrorText.format(raw, http), d, http, j.optJSONObject("errors"))
    }
}

// ---- tolerant JSON readers (PHP often sends numbers as strings, nulls, or omits keys) ----
fun JSONObject.str(key: String, def: String = ""): String = if (isNull(key)) def else opt(key)?.toString() ?: def
fun JSONObject.dbl(key: String, def: Double = 0.0): Double = if (isNull(key)) def else when (val v = opt(key)) {
    is Number -> v.toDouble(); is String -> v.replace(",", "").toDoubleOrNull() ?: def; else -> def
}
fun JSONObject.flag(key: String, def: Boolean = false): Boolean = if (isNull(key)) def else when (val v = opt(key)) {
    is Boolean -> v; is Number -> v.toInt() != 0; is String -> v == "1" || v.equals("true", true) || v.equals("yes", true); else -> def
}

package com.example.walletapp

import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import com.example.walletapp.data.SecurityConfig
import com.example.walletapp.ui.AppFrame
import com.example.walletapp.ui.SecurityGate
import com.example.walletapp.ui.ZaraScreen

/** Zara's chat. FragmentActivity so the fingerprint prompt can attach when she asks to authorize a payment. */
class ZaraActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(AColor.TRANSPARENT, AColor.TRANSPARENT)
        )
        if (SecurityConfig.SECURE_WINDOW) window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
        setContent { AppFrame { _, _ -> SecurityGate { ZaraScreen(onBack = { finish() }) } } }
    }

    companion object {
        fun open(ctx: Context) = ctx.startActivity(Intent(ctx, ZaraActivity::class.java))
    }
}

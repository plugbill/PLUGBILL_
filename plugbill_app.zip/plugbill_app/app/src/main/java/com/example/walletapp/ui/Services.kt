package com.example.walletapp.ui

import com.example.walletapp.data.ApiResult
import com.example.walletapp.data.ErrorText
import com.example.walletapp.data.ServicesAPI
import com.example.walletapp.data.Sync
import com.example.walletapp.data.dbl
import com.example.walletapp.data.str
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.walletapp.services.NotificationStore
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class ServiceType(val label: String, val sub: String, val icon: List<Seg>) {
    Airtime("Airtime", "Top up any network instantly", AppIcons.Airtime),
    Data("Data", "Cheap data bundles", AppIcons.Data),
    Electricity("Electricity", "Prepaid & postpaid meters", AppIcons.Electricity),
    Tv("TV", "DStv, GOtv & StarTimes", AppIcons.Tv)
}

fun naira(v: Double): String = "\u20A6" + String.format(Locale.US, "%,.2f", v)
private fun money(v: Double): String = String.format(Locale.US, "%,.2f", v)

// ───────────── catalogue (ported from the web app's billProviders.ts) ─────────────

private data class Net(val id: String, val name: String, val logo: Int)
private val NETS = listOf(
    Net("mtn", "MTN", Logos.Mtn), Net("airtel", "Airtel", Logos.Airtel),
    Net("glo", "Glo", Logos.Glo), Net("9mobile", "9mobile", Logos.NineMobile)
)

private data class Plan(
    val net: String, val name: String, val validity: String, val price: Double, val cat: String,
    val id: String = "", val code: String = "", val providerPlanId: String = ""
)

private data class TvProv(val id: String, val name: String, val idLabel: String, val logo: Int)
private val TV_PROVS = listOf(
    TvProv("dstv", "DStv", "Smartcard number", Logos.DsTv),
    TvProv("gotv", "GOtv", "IUC number", Logos.GoTv),
    TvProv("startimes", "StarTimes", "Smartcard number", Logos.StarTimes)
)
private data class TvPack(val prov: String, val name: String, val price: Double, val channels: String, val id: String = "", val code: String = "")

private data class Disco(val name: String, val code: String)
private val DISCOS_FALLBACK = listOf("IKEDC", "EKEDC", "AEDC", "IBEDC", "EEDC", "PHED", "KEDCO", "BEDC").map { Disco(it, it) }

/** Live plans / packages / discos from services/providers.php (same fields the web screens read). */
private object Catalog {
    var loaded by mutableStateOf(false)
    var failed by mutableStateOf("")
    val plans = mutableStateMapOf<String, List<Plan>>()
    val packs = mutableStateMapOf<String, List<TvPack>>()
    val discos = mutableStateListOf<Disco>()
    private var loading = false

    private fun catOf(validity: String): String {
        val n = Regex("(\\d+)").find(validity)?.value?.toIntOrNull() ?: 30
        val v = validity.lowercase()
        val days = when { v.contains("month") -> n * 30; v.contains("week") -> n * 7; v.contains("hour") -> 1; else -> n }
        return if (days <= 3) "Daily" else if (days <= 14) "Weekly" else "Monthly"
    }

    suspend fun ensure() {
        if (loaded) return
        if (loading) { while (loading) delay(100); return }
        loading = true
        try {
            val r = ServicesAPI.getProviders()
            val d = r.obj
            if (!r.success || d == null) { failed = r.message; return }
            failed = ""
            d.optJSONObject("data_plans")?.let { dp ->
                dp.keys().forEach { net ->
                    val arr = dp.optJSONArray(net) ?: return@forEach
                    plans[net] = (0 until arr.length()).mapNotNull { i ->
                        val o = arr.optJSONObject(i) ?: return@mapNotNull null
                        val validity = o.str("validity", "30 Days")
                        val code = o.str("code").ifBlank { o.str("provider_plan_id") }
                        Plan(net, o.str("name"), validity, o.dbl("price", o.dbl("selling_price")), catOf(validity),
                            id = o.str("id").ifBlank { code }, code = code, providerPlanId = o.str("provider_plan_id").ifBlank { code })
                    }
                }
            }
            val cable = d.optJSONObject("cable_tv") ?: d.optJSONObject("cableTv")
            cable?.let { c ->
                listOf("dstv", "gotv", "startimes").forEach { k ->
                    val arr = c.optJSONArray(k) ?: return@forEach
                    packs[k] = (0 until arr.length()).mapNotNull { i ->
                        val o = arr.optJSONObject(i) ?: return@mapNotNull null
                        TvPack(k, o.str("name"), o.dbl("price", o.dbl("selling_price")), "", id = o.str("id"), code = o.str("code"))
                    }
                }
            }
            d.optJSONArray("electricity")?.let { arr ->
                val list = (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i) ?: return@mapNotNull null
                    Disco(o.str("name").ifBlank { o.str("title") }, o.str("code").ifBlank { o.str("id") })
                }.filter { it.name.isNotBlank() }
                if (list.isNotEmpty()) { discos.clear(); discos.addAll(list) }
            }
            loaded = true
        } finally { loading = false }
    }
}

// ───────────── payment plumbing ─────────────

private class PurchaseResult(val ok: Boolean, val message: String, val tx: Tx?)

private class Payer {
    var busy by mutableStateOf(false)
    var needPin by mutableStateOf(false)
    var amount = 0.0
    var pin = ""
    var build: (suspend (String) -> PurchaseResult)? = null
    /** Ignored while a purchase is running (double-tap protection). */
    fun start(amount: Double, build: suspend (String) -> PurchaseResult) { if (busy) return; this.amount = amount; this.build = build; needPin = true }
}

/**
 * Runs one purchase call. Money-moving POSTs are never retried by ApiClient. If the connection drops mid-purchase the outcome
 * is unknown (the server may have debited and is settling), so we say so, refresh the wallet and let History show the truth.
 */
private suspend fun runPurchase(ctx: android.content.Context, fallback: (Double) -> Tx, call: suspend () -> ApiResult): PurchaseResult {
    val r = call()
    if (!r.success) {
        try { Sync.refresh(ctx) } catch (_: Exception) {} // failed purchases are released server-side: pick up the restored balance
        if (r.message == ErrorText.NO_NETWORK)
            return PurchaseResult(false, "We could not confirm this purchase. Check your History before trying again.", null)
        return PurchaseResult(false, r.message, null)
    }
    val d = r.obj
    d?.takeIf { it.has("newBalance") && !it.isNull("newBalance") }?.let { Session.balance = it.dbl("newBalance", Session.balance) }
    val txo = d?.optJSONObject("transaction")
    val mapped = txo?.let { try { TxMapper.fromJson(it) } catch (_: Exception) { null } }
    var t = mapped ?: fallback(txo?.dbl("amount") ?: 0.0)
    val token = d?.str("token").orEmpty(); val units = d?.str("units").orEmpty()
    if (token.isNotBlank() || units.isNotBlank()) t = t.copy(token = token.ifBlank { t.token }, units = units.ifBlank { t.units })
    return PurchaseResult(true, r.message, t)
}

@Composable
private fun rememberPayer(onSuccess: (Tx) -> Unit): Payer {
    val ctx = LocalContext.current
    val payer = remember { Payer() }
    // full-screen blurred logo loader while the payment is being processed (after PIN / fingerprint)
    LoadingEffect(payer.busy)
    LaunchedEffect(payer.busy) {
        if (payer.busy) {
            if (!Network.isOnline(ctx)) {
                payer.busy = false
                AppToast.error("Connection error. Check your internet and try again.")
                return@LaunchedEffect
            }
            val pin = payer.pin; payer.pin = ""
            val res = try { payer.build!!.invoke(pin) } catch (e: Exception) { PurchaseResult(false, "We could not confirm this purchase. Check your History before trying again.", null) }
            payer.busy = false
            if (res.ok && res.tx != null) {
                Session.setPayPinLocal(ctx, pin)
                Session.save(ctx)
                TxStore.add(res.tx)
                onSuccess(res.tx)
            } else AppToast.error(res.message)
        }
    }
    return payer
}

private fun makeTx(
    kind: Kind, title: String, detail: String, amount: Double, logo: Int?, service: String, recipient: String,
    customer: String? = null, pkg: String? = null, token: String? = null, units: String? = null
): Tx {
    val now = LocalDateTime.now()
    val ref = "PB" + now.format(DateTimeFormatter.ofPattern("yyMMddHHmmss")) + (1000..9999).random()
    return Tx(
        kind, title, detail,
        now.format(DateTimeFormatter.ofPattern("yyyy MMMM dd", Locale.ENGLISH)),
        now.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)),
        now.format(DateTimeFormatter.ofPattern("HH:mm")),
        money(amount), false, logo, ref, service, recipient, "SUCCESSFUL", customer, pkg, token, units
    )
}

// ───────────── shared pieces ─────────────

@Composable
private fun ServiceIntro(s: ServiceType) {
    val p = pal()
    Row(
        Modifier.fillMaxWidth().background(p.surface, RoundedCornerShape(22.u())).padding(horizontal = 16.u(), vertical = 14.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GreenIcon(s.icon, 46, 24)
        Spacer(Modifier.width(14.u()))
        Column(Modifier.weight(1f)) {
            T(s.label, 16f, FontWeight.Bold)
            Spacer(Modifier.height(2.u()))
            T(s.sub, 11.5f, FontWeight.Normal, p.textSecondary, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End) {
            T("Wallet balance", 10f, FontWeight.Medium, p.textSecondary)
            Spacer(Modifier.height(2.u()))
            T(naira(Session.balance), 13.5f, FontWeight.Bold, AppColors.Accent)
        }
    }
    Spacer(Modifier.height(22.u()))
}

@Composable
private fun NetPicker(selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.u())) {
        NETS.forEach { n ->
            val sel = n.id == selected
            val shape = RoundedCornerShape(16.u())
            Column(Modifier.weight(1f).pressable(0.94f) { onSelect(n.id) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(62.u()).clip(shape).border(if (sel) 2.5.dp else 1.dp, if (sel) AppColors.Accent else pal().divider.copy(alpha = 0.5f), shape)) {
                    Image(painterResource(n.logo), n.name, Modifier.fillMaxWidth().height(62.u()), contentScale = ContentScale.Crop)
                }
                Spacer(Modifier.height(6.u()))
                T(n.name, 11f, if (sel) FontWeight.Bold else FontWeight.Medium, if (sel) AppColors.Accent else pal().textSecondary, maxLines = 1)
            }
        }
    }
}

/** Where ServiceScreen shows the pay button: pinned at the bottom while the form scrolls above it. */
private val LocalPayBarHost = androidx.compose.runtime.staticCompositionLocalOf<androidx.compose.runtime.MutableState<(@Composable () -> Unit)?>?> { null }

/** The forms call this like before; it hands the button to the pinned bottom bar instead of drawing it inside the scrolling form. */
@Composable
private fun PayBar(amount: Double?, label: String, ready: Boolean, busy: Boolean, onPay: () -> Unit) {
    val host = LocalPayBarHost.current
    val body: @Composable () -> Unit = { PayBarBody(amount, label, ready, busy, onPay) }
    if (host == null) {
        body()
    } else {
        androidx.compose.runtime.SideEffect { host.value = body }
        androidx.compose.runtime.DisposableEffect(Unit) { onDispose { host.value = null } }
    }
}

@Composable
private fun PayBarBody(amount: Double?, label: String, ready: Boolean, busy: Boolean, onPay: () -> Unit) {
    val short = amount != null && amount > Session.balance
    PrimaryButton(
        if (amount != null && amount > 0) "$label \u2022 ${naira(amount)}" else label,
        enabled = ready && !short, loading = busy, overlay = false,
        blockedMessage = if (short) "Insufficient balance. Fund your wallet to continue." else "Fill in all the details first",
        onClick = onPay
    )
}

// ───────────── forms ─────────────

/** Full-screen service page (Airtime, Data, Electricity, TV) with a back button. */
@Composable
fun ServiceScreen(service: ServiceType, onBack: () -> Unit, onReceipt: (Tx) -> Unit) {
    var done by remember { mutableStateOf<Tx?>(null) }
    var shown by remember { mutableStateOf<Tx?>(null) }
    if (done != null) shown = done
    val payer = rememberPayer { done = it }
    val covered = done != null || payer.needPin
    val blurR by androidx.compose.animation.core.animateDpAsState(
        if (covered && android.os.Build.VERSION.SDK_INT >= 31) 24.dp else 0.dp, androidx.compose.animation.core.tween(260), label = "svcBlur"
    )
    val scroll = rememberScrollState()
    val payHost = remember { mutableStateOf<(@Composable () -> Unit)?>(null) }
    Box(Modifier.fillMaxSize().background(screenBackground())) {
        Box(Modifier.fillMaxSize().blur(blurR)) {
            FrostedScreen(service.label, onBack, scrollOffset = { scroll.value }, rubberBand = false) { top ->
                androidx.compose.runtime.CompositionLocalProvider(LocalPayBarHost provides payHost) {
                    Column(Modifier.fillMaxSize().navigationBarsPadding().imePadding()) {
                        // the form (networks, plans, fields) scrolls with a rubber-band feel...
                        Box(Modifier.weight(1f).fillMaxWidth().elastic()) {
                            Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 21.u())) {
                                Spacer(Modifier.height(top))
                                ServiceIntro(service)
                                when (service) {
                                    ServiceType.Airtime -> AirtimeForm(payer)
                                    ServiceType.Data -> DataForm(payer)
                                    ServiceType.Electricity -> ElectricityForm(payer)
                                    ServiceType.Tv -> TvForm(payer)
                                }
                                Spacer(Modifier.height(20.u()))
                            }
                        }
                        // ...while the pay button stays put at the bottom
                        Column(Modifier.fillMaxWidth().padding(start = 21.u(), end = 21.u(), top = 8.u(), bottom = 14.u())) {
                            payHost.value?.invoke()
                        }
                    }
                }
            }
        }
        // every purchase asks for the 4-digit payment PIN (or fingerprint) first
        if (payer.needPin) PayPinFlow(onVerified = { pin -> payer.pin = pin; payer.needPin = false; payer.busy = true }, onCancel = { payer.needPin = false })
        GlassSheet(visible = done != null, onDismiss = onBack) {
            shown?.let { SuccessSheetContent(it, onDone = onBack, onReceipt = { onReceipt(it) }) }
        }
    }
}

@Composable
private fun AirtimeForm(payer: Payer) {
    var net by remember { mutableStateOf("mtn") }
    var phone by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val amt = amount.toDoubleOrNull() ?: 0.0
    FieldLabel("Network")
    NetPicker(net) { net = it }
    Spacer(Modifier.height(16.u()))
    FieldLabel("Phone number")
    PBField(phone, { phone = it.filter(Char::isDigit) }, "08012345678", keyboard = KeyboardType.Phone, maxLen = 11, icon = AppIcons.Phone)
    Spacer(Modifier.height(16.u()))
    FieldLabel("Amount")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.u())) {
        listOf("100", "200", "500", "1000", "2000", "5000").forEach { v -> Chip("\u20A6$v", amount == v) { amount = v } }
    }
    Spacer(Modifier.height(10.u()))
    PBField(amount, { amount = it.filter(Char::isDigit) }, "Enter amount (min \u20A650)", keyboard = KeyboardType.Number, maxLen = 6, icon = AppIcons.WalletIn)
    Spacer(Modifier.height(20.u()))
    val n = NETS.first { it.id == net }
    val ctx = LocalContext.current
    PayBar(amt, "Buy airtime", phone.length == 11 && amt >= 50, payer.busy) {
        payer.start(amt) { pin ->
            runPurchase(ctx, { a -> makeTx(Kind.Airtime, "${n.name} Airtime Top-up", phone, if (a > 0) a else amt, n.logo, "${n.name} Airtime", phone) }) {
                ServicesAPI.buyAirtime(phone, net, amt, pin)
            }
        }
    }
}

@Composable
private fun DataForm(payer: Payer) {
    var net by remember { mutableStateOf("mtn") }
    var phone by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Monthly") }
    var plan by remember { mutableStateOf<Plan?>(null) }
    val plans = (Catalog.plans[net] ?: emptyList()).filter { it.cat == cat }
    // live plans from the server; shimmer while they load
    var loadingPlans by remember { mutableStateOf(!Catalog.loaded) }
    LaunchedEffect(Unit) {
        if (!Catalog.loaded) { Catalog.ensure(); loadingPlans = false; if (!Catalog.loaded) AppToast.error(Catalog.failed.ifBlank { ErrorText.NO_NETWORK }) }
    }
    FieldLabel("Network")
    NetPicker(net) { net = it; plan = null }
    Spacer(Modifier.height(16.u()))
    FieldLabel("Phone number")
    PBField(phone, { phone = it.filter(Char::isDigit) }, "08012345678", keyboard = KeyboardType.Phone, maxLen = 11, icon = AppIcons.Phone)
    Spacer(Modifier.height(16.u()))
    FieldLabel("Choose a plan")
    Row(horizontalArrangement = Arrangement.spacedBy(8.u())) {
        listOf("Daily", "Weekly", "Monthly").forEach { c -> Chip(c, cat == c) { cat = c; plan = null } }
    }
    Spacer(Modifier.height(10.u()))
    if (loadingPlans) {
        repeat(4) { PlanSkeleton() }
    } else {
        if (plans.isEmpty()) {
            T("No $cat plans for this network.", 12.5f, FontWeight.Normal, pal().textSecondary, Modifier.padding(vertical = 10.u()))
        }
        plans.forEachIndexed { i, pl -> DropIn(i.coerceAtMost(5)) { PlanRow(pl.name, "${pl.validity} \u2022 ${pl.cat}", pl.price, plan == pl) { plan = pl } } }
    }
    Spacer(Modifier.height(14.u()))
    val n = NETS.first { it.id == net }
    val sel = plan
    val ctx = LocalContext.current
    PayBar(sel?.price, "Buy data", phone.length == 11 && sel != null && !loadingPlans, payer.busy) {
        payer.start(sel!!.price) { pin ->
            runPurchase(ctx, { a -> makeTx(Kind.Data, "${n.name} ${sel.name} Data Plan", phone, if (a > 0) a else sel.price, n.logo, "${n.name} Data", phone, pkg = "${sel.name} - ${sel.validity}") }) {
                ServicesAPI.buyData(phone, net, sel.name, sel.id, sel.code, sel.providerPlanId, sel.price, pin)
            }
        }
    }
}

@Composable
private fun PlanRow(title: String, sub: String, price: Double, selected: Boolean, onClick: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(16.u())
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.u()).pressable(0.98f, onClick)
            .background(if (selected) AppColors.Accent.copy(alpha = 0.12f) else p.surface.copy(alpha = 0.7f), shape)
            .border(1.5.dp, if (selected) AppColors.Accent else Color.Transparent, shape)
            .padding(horizontal = 16.u(), vertical = 12.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T(title, 14f, FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.height(2.u()))
            T(sub, 11f, FontWeight.Normal, p.textSecondary, maxLines = 1)
        }
        T("\u20A6" + String.format(Locale.US, if (price % 1.0 == 0.0) "%,.0f" else "%,.2f", price), 14f, FontWeight.Bold, AppColors.Accent)
    }
}

/** Placeholder shown (with a moving shimmer) while the plan list reloads. */
@Composable
private fun PlanSkeleton() {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.u()).background(pal().surface.copy(alpha = 0.7f), RoundedCornerShape(16.u()))
            .padding(horizontal = 16.u(), vertical = 14.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Box(Modifier.width(90.u()).height(13.u()).shimmer())
            Spacer(Modifier.height(8.u()))
            Box(Modifier.width(140.u()).height(10.u()).shimmer())
        }
        Box(Modifier.width(56.u()).height(14.u()).shimmer())
    }
}

@Composable
private fun ElectricityForm(payer: Payer) {
    LaunchedEffect(Unit) { Catalog.ensure() }
    val discos = if (Catalog.discos.isNotEmpty()) Catalog.discos.toList() else DISCOS_FALLBACK
    var discoName by remember { mutableStateOf("") }
    val disco = discos.firstOrNull { it.name == discoName } ?: discos.first()
    var prepaid by remember { mutableStateOf(true) }
    var meter by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val amt = amount.toDoubleOrNull() ?: 0.0
    FieldLabel("Distribution company")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.u())) {
        discos.forEach { d -> Chip(d.name, disco == d) { discoName = d.name } }
    }
    Spacer(Modifier.height(16.u()))
    FieldLabel("Meter type")
    Row(horizontalArrangement = Arrangement.spacedBy(8.u())) {
        Chip("Prepaid", prepaid) { prepaid = true }
        Chip("Postpaid", !prepaid) { prepaid = false }
    }
    Spacer(Modifier.height(16.u()))
    FieldLabel("Meter number")
    PBField(meter, { meter = it.filter(Char::isDigit) }, "Enter meter number", keyboard = KeyboardType.Number, maxLen = 13, icon = AppIcons.Electricity)
    val verified = meter.length >= 10
    Spacer(Modifier.height(16.u()))
    FieldLabel("Amount")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.u())) {
        listOf("1000", "2000", "3000", "5000", "10000").forEach { v -> Chip("\u20A6$v", amount == v) { amount = v } }
    }
    Spacer(Modifier.height(10.u()))
    PBField(amount, { amount = it.filter(Char::isDigit) }, "Enter amount (min \u20A6500)", keyboard = KeyboardType.Number, maxLen = 7, icon = AppIcons.WalletIn)
    Spacer(Modifier.height(20.u()))
    val ctx = LocalContext.current
    PayBar(amt, "Pay bill", verified && amt >= 500, payer.busy) {
        payer.start(amt) { pin ->
            runPurchase(ctx, { a ->
                makeTx(Kind.Electricity, "${disco.name} Electricity ${if (prepaid) "Token" else "Bill"}", "Meter $meter", if (a > 0) a else amt, null,
                    "${disco.name} ${if (prepaid) "Prepaid" else "Postpaid"} Electricity", meter)
            }) {
                ServicesAPI.payElectricity(disco.name, meter, amt, pin, if (prepaid) "prepaid" else "postpaid", Session.phone.ifBlank { null })
            }
        }
    }
}

@Composable
private fun TvForm(payer: Payer) {
    var prov by remember { mutableStateOf("dstv") }
    var card by remember { mutableStateOf("") }
    var pack by remember { mutableStateOf<TvPack?>(null) }
    val pv = TV_PROVS.first { it.id == prov }
    var loadingPacks by remember { mutableStateOf(!Catalog.loaded) }
    LaunchedEffect(Unit) {
        if (!Catalog.loaded) { Catalog.ensure(); loadingPacks = false; if (!Catalog.loaded) AppToast.error(Catalog.failed.ifBlank { ErrorText.NO_NETWORK }) }
    }
    FieldLabel("Provider")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.u())) {
        TV_PROVS.forEach { t ->
            val sel = t.id == prov
            val shape = RoundedCornerShape(16.u())
            Column(Modifier.weight(1f).pressable(0.94f) { prov = t.id; pack = null }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(62.u()).clip(shape).border(if (sel) 2.5.dp else 1.dp, if (sel) AppColors.Accent else pal().divider.copy(alpha = 0.5f), shape)) {
                    Image(painterResource(t.logo), t.name, Modifier.fillMaxWidth().height(62.u()), contentScale = ContentScale.Crop)
                }
                Spacer(Modifier.height(6.u()))
                T(t.name, 11f, if (sel) FontWeight.Bold else FontWeight.Medium, if (sel) AppColors.Accent else pal().textSecondary, maxLines = 1)
            }
        }
    }
    Spacer(Modifier.height(16.u()))
    FieldLabel(pv.idLabel)
    PBField(card, { card = it.filter(Char::isDigit) }, "Enter ${pv.idLabel.lowercase()}", keyboard = KeyboardType.Number, maxLen = 11, icon = AppIcons.Tv)
    val verified = card.length >= 10
    Spacer(Modifier.height(16.u()))
    FieldLabel("Choose a package")
    if (loadingPacks) {
        repeat(4) { PlanSkeleton() }
    } else {
        (Catalog.packs[prov] ?: emptyList()).forEachIndexed { i, pk -> DropIn(i.coerceAtMost(5)) { PlanRow(pk.name, "1 month", pk.price, pack == pk) { pack = pk } } }
    }
    Spacer(Modifier.height(14.u()))
    val sel = pack
    val ctx = LocalContext.current
    PayBar(sel?.price, "Subscribe", verified && sel != null && !loadingPacks, payer.busy) {
        payer.start(sel!!.price) { pin ->
            runPurchase(ctx, { a -> makeTx(Kind.Tv, "${sel.name} Subscription", "${pv.idLabel.substringBefore(" ")} $card", if (a > 0) a else sel.price, pv.logo, "${pv.name} Subscription", card, pkg = sel.name) }) {
                ServicesAPI.payCableTv(prov, card, sel.name, sel.id.ifBlank { sel.code }.ifBlank { null }, sel.price, pin)
            }
        }
    }
}

// ───────────── success bottom sheet ─────────────

@Composable
fun SuccessSheetContent(tx: Tx, onDone: () -> Unit, onReceipt: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    LaunchedEffect(tx.reference) { Haptics.success(ctx) }
    val title = when (tx.kind) {
        Kind.Airtime -> "Airtime purchase successful"
        Kind.Data -> "Data purchase successful"
        Kind.Electricity -> "Electricity payment successful"
        Kind.Tv -> "TV subscription successful"
        Kind.Funding -> "Wallet funded"
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        SuccessLottie(120)
        Spacer(Modifier.height(4.u()))
        T(title, 19f, FontWeight.Bold, align = TextAlign.Center)
        Spacer(Modifier.height(6.u()))
        T("\u20A6${tx.amount}", 30f, FontWeight.Bold, AppColors.Accent)
        Spacer(Modifier.height(16.u()))
        Column(
            Modifier.fillMaxWidth().background(p.surface.copy(alpha = 0.95f), RoundedCornerShape(18.u())).padding(horizontal = 16.u(), vertical = 6.u())
        ) {
            SummaryRow("Service", tx.service)
            SummaryRow("Recipient", tx.recipient)
            tx.token?.let { SummaryRow("Token", it) }
            SummaryRow("Reference", tx.reference)
            SummaryRow("Date", "${tx.shortDate} \u2022 ${tx.time}")
        }
        if (tx.token != null) {
            Spacer(Modifier.height(8.u()))
            T("Your meter token is also saved in your transaction details.", 11.5f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center)
        }
        Spacer(Modifier.height(18.u()))
        PrimaryButton("Done", onClick = onDone)
        Spacer(Modifier.height(12.u()))
        T("View details", 14f, FontWeight.Bold, AppColors.Accent, Modifier.pressable(onClick = onReceipt).padding(8.u()))
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.u()), verticalAlignment = Alignment.CenterVertically) {
        T(label, 12.5f, FontWeight.Medium, pal().textSecondary)
        Spacer(Modifier.width(12.u()))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) { T(value, 12.5f, FontWeight.Bold, maxLines = 1, align = TextAlign.End) }
    }
}

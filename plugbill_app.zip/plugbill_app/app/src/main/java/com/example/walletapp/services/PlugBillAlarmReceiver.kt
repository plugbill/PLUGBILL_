package com.example.walletapp.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class PlugBillAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        context ?: return
        try {
            val type = intent?.getStringExtra("notification_type") ?: "discount"
            Log.d("PlugBillAlarm", "Received Alarm trigger for notification type: $type")
            PlugBillNotificationHelper.showEngagementNotification(context, type)

            // Re-schedule next alarm
            PlugBillNotificationScheduler.scheduleAll(context)
        } catch (e: Exception) {
            Log.e("PlugBillAlarm", "Error handling alarm receive", e)
        }
    }
}

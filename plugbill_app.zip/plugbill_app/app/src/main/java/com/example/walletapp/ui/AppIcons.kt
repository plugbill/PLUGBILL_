package com.example.walletapp.ui

object AppIcons {
    val Menu = icon("M2 7H22", "M2 12H22", "M2 17H22")
    val Bell = icon(
        "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9",
        "M13.73 21a2 2 0 0 1-3.46 0"
    )
    val Back = icon("M19 12H5", "M12 19L5 12L12 5")
    val Close = icon("M6 6L18 18", "M18 6L6 18")
    val Chevron = icon("M9 6L15 12L9 18")
    val Lock = icon(
        "M7 11h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2z",
        "M8 11V8a4 4 0 0 1 8 0v3",
        "M12 15.5v.5"
    )
    val ArrowUp = icon("M12 19V5", "M6 11L12 5L18 11")
    val ArrowDown = icon("M12 5V19", "M6 13L12 19L18 13")

    // bottom bar
    val Home = icon(
        "M3 11.5L12 4l9 7.5",
        "M5.5 10v9a1 1 0 0 0 1 1H10v-5h4v5h3.5a1 1 0 0 0 1 -1v-9"
    )
    val Bills = icon(
        "M7 3.5h10a1 1 0 0 1 1 1V20l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5L6 20V4.5a1 1 0 0 1 1-1z",
        "M9.5 8h5",
        "M9.5 12h5"
    )
    val Profile = icon(
        "M9 8a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z",
        "M5 20c0 -3.5 3 -6 7 -6s7 2.5 7 6"
    )

    // bill types
    val Airtime = icon(rr(7f, 2.5f, 10f, 19f, 2.5f), "M11 18.5h2")
    val Data = icon(
        "M2 9a15 15 0 0 1 20 0",
        "M5.5 12.8a10 10 0 0 1 13 0",
        "M9 16.5a5 5 0 0 1 6 0",
        "M12 20h.01"
    )
    val Electricity = icon("M13 2L4 14h7l-1 8 9-12h-7z")
    val Tv = icon(rr(2.5f, 5f, 19f, 13f, 2.5f), "M8 21.5h8", "M12 18v3.5")
    val WalletIn = icon(rr(3f, 6.5f, 18f, 13.5f, 3.5f), "M6 3.5h9", "M12 10.5v6", "M9 13.5h6")
    /** Money received from someone (arrow dropping into a tray). */
    val Receive = icon("M12 3v11", "M7.5 9.5L12 14l4.5-4.5", "M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3")

    // actions / profile
    val History = icon("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", "M12 7v5l3 2")
    val Copy = icon(rr(9f, 9f, 12f, 12f, 2.5f), "M5 15V6a2 2 0 0 1 2 -2h9")
    val Moon = icon("M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z")
    val Shield = icon("M12 3l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10V6z", "M9.5 12l2 2 3.5-4")
    val Document = icon(
        "M7 3h7l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z",
        "M14 3v4h4", "M9 12h6", "M9 16h6"
    )
    val Share = icon("M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7", "M16 6l-4-4-4 4", "M12 2v13")

    // added for PlugBill
    val Eye = icon("M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z", "M9 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z")
    val EyeOff = icon("M3 3l18 18", "M10.6 6.1A9.8 9.8 0 0 1 12 6c6 0 10 6 10 6a17 17 0 0 1 -3.2 3.9", "M6.5 7.6C3.6 9.4 2 12 2 12s4 7 10 7c1.6 0 3 -.4 4.3 -1", "M9.9 9.9a3 3 0 0 0 4.2 4.2")
    val Mail = icon(rr(3f, 5f, 18f, 14f, 3f), "M4 7l8 6 8 -6")
    val Phone = icon("M6.6 3h3l1.6 4-2 1.3a11 11 0 0 0 5.5 5.5l1.3-2 4 1.6v3a2 2 0 0 1-2.2 2A16 16 0 0 1 4.6 5.2 2 2 0 0 1 6.6 3z")
    val Fingerprint = icon("M12 4a7 7 0 0 0-7 7v1.5", "M12 8a3 3 0 0 0-3 3v2a8 8 0 0 1-1 3.5", "M12 12v2a10 10 0 0 1-1.5 5", "M16 11a4 4 0 0 0-1-2.6", "M19 12.5V11a7 7 0 0 0-3-5.7", "M16 14c0 2-.4 3.7-1.2 5.2")
    val Gift = icon(rr(3f, 8f, 18f, 4f, 1.5f), "M5 12v8h14v-8", "M12 8v12", "M12 8c-2.5 0-4-1-4-2.5S9 3 10.5 3C12 3 12 5 12 8z", "M12 8c2.5 0 4-1 4-2.5S15 3 13.5 3C12 3 12 5 12 8z")
    val Bank = icon("M3 10l9-6 9 6", "M5 10v8", "M9.5 10v8", "M14.5 10v8", "M19 10v8", "M3 20h18")
    val Flight = icon("M10.5 13.5L3 11l1-1.5 8 .5 4-5 2 1-2.2 5.5 5.2 2.5-1 2-6-1-3 5-1.5-.8z")
    val Check = icon("M5 12.5l4.5 4.5L19 7.5")
    val Support = icon("M4 13v-1a8 8 0 0 1 16 0v1", rr(3f, 13f, 4f, 6f, 1.5f), rr(17f, 13f, 4f, 6f, 1.5f), "M21 19a3 3 0 0 1-3 3h-3")
    val Chart = icon("M4 20V10", "M10 20V4", "M16 20v-8", "M22 20H2")
    val Refresh = icon("M20 11a8 8 0 1 0-2 5.5", "M20 4v7h-7")
    val Education = icon("M2 9l10-5 10 5-10 5z", "M6 11v5c0 1.5 3 3 6 3s6-1.5 6-3v-5")
    val Info = icon("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", "M12 11v5", "M12 8h.01")
    val Key = icon("M7 14a4 4 0 1 1 0-8 4 4 0 0 1 0 8z", "M10.8 11.2L21 21", "M17 17l-2 2", "M20 20l-2 2")
    val Logout = icon("M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "M16 17l5-5-5-5", "M21 12H9")
}

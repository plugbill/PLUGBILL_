package com.example.walletapp.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * "Pull up to load more": when the list is already at its end, dragging further stretches the list upward (rubber band)
 * and shows a hint. Letting go past the threshold bounces back and loads the next page. Nothing loads by itself,
 * so data is only fetched when the person asks for more.
 */
class PullUpState {
    val offset = Animatable(0f)
    var raw = 0f
    var loading by mutableStateOf(false)
    var armed by mutableStateOf(false)
}

@Composable
fun rememberPullUpState(): PullUpState = remember { PullUpState() }

@Composable
fun Modifier.pullUpToLoad(state: PullUpState, enabled: Boolean, onLoad: suspend () -> Unit): Modifier {
    val threshold = with(LocalDensity.current) { 76.dp.toPx() }
    val maxPull = threshold * 1.8f
    val scope = rememberCoroutineScope()
    val enabledNow by rememberUpdatedState(enabled)
    val loadNow by rememberUpdatedState(onLoad)
    val connection = remember(state, threshold) {
        object : NestedScrollConnection {
            var flinging = false

            // dragging back down while the footer is stretched: shrink it first
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (!flinging && !state.loading && state.raw > 0f && available.y > 0f) {
                    val use = minOf(available.y, state.raw)
                    state.raw -= use
                    state.armed = state.raw >= threshold
                    scope.launch { state.offset.snapTo(state.raw) }
                    return Offset(0f, use)
                }
                return Offset.Zero
            }

            // the list could not use the rest of an upward drag: it is at the end, so stretch the footer
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!flinging && enabledNow && !state.loading && available.y < 0f) {
                    state.raw = (state.raw - available.y * 0.55f).coerceAtMost(maxPull)
                    state.armed = state.raw >= threshold
                    scope.launch { state.offset.snapTo(state.raw) }
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity { flinging = true; return Velocity.Zero }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                flinging = false
                if (state.raw >= threshold && enabledNow && !state.loading) {
                    state.loading = true
                    scope.launch {
                        state.offset.animateTo(threshold * 0.72f, spring(0.6f, Spring.StiffnessMedium))
                        try { loadNow() } finally {
                            state.loading = false; state.armed = false; state.raw = 0f
                            state.offset.animateTo(0f, spring(0.5f, Spring.StiffnessMediumLow))   // bounce back
                        }
                    }
                } else if (!state.loading) {
                    state.armed = false; state.raw = 0f
                    scope.launch { state.offset.animateTo(0f, spring(0.55f, Spring.StiffnessMediumLow)) }
                }
                return Velocity.Zero
            }
        }
    }
    return this.nestedScroll(connection)
}

/** The area revealed under the stretched list: arrow / spinner and a short hint. */
@Composable
fun PullUpFooter(state: PullUpState, perPage: Int, modifier: Modifier = Modifier) {
    val p = pal()
    val h = with(LocalDensity.current) { state.offset.value.toDp() }
    if (h < 2.dp) return
    Box(modifier.fillMaxWidth().height(h).clipToBounds(), contentAlignment = Alignment.TopCenter) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(10.u()))
            if (state.loading) Spinner() else Arrow(state.armed)
            Spacer(Modifier.height(6.u()))
            T(
                if (state.loading) "Loading $perPage more..." else if (state.armed) "Release to load $perPage more" else "Pull up to load $perPage more",
                11.5f, FontWeight.Medium, p.textSecondary
            )
        }
    }
}

@Composable
private fun Arrow(up: Boolean) {
    val rot by androidx.compose.animation.core.animateFloatAsState(if (up) 180f else 0f, tween(200), label = "arrow")
    val c = AppColors.Accent
    Canvas(Modifier.size(22.dp).rotate(rot)) {
        val w = size.width; val s = Stroke(width = 2.6f * density, cap = StrokeCap.Round)
        drawLine(c, Offset(w * 0.5f, w * 0.22f), Offset(w * 0.5f, w * 0.80f), s.width, StrokeCap.Round)
        drawLine(c, Offset(w * 0.5f, w * 0.80f), Offset(w * 0.24f, w * 0.54f), s.width, StrokeCap.Round)
        drawLine(c, Offset(w * 0.5f, w * 0.80f), Offset(w * 0.76f, w * 0.54f), s.width, StrokeCap.Round)
    }
}

@Composable
private fun Spinner() {
    val t = rememberInfiniteTransition(label = "spin")
    val a by t.animateFloat(0f, 360f, infiniteRepeatable(tween(800, easing = LinearEasing)), label = "a")
    val c = AppColors.Accent
    Canvas(Modifier.size(22.dp).rotate(a)) {
        val sw = 3f * density
        drawArc(c, 0f, 270f, false, topLeft = Offset(sw / 2, sw / 2), size = Size(size.width - sw, size.height - sw), style = Stroke(sw, cap = StrokeCap.Round))
    }
}

package com.example.walletapp.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.walletapp.ReceiptActivity

/** Line icon for a transaction: receive arrow for money from someone, wallet for funding, then the service icon. */
fun txGlyph(tx: Tx): List<Seg> = when {
    tx.received -> AppIcons.Receive
    else -> tx.kind.icon()
}

/**
 * Transaction leading icon: the network / provider logo (MTN, Airtel, DStv...) for airtime, data and TV,
 * otherwise a green icon tile (wallet funding, payment received) or an amber one (electricity).
 * The PlugBill app logo is never used here.
 */
@Composable
fun TxIcon(tx: Tx, size: Number = 52, corner: Number = 16) {
    val p = pal()
    val shape = RoundedCornerShape(corner.u())
    val logo = tx.logo?.takeIf { it != Logos.PlugBill }
    if (logo != null) {
        Box(Modifier.size(size.u()).softShadow(shape, p.shadow, 10.u(), 0.dp, 4.u())) {
            Image(
                painter = painterResource(logo),
                contentDescription = tx.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size.u()).clip(shape)
            )
        }
    } else {
        val c1: Color
        val c2: Color
        if (tx.kind == Kind.Electricity) {
            c1 = Color(0xFFFFC145); c2 = Color(0xFFF59E0B)
        } else if (p.dark) {
            c1 = Color(0xFF12A56D); c2 = Color(0xFF007A4C)
        } else {
            c1 = AppColors.GreenLight; c2 = AppColors.Accent
        }
        Box(
            Modifier.size(size.u())
                .softShadow(shape, c2.copy(alpha = 0.35f), 8.u(), 0.dp, 3.u())
                .background(Brush.linearGradient(listOf(c1, c2)), shape),
            contentAlignment = Alignment.Center
        ) {
            SvgIcon(txGlyph(tx), (size.toFloat() * 0.46f).u(), Color.White, 2f)
        }
    }
}

/** Opens the receipt screen (its own Activity) for a transaction. */
fun openReceipt(ctx: Context, tx: Tx) {
    ctx.startActivity(Intent(ctx, ReceiptActivity::class.java).putExtra(ReceiptActivity.EXTRA_REF, tx.reference))
    (ctx as? android.app.Activity)?.overridePendingTransition(com.example.walletapp.R.anim.fade_in_soft, com.example.walletapp.R.anim.fade_out_soft)
}

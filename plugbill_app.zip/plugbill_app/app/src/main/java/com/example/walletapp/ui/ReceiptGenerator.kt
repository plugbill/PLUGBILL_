package com.example.walletapp.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.walletapp.R

/** One line of the transaction details list / receipt. */
data class TxLine(val label: String, val value: String, val bold: Boolean = false, val highlight: Boolean = false)

fun txLines(tx: Tx): List<TxLine> = buildList {
    add(TxLine("Service", tx.service.ifBlank { "Wallet Top-Up" }))
    add(TxLine("Recipient", tx.recipient.ifBlank { "Main Account" }, bold = true))
    if (!tx.customer.isNullOrBlank()) add(TxLine("Customer", tx.customer))
    if (!tx.packageName.isNullOrBlank()) add(TxLine("Package Plan", tx.packageName))
    if (!tx.token.isNullOrBlank()) add(TxLine("Token", tx.token, bold = true, highlight = true))
    if (!tx.units.isNullOrBlank()) add(TxLine("Units", tx.units))
    add(TxLine("Amount", "\u20A6" + tx.amount, bold = true))
    add(TxLine("Fee", "\u20A60.00 (Free)", highlight = true))
    add(TxLine("Reference", tx.reference, bold = true))
    add(TxLine("Date & Time", "${tx.shortDate} \u2022 ${tx.time}"))
    add(TxLine("Payment Method", if (tx.incoming) "9PSB Dedicated Bank Transfer" else "PlugBill Wallet"))
}

/** Flat, minimal receipt image: white paper with sharp zig-zag top and bottom edges. */
object ReceiptGenerator {
    private const val W = 640f
    private const val SCALE = 2f

    private const val SLATE = 0xFF64748B.toInt()
    private const val INK = 0xFF0F172A.toInt()
    private const val BG = 0xFFF1F5F4.toInt()
    private const val GREEN = 0xFF00B875.toInt()
    private const val AMBER = 0xFFB7791F.toInt()
    private const val RED = 0xFFEF4444.toInt()

    private var outfitRegular: Typeface = Typeface.SANS_SERIF
    private var outfitBold: Typeface = Typeface.SANS_SERIF

    private fun loadFonts(ctx: Context) {
        outfitRegular = androidx.core.content.res.ResourcesCompat.getFont(ctx, R.font.outfit_regular) ?: Typeface.SANS_SERIF
        outfitBold = androidx.core.content.res.ResourcesCompat.getFont(ctx, R.font.outfit_bold) ?: Typeface.SANS_SERIF
    }

    private fun paint(size: Float, color: Int, bold: Boolean = true, align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            textAlign = align
            letterSpacing = spacing
            typeface = if (bold) outfitBold else outfitRegular
        }

    private fun Canvas.textTop(s: String, x: Float, y: Float, p: Paint) = drawText(s, x, y - p.fontMetrics.ascent, p)

    private fun Canvas.textMid(s: String, x: Float, y: Float, p: Paint) {
        val fm = p.fontMetrics
        drawText(s, x, y - (fm.ascent + fm.descent) / 2f, p)
    }

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }

    /** Rectangle with a zig-zag (sharp teeth) top edge and bottom edge. */
    private fun paperPath(l: Float, t: Float, r: Float, b: Float, tw: Float, th: Float, n: Int): Path =
        Path().apply {
            moveTo(l, t + th)
            for (i in 0 until n) {
                val x1 = l + i * tw
                lineTo(x1 + tw / 2f, t)
                lineTo(x1 + tw, t + th)
            }
            lineTo(r, b - th)
            for (i in n - 1 downTo 0) {
                val x1 = l + i * tw
                lineTo(x1 + tw / 2f, b)
                lineTo(x1, b - th)
            }
            close()
        }

    fun generate(ctx: Context, tx: Tx): Bitmap {
        loadFonts(ctx)
        val lines = txLines(tx)
        val rowH = 42f
        val height = 430f + lines.size * rowH

        val bmp = Bitmap.createBitmap((W * SCALE).toInt(), (height * SCALE).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(SCALE, SCALE)
        c.drawColor(BG)

        val margin = 28f
        val l = margin; val r = W - margin
        val top = margin; val bottom = height - margin
        val cx = W / 2f
        val toothH = 12f
        val teeth = ((r - l) / 20f).toInt()
        c.drawPath(paperPath(l, top, r, bottom, (r - l) / teeth, toothH, teeth), fill(0xFFFFFFFF.toInt()))

        // header
        var y = top + toothH + 30f
        val logoSize = 52f
        val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.plugbill_logo)
        c.drawBitmap(logo, null, RectF(cx - logoSize / 2f, y, cx + logoSize / 2f, y + logoSize), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        y += logoSize + 12f
        c.textTop("PlugBill", cx, y, paint(22f, INK, align = Paint.Align.CENTER))
        y += 28f
        c.textTop("Transaction Receipt", cx, y, paint(13f, SLATE, bold = false, align = Paint.Align.CENTER, spacing = 0.04f))
        y += 36f

        // amount + status
        c.textTop("\u20A6" + tx.amount, cx, y, paint(40f, INK, align = Paint.Align.CENTER))
        y += 56f
        val status = tx.status.uppercase()
        val (label, fg) = when (status) {
            "SUCCESSFUL" -> "Successful" to GREEN
            "PENDING" -> "Pending" to AMBER
            else -> "Failed" to RED
        }
        val chipP = paint(13f, fg, align = Paint.Align.CENTER)
        val chipW = chipP.measureText(label) + 34f
        val chipH = 28f
        c.drawRoundRect(RectF(cx - chipW / 2f, y, cx + chipW / 2f, y + chipH), chipH / 2f, chipH / 2f, fill((fg and 0x00FFFFFF) or 0x1F000000))
        c.textMid(label, cx, y + chipH / 2f, chipP)
        y += chipH + 26f

        // dashed divider
        c.drawLine(l + 32f, y, r - 32f, y, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFD5DDE3.toInt(); strokeWidth = 1.5f; style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f)
        })
        y += 14f

        // rows
        val tx0 = l + 32f
        val tx1 = r - 32f
        val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF1F5F9.toInt(); strokeWidth = 1.5f }
        val labelP = paint(14f, SLATE, bold = false)
        lines.forEachIndexed { i, row ->
            val ry = y + i * rowH
            if (i > 0) c.drawLine(tx0, ry, tx1, ry, hair)
            c.textMid(row.label, tx0, ry + rowH / 2f, labelP)
            val vp = paint(14f, if (row.highlight) GREEN else INK, bold = row.bold, align = Paint.Align.RIGHT)
            val maxW = (tx1 - tx0) * 0.6f
            var v = row.value
            if (vp.measureText(v) > maxW) {
                while (vp.measureText("$v...") > maxW && v.length > 5) v = v.dropLast(1)
                v += "..."
            }
            c.textMid(v, tx1, ry + rowH / 2f, vp)
        }
        y += lines.size * rowH + 22f

        // footer
        c.textTop("Thank you for choosing PlugBill", cx, y, paint(13f, INK, align = Paint.Align.CENTER))
        y += 22f
        c.textTop("This receipt was generated electronically", cx, y, paint(11f, SLATE, bold = false, align = Paint.Align.CENTER))
        return bmp
    }
}

package com.example.walletapp.data

import android.content.Context

/** Registration details held in memory between the OTP step and PIN creation (register.php needs the PIN). Never persisted. */
object PendingReg {
    private var first = ""; private var last = ""; private var email = ""; private var phone = ""; private var password = ""
    var referral: String? = null
    val active: Boolean get() = email.isNotBlank() && password.isNotEmpty()

    fun set(f: String, l: String, e: String, p: String, pw: String) { first = f; last = l; email = e; phone = p; password = pw }
    fun clear() { first = ""; last = ""; email = ""; phone = ""; password = ""; referral = null }

    suspend fun submit(ctx: Context, pin: String): Pair<Boolean, String> {
        val r = AuthFlow.register(ctx, first, last, email, phone, password, pin, referral)
        if (r.first) clear()
        return r
    }
}

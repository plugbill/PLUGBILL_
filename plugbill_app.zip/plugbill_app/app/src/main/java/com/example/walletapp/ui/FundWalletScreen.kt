package com.example.walletapp.ui

import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun FundWalletScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    var generating by remember { mutableStateOf(false) }
    // like the web: load the existing virtual account on open, create it only if none exists
    LaunchedEffect(Unit) {
        if (Session.accountNumber == null && Network.isOnline(ctx)) {
            generating = true
            val got = com.example.walletapp.data.WalletAPI.getVirtualAccounts()
            val arr = got.obj?.optJSONArray("accounts")
            if (got.success && arr != null && arr.length() > 0) { Session.applyVirtualAccounts(arr); Session.save(ctx) }
            generating = false
        }
    }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    fun generate() {
        if (generating) return
        if (!Network.isOnline(ctx)) { AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); return }
        generating = true
        scope.launch {
            val r = com.example.walletapp.data.WalletAPI.generateVirtualAccount(Session.email)
            val arr = r.obj?.optJSONArray("accounts")
            if (r.success && arr != null && arr.length() > 0) {
                Session.applyVirtualAccounts(arr)
            } else if (r.success && r.obj?.optJSONObject("account") != null) {
                val acc = r.obj!!.optJSONObject("account")!!
                Session.accountNumber = acc.optString("account_number").ifBlank { null }
                Session.bankName = acc.optString("bank_name").ifBlank { Session.bankName }
                Session.accountName = acc.optString("account_name").ifBlank { Session.accountName }
            } else AppToast.error(r.message)
            Session.save(ctx)
            if (Session.accountNumber != null) { Haptics.success(ctx); AppToast.success("Your account number is ready") }
            generating = false
        }
    }
    val number = Session.accountNumber
    val scroll = rememberScrollState()
    FrostedScreen("Fund wallet", onBack, scrollOffset = { scroll.value }) { top ->
     Box(Modifier.fillMaxSize()) {
      Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
        Spacer(Modifier.height(top))
        Column(Modifier.padding(horizontal = 21.u())) {
            if (number == null) {
                val card = RoundedCornerShape(28.u())
                Column(
                    Modifier.fillMaxWidth().softShadow(card, AppColors.Accent.copy(alpha = 0.3f), 24.u(), 0.dp, 12.u())
                        .background(Brush.linearGradient(listOf(AppColors.GreenDeep, AppColors.Accent, AppColors.GreenLight)), card)
                        .padding(22.u())
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SvgIcon(AppIcons.Bank, 22.u(), Color.White, 1.9f)
                        Spacer(Modifier.width(10.u()))
                        T("9 Payment Service Bank", 13f, FontWeight.SemiBold, Color.White, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(20.u()))
                    T("No account number yet", 17f, FontWeight.Bold, Color.White)
                    Spacer(Modifier.height(4.u()))
                    T("Generate a dedicated account and fund your wallet by bank transfer. Funds arrive instantly.", 11.5f, FontWeight.Normal, Color(0xFFD8FFEE), lineHeight = 16f)
                    Spacer(Modifier.height(16.u()))
                    Box(
                        Modifier.fillMaxWidth().height(50.u()).pressable(0.98f) { generate() }
                            .background(Color.White, RoundedCornerShape(16.u())),
                        contentAlignment = Alignment.Center
                    ) {
                        LoadingEffect(generating)
                        T("Generate account number", 14f, FontWeight.Bold, AppColors.Accent)
                    }
                }
            } else {
                // every detail in its own card
                ProfileInfoCard(AppIcons.Bank, "Bank name", Session.bankName, true)
                Spacer(Modifier.height(12.u()))
                ProfileInfoCard(AppIcons.Profile, "Account name", Session.accountName.ifBlank { "PLUGBILL - ${Session.fullName.uppercase()}" }, true)
                Spacer(Modifier.height(12.u()))
                val big = RoundedCornerShape(24.u())
                Column(
                    Modifier.fillMaxWidth().softShadow(big, AppColors.Accent.copy(alpha = 0.3f), 24.u(), 0.dp, 12.u())
                        .background(Brush.linearGradient(listOf(AppColors.GreenDeep, AppColors.Accent, AppColors.GreenLight)), big)
                        .padding(horizontal = 20.u(), vertical = 18.u())
                ) {
                    T("ACCOUNT NUMBER", 9.5f, FontWeight.SemiBold, Color(0xFFB8F5DE), spacing = 0.5f)
                    Spacer(Modifier.height(6.u()))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T(number, 28f, FontWeight.Bold, Color.White, Modifier.weight(1f), spacing = 2f, maxLines = 1)
                        Box(
                            Modifier.height(40.u()).pressable {
                                clip.setText(AnnotatedString(number)); Haptics.tick(ctx)
                                AppToast.success("Account number copied")
                            }.background(Color.White, RoundedCornerShape(13.u())).padding(horizontal = 16.u()),
                            contentAlignment = Alignment.Center
                        ) { T("Copy", 12.5f, FontWeight.Bold, AppColors.Accent) }
                    }
                }
            }
            Spacer(Modifier.height(18.u()))
            T("Transfer to this account from any bank app. Your wallet is credited automatically, with zero charges.", 11.5f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 16f)
            Spacer(Modifier.height(64.u()))
        }
      }
      // "Verified by CBN" stays pinned at the bottom of the screen
      CbnBadge(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.u()))
     }
    }
}

/** CBN logo + "Verified by CBN". The logo is res/drawable/cbn_logo (replace it with the official artwork). */
@Composable
fun CbnBadge(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.example.walletapp.R.drawable.cbn_logo),
            contentDescription = "CBN",
            modifier = Modifier.size(22.u())
        )
        Spacer(Modifier.width(8.u()))
        T("Verified by CBN", 12f, FontWeight.SemiBold, pal().textSecondary)
    }
}

package com.example.walletapp.ui

import com.example.walletapp.data.AuthAPI
import com.example.walletapp.data.AuthFlow
import com.example.walletapp.data.LoginOutcome
import com.example.walletapp.data.PendingReg
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Screen background with a green glow fading in from the top AND the bottom. */
@Composable
fun Modifier.authBackground(): Modifier {
    val p = pal()
    val h = 260.u()
    val accent = AppColors.Accent
    val topA = if (p.dark) 0.20f else 0.16f
    val botA = if (p.dark) 0.24f else 0.20f
    return this.background(screenBackground()).drawBehind {
        val hp = h.toPx()
        drawRect(
            Brush.verticalGradient(listOf(accent.copy(alpha = topA), Color.Transparent), startY = 0f, endY = hp),
            size = Size(size.width, hp)
        )
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, accent.copy(alpha = botA)), startY = size.height - hp, endY = size.height),
            topLeft = Offset(0f, size.height - hp), size = Size(size.width, hp)
        )
    }
}

/** Shared shell for auth screens: green header glow + scrolling form. */
@Composable
private fun AuthFrame(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)?,
    step: Int? = null,
    content: @Composable () -> Unit
) {
    val p = pal()
    Box(Modifier.fillMaxSize().authBackground().elastic()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 21.u())
        ) {
            Spacer(Modifier.height(20.u()))
            if (onBack != null) {
                FloatSurface(Modifier.size(52.u()), RoundedCornerShape(18.u()), onBack) { SvgIcon(AppIcons.Back, 22.u(), p.text, 2f) }
            } else Spacer(Modifier.height(52.u()))
            Spacer(Modifier.height(24.u()))
            if (step != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.u())) {
                    repeat(4) { i ->
                        val fill by animateFloatAsState(if (i <= step) 1f else 0f, tween(350), label = "stepbar")
                        Box(Modifier.weight(1f).height(5.u()).background(p.divider, CircleShape)) {
                            Box(Modifier.fillMaxWidth(fill).height(5.u()).background(AppColors.Accent, CircleShape))
                        }
                    }
                }
                Spacer(Modifier.height(10.u()))
                T("Step ${step + 1} of 4", 11.5f, FontWeight.Medium, p.textSecondary)
                Spacer(Modifier.height(14.u()))
            }
            T(title, 30f, FontWeight.Bold)
            Spacer(Modifier.height(6.u()))
            T(subtitle, 13.5f, FontWeight.Normal, p.textSecondary, lineHeight = 13.5f * 1.4f)
            Spacer(Modifier.height(28.u()))
            content()
            Spacer(Modifier.height(24.u()))
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val p = pal()
    LaunchedEffect(Unit) { delay(2200); onDone() }
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "dots")
    Box(Modifier.fillMaxSize().background(screenBackground())) {
        // launcher icon: green rounded tile with the PlugBill mark, 145 x 145
        Box(
            Modifier.align(Alignment.Center).size(145.dp)
                .clip(RoundedCornerShape(36.dp))
                .background(Color(0xFF00B875)),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(com.example.walletapp.R.drawable.ic_launcher_fg),
                contentDescription = "PlugBill",
                modifier = Modifier.size(145.dp)
            )
        }
        // three pulsing loading dots
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 56.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(3) { i ->
                val v by t.animateFloat(
                    initialValue = 0f, targetValue = 1f,
                    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                        androidx.compose.animation.core.keyframes {
                            durationMillis = 1200
                            0f at i * 160 using androidx.compose.animation.core.FastOutSlowInEasing
                            1f at i * 160 + 300 using androidx.compose.animation.core.FastOutSlowInEasing
                            0f at i * 160 + 600
                            0f at 1200
                        }
                    ),
                    label = "dot$i"
                )
                Box(
                    Modifier.size(11.dp).scale(0.7f + 0.5f * v).alpha(0.35f + 0.65f * v)
                        .background(if (v > 0.5f) AppColors.Accent else p.text.copy(alpha = 0.55f), CircleShape)
                )
            }
        }
    }
}

/** Shown after onboarding: create a new account or log in. */
@Composable
fun WelcomeScreen(onCreate: () -> Unit, onLogin: () -> Unit, onTerms: () -> Unit, onPrivacy: () -> Unit) {
    val p = pal()
    Box(Modifier.fillMaxSize().authBackground().elastic().statusBarsPadding().navigationBarsPadding()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 21.u()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))
            AppLogo(size = 96)
            Spacer(Modifier.height(28.u()))
            T("Welcome to PlugBill", 28f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(10.u()))
            T(
                "Create an account to pay bills, buy airtime and data, and manage your wallet in one place.",
                14f, FontWeight.Normal, p.textSecondary, Modifier.padding(horizontal = 10.u()),
                align = TextAlign.Center, lineHeight = 14f * 1.5f
            )
            Spacer(Modifier.weight(1.2f))
            PrimaryButton("Create new account", onClick = onCreate)
            Spacer(Modifier.height(14.u()))
            val shape = RoundedCornerShape(18.u())
            Box(
                Modifier.fillMaxWidth().height(56.u()).pressable(0.98f, onLogin)
                    .background(p.surface, shape).border(1.5.dp, AppColors.Accent, shape),
                contentAlignment = Alignment.Center
            ) { T("Login", 16f, FontWeight.SemiBold, AppColors.Accent) }
            Spacer(Modifier.height(22.u()))
            T("By creating an account, you accept our", 12f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center)
            Spacer(Modifier.height(3.u()))
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                T("Terms of Service", 12f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable(onClick = onTerms))
                T(" and ", 12f, FontWeight.Normal, p.textSecondary)
                T("Privacy Policy", 12f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable(onClick = onPrivacy))
            }
            Spacer(Modifier.height(20.u()))
        }
    }
}

@Composable
fun LoginScreen(onLoggedIn: (needsOtp: Boolean) -> Unit, onRegister: () -> Unit, onForgot: () -> Unit, onBack: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    var email by remember { mutableStateOf(Session.email) }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val valid = email.contains("@") && email.contains(".") && pass.isNotBlank()
    val scope = rememberCoroutineScope()
    LaunchedEffect(busy) {
        if (busy) {
            if (!Network.isOnline(ctx)) { busy = false; AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); return@LaunchedEffect }
            val o = AuthFlow.login(ctx, email, pass)
            busy = false
            when (o) {
                is LoginOutcome.Ok -> {
                    if (Session.blocked) {
                        val st = Session.accountStatus
                        AuthFlow.logout(ctx)
                        AppGate.showBlocked(st)
                    } else onLoggedIn(false)
                }
                is LoginOutcome.NeedOtp -> onLoggedIn(true)
                is LoginOutcome.Blocked -> AppGate.showBlocked(o.status, o.message)
                is LoginOutcome.Fail -> AppToast.error(o.message)
            }
        }
    }
    AuthFrame("Login", "Welcome back! Sign in to your PlugBill wallet.", onBack) {
        FieldLabel("Email address")
        PBField(email, { email = it }, "you@example.com", keyboard = KeyboardType.Email, icon = AppIcons.Mail)
        Spacer(Modifier.height(16.u()))
        FieldLabel("Password")
        PBField(pass, { pass = it }, "Enter your password", password = true, icon = AppIcons.Lock)
        Spacer(Modifier.height(12.u()))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            T("Forgot password?", 12.5f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable(onClick = onForgot))
        }
        Spacer(Modifier.height(24.u()))
        PrimaryButton("Sign In", enabled = valid && !busy, loading = busy, blockedMessage = "Enter a valid email address and your password") { busy = true }
        Spacer(Modifier.height(22.u()))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            T("New to PlugBill? ", 13f, FontWeight.Normal, pal().textSecondary)
            T("Create account", 13f, FontWeight.Bold, AppColors.Accent, Modifier.pressable(onClick = onRegister))
        }
    }
}

@Composable
fun RegisterScreen(onBack: () -> Unit, onNext: () -> Unit, onLogin: () -> Unit) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    var first by rememberSaveable { mutableStateOf("") }
    var last by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val back: () -> Unit = { if (step > 0) step-- else onBack() }
    androidx.activity.compose.BackHandler(enabled = step > 0) { step-- }

    LaunchedEffect(busy) {
        if (busy) {
            if (!Network.isOnline(ctx)) { busy = false; AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); return@LaunchedEffect }
            val v = AuthAPI.validateRegistration(email.trim(), phone.trim(), null)
            if (!v.success) { busy = false; AppToast.error(v.message); return@LaunchedEffect }
            val o = AuthAPI.sendOtp(email.trim(), "email_verification")
            busy = false
            if (o.success) { AppToast.success("A 6-digit code has been sent to ${email.trim()}"); step = 3 } else AppToast.error(o.message)
        }
    }

    val title = when (step) { 0 -> "Create account"; 1 -> "Phone number"; 2 -> "Set a password"; else -> "Verify your email" }
    val subtitle = when (step) {
        0 -> "Tell us who you are to get started."
        1 -> "Enter your 11-digit phone number."
        2 -> "Choose a strong password to protect your wallet."
        else -> "We sent a 6-digit code to\n$email."
    }
    AuthFrame(title, subtitle, back, step = step) {
        androidx.compose.animation.AnimatedContent(
            targetState = step,
            transitionSpec = {
                val fwd = targetState > initialState
                (androidx.compose.animation.slideInHorizontally(tween(320)) { if (fwd) it / 3 else -it / 3 } + androidx.compose.animation.fadeIn(tween(280))) togetherWith
                    (androidx.compose.animation.slideOutHorizontally(tween(260)) { if (fwd) -it / 3 else it / 3 } + androidx.compose.animation.fadeOut(tween(160)))
            },
            label = "regStep"
        ) { st ->
            Column(Modifier.fillMaxWidth()) {
                when (st) {
                    0 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.u())) {
                            Column(Modifier.weight(1f)) { FieldLabel("First name"); PBField(first, { first = it }, "John", icon = null) }
                            Column(Modifier.weight(1f)) { FieldLabel("Last name"); PBField(last, { last = it }, "Doe", icon = null) }
                        }
                        Spacer(Modifier.height(16.u()))
                        FieldLabel("Email address")
                        PBField(email, { email = it }, "you@example.com", keyboard = KeyboardType.Email, icon = AppIcons.Mail)
                        Spacer(Modifier.height(28.u()))
                        PrimaryButton(
                            "Continue",
                            enabled = first.isNotBlank() && last.isNotBlank() && email.contains("@") && email.contains("."),
                            blockedMessage = if (first.isBlank() || last.isBlank()) "Enter your first and last name" else "Enter a valid email address"
                        ) { step = 1 }
                        Spacer(Modifier.height(20.u()))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            T("Already have an account? ", 13f, FontWeight.Normal, pal().textSecondary)
                            T("Sign in", 13f, FontWeight.Bold, AppColors.Accent, Modifier.pressable(onClick = onLogin))
                        }
                    }
                    1 -> {
                        FieldLabel("Phone number")
                        PBField(phone, { phone = it.filter(Char::isDigit).take(11) }, "08012345678", keyboard = KeyboardType.Phone, maxLen = 11, icon = AppIcons.Phone)
                        Spacer(Modifier.height(8.u()))
                        T("${phone.length}/11 digits", 11.5f, FontWeight.Medium, pal().textSecondary, Modifier.padding(start = 4.u()))
                        Spacer(Modifier.height(24.u()))
                        PrimaryButton("Continue", enabled = phone.length == 11, blockedMessage = "Enter your 11-digit phone number") { step = 2 }
                    }
                    2 -> {
                        val rules = listOf(
                            "At least 8 characters" to (pass.length >= 8),
                            "An uppercase letter" to pass.any { it.isUpperCase() },
                            "A lowercase letter" to pass.any { it.isLowerCase() },
                            "A number" to pass.any { it.isDigit() }
                        )
                        val strong = rules.all { it.second }
                        FieldLabel("Password")
                        PBField(pass, { pass = it }, "Create a password", password = true, icon = AppIcons.Lock)
                        Spacer(Modifier.height(14.u()))
                        FieldLabel("Confirm password")
                        PBField(confirm, { confirm = it }, "Repeat password", password = true, icon = AppIcons.Lock)
                        Spacer(Modifier.height(16.u()))
                        rules.forEach { (label, ok) ->
                            Row(Modifier.padding(vertical = 3.u()), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(18.u()).background(if (ok) AppColors.Accent else pal().divider, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { if (ok) SvgIcon(AppIcons.Check, 11.u(), Color.White, 3f) }
                                Spacer(Modifier.width(10.u()))
                                T(label, 12.5f, FontWeight.Medium, if (ok) pal().text else pal().textSecondary)
                            }
                        }
                        Spacer(Modifier.height(26.u()))
                        PrimaryButton("Continue", enabled = strong && pass == confirm, loading = busy,
                            blockedMessage = if (!strong) "Your password doesn't meet all the rules yet" else "Passwords do not match") { busy = true }
                    }
                    else -> OtpBody(
                        email = email.trim(), type = "email_verification",
                        onVerified = {
                            // the account itself is created at the end of PIN creation (register.php needs the PIN)
                            PendingReg.set(first, last, email, phone, pass)
                            Session.email = email.trim()
                            onNext()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ForgotScreen(onBack: () -> Unit, onNext: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    LaunchedEffect(busy) {
        if (busy) {
            if (!Network.isOnline(ctx)) { busy = false; AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); return@LaunchedEffect }
            val r = AuthAPI.forgotPassword(email.trim())
            busy = false
            if (r.success) { Session.email = email.trim(); AppToast.success("Reset code sent to ${email.trim()}"); onNext() } else AppToast.error(r.message)
        }
    }
    AuthFrame("Forgot password?", "Enter your email and we'll send a 6-digit code to reset it.", onBack) {
        FieldLabel("Email address")
        PBField(email, { email = it }, "you@example.com", keyboard = KeyboardType.Email, icon = AppIcons.Mail)
        Spacer(Modifier.height(24.u()))
        PrimaryButton("Send code", enabled = email.contains("@"), loading = busy, blockedMessage = "Enter a valid email address") { busy = true }
    }
}

@Composable
fun ResetScreen(onBack: () -> Unit, onDone: () -> Unit) {
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    LaunchedEffect(busy) {
        if (busy) {
            if (!Network.isOnline(ctx)) { busy = false; AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); return@LaunchedEffect }
            val r = AuthAPI.resetPassword(Session.email, AuthFlow.resetOtp, AuthFlow.resetToken, pass)
            busy = false
            if (r.success) { AuthFlow.resetToken = ""; AuthFlow.resetOtp = ""; onDone() } else AppToast.error(r.message)
        }
    }
    AuthFrame("New password", "Choose a strong password you haven't used before.", onBack) {
        FieldLabel("New password")
        PBField(pass, { pass = it }, "At least 6 characters", password = true, icon = AppIcons.Lock)
        Spacer(Modifier.height(14.u()))
        FieldLabel("Confirm password")
        PBField(confirm, { confirm = it }, "Repeat password", password = true, icon = AppIcons.Lock)
        Spacer(Modifier.height(24.u()))
        PrimaryButton("Update password", enabled = pass.length >= 6 && pass == confirm, loading = busy,
            blockedMessage = if (pass.length < 6) "Password must be at least 6 characters" else "Passwords do not match") { busy = true }
    }
}

/** 6-digit OTP, verified by the server (auth/verify-otp.php). */
@Composable
fun OtpScreen(destination: String, type: String, onBack: () -> Unit, onVerified: () -> Unit) {
    AuthFrame("Verify it's you", "We sent a 6-digit code to\n$destination.", onBack) {
        OtpBody(destination, type, onVerified)
    }
}

/** The OTP boxes, verify button and resend timer (shared by login/reset and the registration flow). */
@Composable
private fun OtpBody(email: String, type: String, onVerified: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    var code by remember { mutableStateOf("") }
    var left by remember { mutableIntStateOf(30) }
    var busy by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(left) { if (left > 0) { delay(1000); left-- } }
    LaunchedEffect(code) {
        if (code.length == 6 && !busy) {
            busy = true
            if (!Network.isOnline(ctx)) { busy = false; AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); return@LaunchedEffect }
            val (ok, msg) = AuthFlow.verifyOtp(ctx, email, code, type)
            busy = false
            if (ok) { Haptics.tick(ctx); onVerified() } else { Haptics.reject(ctx); AppToast.error(msg); code = "" }
        }
    }
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.u())) {
            repeat(6) { i ->
                val active = i == code.length
                val shape = RoundedCornerShape(16.u())
                Box(
                    Modifier.weight(1f).height(60.u())
                        .softShadow(shape, p.shadow, 10.u(), 0.dp, 3.u())
                        .background(p.surface, shape)
                        .border(1.5.dp, if (active || i < code.length) AppColors.Accent else Color.Transparent, shape),
                    contentAlignment = Alignment.Center
                ) { T(code.getOrNull(i)?.toString() ?: "", 22f, FontWeight.Bold) }
            }
        }
        // hidden field drives the boxes
        BasicTextField(
            value = code,
            onValueChange = { v -> if (v.length <= 6 && v.all(Char::isDigit)) code = v },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            textStyle = TextStyle(color = Color.Transparent),
            cursorBrush = SolidColor(Color.Transparent),
            modifier = Modifier.fillMaxWidth().height(56.u()).alpha(0.01f).focusRequester(focus)
        )
    }
    Spacer(Modifier.height(26.u()))
    PrimaryButton("Verify", enabled = code.length == 6, loading = busy, blockedMessage = "Enter the 6-digit code we sent you") { }
    Spacer(Modifier.height(20.u()))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        if (left > 0) T("Resend code in ${left}s", 13f, FontWeight.Medium, p.textSecondary)
        else T("Resend code", 13f, FontWeight.Bold, AppColors.Accent, Modifier.pressable {
            left = 30
            scope.launch {
                val r = AuthAPI.sendOtp(email, type)
                if (r.success) AppToast.success("A new code was sent to $email") else AppToast.error(r.message)
            }
        })
    }
}

@Composable
fun SuccessScreen(title: String, subtitle: String, button: String, onContinue: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Haptics.success(ctx) }
    Box(Modifier.fillMaxSize().authBackground().elastic().statusBarsPadding().navigationBarsPadding()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 21.u()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            SuccessLottie(180)
            Spacer(Modifier.height(10.u()))
            T(title, 24f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(8.u()))
            T(subtitle, 13.5f, FontWeight.Normal, pal().textSecondary, align = TextAlign.Center, lineHeight = 13.5f * 1.4f)
        }
        PrimaryButton(button, Modifier.align(Alignment.BottomCenter).padding(24.u()), onClick = onContinue)
    }
}

/**
 * 4-digit passcode keypad. mode: "create" (enter + confirm), "verify" (unlock).
 * Fingerprint button is shown on verify when biometrics are enabled.
 */
@Composable
fun PasscodeScreen(mode: String, onBack: (() -> Unit)?, onSuccess: () -> Unit, onSkip: (() -> Unit)? = null, onFail: (() -> Unit)? = null, onLogout: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val p = pal()
    var first by remember { mutableStateOf<String?>(null) }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val pin = mode == "pin"
    val create = mode == "create" || pin
    val bioOk = !create && Session.biometricEnabled && Biometrics.available(ctx)
    var saving by remember { mutableStateOf(false) }
    var askLogout by remember { mutableStateOf(false) }
    LoadingEffect(saving)

    fun fingerprint() = Biometrics.prompt(ctx, "Unlock PlugBill", "Confirm your fingerprint") { if (it) onSuccess() }
    LaunchedEffect(Unit) { if (bioOk) fingerprint() }

    LaunchedEffect(code) {
        if (code.length == 4) {
            delay(150)
            if (create) {
                if (first == null) { first = code; code = ""; error = null }
                else if (first == code) {
                    if (!Network.isOnline(ctx)) { AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); first = null; code = ""; return@LaunchedEffect }
                    saving = true
                    val (ok, msg) = if (pin && PendingReg.active) PendingReg.submit(ctx, code)
                        else if (pin) AuthFlow.setPin(ctx, code) else AuthFlow.setPasscode(ctx, code)
                    saving = false
                    if (ok) { Haptics.success(ctx); onSuccess() }
                    else { Haptics.reject(ctx); AppToast.error(msg); first = null; code = ""; if (pin && PendingReg.active) { PendingReg.clear(); onFail?.invoke() } }
                }
                else { Haptics.reject(ctx); AppToast.error("Passcodes don't match. Try again."); first = null; code = "" }
            } else {
                saving = true
                val (ok, msg) = AuthFlow.verifyPasscode(ctx, code)
                saving = false
                if (ok) { Haptics.tick(ctx); onSuccess() }
                else { Haptics.reject(ctx); AppToast.error(msg.ifBlank { "Wrong passcode" }); code = "" }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().authBackground().elastic().statusBarsPadding().navigationBarsPadding().padding(horizontal = 21.u()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 20.u()), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) FloatSurface(Modifier.size(52.u()), RoundedCornerShape(18.u()), onBack) { SvgIcon(AppIcons.Back, 22.u(), p.text, 2f) }
            else Spacer(Modifier.size(52.u()))
            Spacer(Modifier.weight(1f))
            if (onSkip != null) T("Skip", 14f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable(onClick = onSkip))
        }
        Spacer(Modifier.height(24.u()))
        AppLogo(size = 60)
        Spacer(Modifier.height(18.u()))
        T(
            if (pin) (if (first == null) "Create transaction PIN" else "Confirm transaction PIN")
            else if (!create) "Enter passcode" else if (first == null) "Create passcode" else "Confirm passcode",
            22f, FontWeight.Bold
        )
        Spacer(Modifier.height(6.u()))
        T(
            if (pin) "This 4-digit PIN authorizes every purchase" else if (!create) "Unlock ${Session.firstName.ifBlank { "your wallet" }}" else "Protect your wallet with a 4-digit code",
            13f, FontWeight.Normal, p.textSecondary
        )
        Spacer(Modifier.height(28.u()))
        Row(horizontalArrangement = Arrangement.spacedBy(16.u())) {
            repeat(4) { i ->
                Box(
                    Modifier.size(16.u())
                        .background(if (i < code.length) AppColors.Accent else Color.Transparent, CircleShape)
                        .border(2.dp, if (i < code.length) AppColors.Accent else p.divider, CircleShape)
                )
            }
        }
        Spacer(Modifier.height(14.u()))
        Spacer(Modifier.height(18.u()))
        Spacer(Modifier.weight(1f))
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", if (bioOk) "bio" else "", "0", "del")
        Column(verticalArrangement = Arrangement.spacedBy(14.u())) {
            keys.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(22.u())) {
                    row.forEach { k ->
                        Box(Modifier.size(74.u()), contentAlignment = Alignment.Center) {
                            when (k) {
                                "" -> {}
                                "bio" -> Box(Modifier.size(74.u()).pressable { fingerprint() }, contentAlignment = Alignment.Center) {
                                    SvgIcon(AppIcons.Fingerprint, 30.u(), AppColors.Accent, 1.8f)
                                }
                                "del" -> Box(Modifier.size(74.u()).pressable { if (code.isNotEmpty()) code = code.dropLast(1) }, contentAlignment = Alignment.Center) {
                                    SvgIcon(AppIcons.Close, 26.u(), p.text, 2f)
                                }
                                else -> FloatSurface(Modifier.size(74.u()), CircleShape, {
                                    if (code.length < 4 && !saving) { code += k; error = null; Haptics.tick(ctx) }
                                }) { T(k, 24f, FontWeight.SemiBold) }
                            }
                        }
                    }
                }
            }
        }
        if (!create && onLogout != null) {
            Spacer(Modifier.height(6.u()))
            T("Forgot passcode? Log out", 13.5f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable(onClick = { askLogout = true }).padding(horizontal = 16.u(), vertical = 10.u()))
        }
        Spacer(Modifier.height(22.u()))
    }
    AppAlertDialog(
        visible = askLogout,
        title = "Log out?",
        message = "You will be signed out and the passcode and fingerprint saved on this phone will be cleared. Log in again, then set a new passcode in Security.",
        icon = AppIcons.Logout, tone = AlertTone.Warning,
        primary = "Stay", onPrimary = { askLogout = false },
        secondary = "Log out", onSecondary = { askLogout = false; onLogout?.invoke() },
        dismissible = true, onDismiss = { askLogout = false }
    )
}

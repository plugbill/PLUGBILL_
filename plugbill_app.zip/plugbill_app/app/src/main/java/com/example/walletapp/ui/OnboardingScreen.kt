package com.example.walletapp.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.abs

private data class OnboardPage(
    val icon: List<Seg>, val small1: List<Seg>, val small2: List<Seg>,
    val title: String, val text: String
)

private val pages = listOf(
    OnboardPage(
        AppIcons.Bills, AppIcons.Airtime, AppIcons.Tv,
        "Pay bills in seconds",
        "Airtime, data, electricity and TV subscriptions, all from one simple wallet."
    ),
    OnboardPage(
        AppIcons.WalletIn, AppIcons.Bank, AppIcons.Check,
        "Fund your wallet instantly",
        "Get your own dedicated account number and top up by bank transfer with zero charges."
    ),
    OnboardPage(
        AppIcons.Shield, AppIcons.Lock, AppIcons.Gift,
        "Safe, secure and rewarding",
        "Protect every payment with a passcode and fingerprint, and earn bonuses when friends join."
    )
)

/** Three-step welcome shown the first time the app is opened. */
@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val p = pal()
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val last = state.currentPage == pages.size - 1

    Box(Modifier.fillMaxSize().background(screenBackground())) {
        Column(Modifier.fillMaxSize().elastic().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 21.u(), vertical = 20.u()), horizontalArrangement = Arrangement.End) {
                Box(Modifier.height(52.u()), contentAlignment = Alignment.CenterEnd) {
                    if (!last) T("Skip", 14f, FontWeight.SemiBold, p.textSecondary, Modifier.pressable(onClick = onDone).padding(8.u()))
                }
            }
            HorizontalPager(state, Modifier.weight(1f).fillMaxWidth()) { page ->
                val offset = abs(state.currentPage - page + state.currentPageOffsetFraction).coerceIn(0f, 1f)
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 28.u()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(Modifier.scale(1f - 0.15f * offset).alpha(1f - offset)) { Illustration(pages[page]) }
                    Spacer(Modifier.height(40.u()))
                    Column(Modifier.alpha(1f - offset), horizontalAlignment = Alignment.CenterHorizontally) {
                        T(pages[page].title, 26f, FontWeight.Bold, align = TextAlign.Center)
                        Spacer(Modifier.height(12.u()))
                        T(pages[page].text, 14f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 14f * 1.5f)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 18.u()), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(pages.size) { i ->
                    val active = state.currentPage == i
                    val w by animateDpAsState(if (active) 26.u() else 8.u(), tween(260), label = "dotW")
                    Box(
                        Modifier.padding(horizontal = 4.u()).height(8.u()).width(w)
                            .background(if (active) AppColors.Accent else p.divider, CircleShape)
                    )
                }
            }
            Box(Modifier.padding(horizontal = 21.u()).padding(bottom = 24.u())) {
                PrimaryButton(if (last) "Get started" else "Next") {
                    if (last) onDone() else scope.launch { state.animateScrollToPage(state.currentPage + 1) }
                }
            }
        }
    }
}

@Composable
private fun Illustration(page: OnboardPage) {
    val t = rememberInfiniteTransition(label = "float")
    val bobF by t.animateFloat(-7f, 7f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "bob")
    val bob2F by t.animateFloat(6f, -6f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "bob2")
    val bob = bobF.dp
    val bob2 = bob2F.dp
    Box(Modifier.size(270.u()), contentAlignment = Alignment.Center) {
        Box(Modifier.size(270.u()).background(AppColors.Accent.copy(alpha = 0.07f), CircleShape))
        Box(Modifier.size(200.u()).background(AppColors.Accent.copy(alpha = 0.12f), CircleShape))
        Box(Modifier.offset(y = bob)) { GreenIcon(page.icon, 120, 60) }
        Box(Modifier.align(Alignment.TopEnd).padding(top = 26.u(), end = 20.u()).offset(y = bob2)) { GreenIcon(page.small1, 52, 26) }
        Box(Modifier.align(Alignment.BottomStart).padding(bottom = 30.u(), start = 16.u()).offset(y = bob)) { GreenIcon(page.small2, 46, 23) }
    }
}

package com.example.walletapp.ui

import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Payment PIN gate. Call-site:  if (needPin) PayPinFlow(onVerified = { ... }, onCancel = { needPin = false })
 * - no PIN yet  -> "set up your payment PIN" dialog -> create + confirm -> onVerified
 * - PIN exists  -> enter PIN (or fingerprint when enabled) -> onVerified
 */
@Composable
fun PayPinFlow(onVerified: (String) -> Unit, onCancel: () -> Unit) {
    var stage by remember { mutableStateOf(if (Session.hasPayPin) 2 else 0) } // 0 setup prompt, 1 create, 2 verify
    when (stage) {
        0 -> PinSetupDialog(onCreate = { stage = 1 }, onCancel = onCancel)
        1 -> PinSheet(create = true, onDone = onVerified, onDismiss = onCancel)
        else -> PinSheet(create = false, onDone = onVerified, onDismiss = onCancel)
    }
}

@Composable
private fun PinSetupDialog(onCreate: () -> Unit, onCancel: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(30.u())
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onCancel() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(horizontal = 28.u()).fillMaxWidth()
                .softShadow(shape, Color(0x55000000), 34.u(), 0.dp, 14.u())
                .background(p.surface, shape).then(noRipple)
                .border(1.dp, p.divider.copy(alpha = 0.5f), shape)
                .padding(24.u()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GreenIcon(AppIcons.Shield, 64, 32)
            Spacer(Modifier.height(18.u()))
            T("Set up your payment PIN", 20f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(8.u()))
            T(
                "Create a 4-digit PIN to authorize every purchase. You can also use your fingerprint once it is enabled in Security.",
                13f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 13f * 1.45f
            )
            Spacer(Modifier.height(22.u()))
            PrimaryButton("Create payment PIN", onClick = onCreate)
            Spacer(Modifier.height(6.u()))
            T("Not now", 14f, FontWeight.SemiBold, p.textSecondary, Modifier.pressable(onClick = onCancel).padding(12.u()))
        }
    }
}

@Composable
private fun PinSheet(create: Boolean, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val scope = rememberCoroutineScope()
    var vis by remember { mutableStateOf(false) }
    var first by remember { mutableStateOf<String?>(null) }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    // the fingerprint key is always offered when the phone has a fingerprint enrolled
    val bioOk = !create && Biometrics.available(ctx)
    val bioReady = Session.storedPin() != null   // the fingerprint prompt opens by itself as soon as the PIN sheet shows

    fun close(then: () -> Unit) { vis = false; scope.launch { delay(240); then() } }
    fun fingerprint() {
        if (Session.storedPin() == null) { AppToast.info("Enter your PIN once. After that, your fingerprint will confirm payments."); return }
        Biometrics.prompt(ctx, "Confirm payment", "Touch the sensor to authorize") { ok ->
            if (ok) {
                // fingerprint releases the PIN kept encrypted on this device; the server still checks it on the purchase
                val saved = Session.storedPin()
                if (saved != null) { Session.biometricEnabled = true; Session.save(ctx); close { onDone(saved) } }
            }
        }
    }

    LaunchedEffect(Unit) { vis = true }
    LaunchedEffect(Unit) { if (bioOk && bioReady) { delay(450); fingerprint() } }
    LaunchedEffect(code) {
        if (code.length == 4) {
            delay(120)
            if (create) {
                if (first == null) { first = code; code = ""; error = null }
                else if (first == code) {
                    if (!Network.isOnline(ctx)) { AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK); first = null; code = ""; return@LaunchedEffect }
                    val (ok, msg) = com.example.walletapp.data.AuthFlow.setPin(ctx, code)
                    if (ok) { val pinNow = code; Haptics.success(ctx); close { onDone(pinNow) } }
                    else { Haptics.reject(ctx); AppToast.error(msg); first = null; code = "" }
                }
                else { Haptics.reject(ctx); AppToast.error("PINs don't match. Try again."); first = null; code = "" }
            } else {
                // the server validates the PIN on the purchase itself (same as the web PinModal)
                val pinNow = code; Haptics.tick(ctx); close { onDone(pinNow) }
            }
        }
    }

    GlassSheet(visible = vis, onDismiss = { close(onDismiss) }) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            GreenIcon(AppIcons.Lock, 52, 26)
            Spacer(Modifier.height(12.u()))
            T(
                if (!create) "Enter payment PIN" else if (first == null) "Create payment PIN" else "Confirm payment PIN",
                20f, FontWeight.Bold
            )
            Spacer(Modifier.height(4.u()))
            T(
                if (!create) "Authorize this purchase" else "Choose a 4-digit PIN for your purchases",
                12.5f, FontWeight.Normal, p.textSecondary
            )
            Spacer(Modifier.height(20.u()))
            Row(horizontalArrangement = Arrangement.spacedBy(16.u())) {
                repeat(4) { i ->
                    Box(
                        Modifier.size(16.u())
                            .background(if (i < code.length) AppColors.Accent else Color.Transparent, CircleShape)
                            .border(2.dp, if (i < code.length) AppColors.Accent else p.divider, CircleShape)
                    )
                }
            }
            Spacer(Modifier.height(10.u()))
            Spacer(Modifier.height(18.u()))
            Spacer(Modifier.height(10.u()))
            PinKeypad(
                onDigit = { k -> if (code.length < 4) { code += k; error = null; Haptics.tick(ctx) } },
                onDelete = { if (code.isNotEmpty()) code = code.dropLast(1) },
                bio = bioOk, onBio = { fingerprint() }
            )
            Spacer(Modifier.height(10.u()))
            T("Cancel", 14f, FontWeight.SemiBold, p.textSecondary, Modifier.pressable { close(onDismiss) }.padding(10.u()))
        }
    }
}

/** Shown on the dashboard after registration: set up passcode + fingerprint. */
@Composable
fun SecurityPromptDialog(onEnable: () -> Unit, onLater: () -> Unit) {
    val p = pal()
    val ctx = LocalContext.current
    val bio = remember { Biometrics.available(ctx) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val sc by androidx.compose.animation.core.animateFloatAsState(
        if (shown) 1f else 0.88f, androidx.compose.animation.core.spring(0.65f, androidx.compose.animation.core.Spring.StiffnessMediumLow), label = "sc"
    )
    val al by androidx.compose.animation.core.animateFloatAsState(if (shown) 1f else 0f, androidx.compose.animation.core.tween(220), label = "al")
    val shape = RoundedCornerShape(30.u())
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f * al)).then(noRipple), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(horizontal = 28.u()).fillMaxWidth()
                .androidx_scale(sc, al)
                .softShadow(shape, Color(0x55000000), 34.u(), 0.dp, 14.u())
                .background(p.surface, shape)
                .border(1.dp, p.divider.copy(alpha = 0.5f), shape)
                .padding(24.u()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GreenIcon(AppIcons.Shield, 64, 32)
            Spacer(Modifier.height(18.u()))
            T("Secure your wallet", 20f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(8.u()))
            T("Lock PlugBill every time it opens so only you can get in.", 13f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 13f * 1.45f)
            Spacer(Modifier.height(18.u()))
            SecPoint(AppIcons.Lock, "4-digit passcode", "Asked when the app opens")
            if (bio) {
                Spacer(Modifier.height(10.u()))
                SecPoint(AppIcons.Fingerprint, "Fingerprint unlock", "Open the app with a touch")
            }
            Spacer(Modifier.height(22.u()))
            PrimaryButton("Set up passcode", onClick = onEnable)
            Spacer(Modifier.height(6.u()))
            T("Maybe later", 14f, FontWeight.SemiBold, p.textSecondary, Modifier.pressable(onClick = onLater).padding(12.u()))
        }
    }
}

private fun Modifier.androidx_scale(s: Float, a: Float): Modifier =
    this.graphicsLayer { scaleX = s; scaleY = s; alpha = a }

@Composable
private fun SecPoint(icon: List<Seg>, title: String, sub: String) {
    val p = pal()
    Row(
        Modifier.fillMaxWidth().background(AppColors.Accent.copy(alpha = 0.10f), RoundedCornerShape(16.u())).padding(12.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GreenIcon(icon, 36, 18)
        Spacer(Modifier.width(12.u()))
        Column {
            T(title, 13.5f, FontWeight.Bold)
            T(sub, 11.5f, FontWeight.Normal, p.textSecondary)
        }
    }
}

@Composable
fun CreatePinSheet(onDone: () -> Unit, onDismiss: () -> Unit) = PinSheet(create = true, onDone = { onDone() }, onDismiss = onDismiss)

@Composable
fun PinKeypad(onDigit: (String) -> Unit, onDelete: () -> Unit, bio: Boolean = false, onBio: () -> Unit = {}) {
    val p = pal()
    val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", if (bio) "bio" else "", "0", "del")
    Column(verticalArrangement = Arrangement.spacedBy(12.u())) {
        keys.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.u())) {
                row.forEach { k ->
                    Box(Modifier.size(66.u()), contentAlignment = Alignment.Center) {
                        when (k) {
                            "" -> {}
                            "bio" -> Box(Modifier.size(66.u()).pressable { onBio() }, contentAlignment = Alignment.Center) {
                                SvgIcon(AppIcons.Fingerprint, 30.u(), AppColors.Accent, 1.8f)
                            }
                            "del" -> Box(Modifier.size(66.u()).pressable { onDelete() }, contentAlignment = Alignment.Center) {
                                SvgIcon(AppIcons.Close, 24.u(), p.text, 2f)
                            }
                            else -> FloatSurface(Modifier.size(66.u()), CircleShape, { onDigit(k) }) { T(k, 23f, FontWeight.SemiBold) }
                        }
                    }
                }
            }
        }
    }
}

/** Asks for the current PIN/passcode, or the account password, before letting the user change it. */
@Composable
fun VerifyCodeSheet(kind: String, onVerified: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val scope = rememberCoroutineScope()
    val label = if (kind == "pin") "transaction PIN" else "passcode"
    var vis by remember { mutableStateOf(false) }
    var usePassword by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    fun close(then: () -> Unit) { vis = false; scope.launch { delay(240); then() } }
    LaunchedEffect(Unit) { vis = true }
    LaunchedEffect(code) {
        if (code.length == 4) {
            delay(120)
            val ok = if (kind == "pin") Session.checkPayPin(code) else com.example.walletapp.data.AuthFlow.verifyPasscode(ctx, code).first
            if (ok) { Haptics.tick(ctx); close(onVerified) }
            else { Haptics.reject(ctx); AppToast.error("Wrong $label. Try again."); code = "" }
        }
    }
    GlassSheet(visible = vis, onDismiss = { close(onCancel) }) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            GreenIcon(AppIcons.Shield, 52, 26)
            Spacer(Modifier.height(12.u()))
            T("Verify it's you", 20f, FontWeight.Bold)
            Spacer(Modifier.height(4.u()))
            T(if (usePassword) "Enter your account password" else "Enter your current $label", 12.5f, FontWeight.Normal, p.textSecondary)
            Spacer(Modifier.height(18.u()))
            if (!usePassword) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.u())) {
                    repeat(4) { i ->
                        Box(
                            Modifier.size(16.u())
                                .background(if (i < code.length) AppColors.Accent else Color.Transparent, CircleShape)
                                .border(2.dp, if (i < code.length) AppColors.Accent else p.divider, CircleShape)
                        )
                    }
                }
                Spacer(Modifier.height(10.u()))
                Spacer(Modifier.height(18.u()))
                Spacer(Modifier.height(10.u()))
                PinKeypad(
                    onDigit = { k -> if (code.length < 4) { code += k; error = null; Haptics.tick(ctx) } },
                    onDelete = { if (code.isNotEmpty()) code = code.dropLast(1) }
                )
            } else {
                PBField(pw, { pw = it; error = null }, "Account password", password = true, icon = AppIcons.Lock)
                Spacer(Modifier.height(24.u()))
                PrimaryButton("Verify", enabled = pw.isNotBlank(), blockedMessage = "Enter your account password") {
                    if (Session.checkPassword(pw)) { Haptics.tick(ctx); close(onVerified) }
                    else { Haptics.reject(ctx); AppToast.error("Incorrect password") }
                }
            }
            Spacer(Modifier.height(12.u()))
            T(
                if (usePassword) "Use current $label instead" else "Use account password instead",
                13.5f, FontWeight.Bold, AppColors.Accent,
                Modifier.pressable { usePassword = !usePassword; error = null; code = ""; pw = "" }.padding(8.u())
            )
            T("Cancel", 14f, FontWeight.SemiBold, p.textSecondary, Modifier.pressable { close(onCancel) }.padding(8.u()))
        }
    }
}

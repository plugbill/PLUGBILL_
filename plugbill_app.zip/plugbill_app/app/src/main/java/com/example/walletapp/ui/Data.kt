package com.example.walletapp.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import com.example.walletapp.R
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class Kind { Airtime, Data, Electricity, Tv, Funding }

data class Tx(
    val kind: Kind,
    val title: String,
    val detail: String,
    val day: String,
    val shortDate: String,
    val time: String,
    val amount: String,
    val incoming: Boolean,
    /** Network / brand logo (drawable res id). Null = fall back to the line icon. */
    val logo: Int? = null,
    val reference: String = "",
    val service: String = "",
    val recipient: String = "",
    val status: String = "SUCCESSFUL",
    val customer: String? = null,
    val packageName: String? = null,
    val token: String? = null,
    val units: String? = null,
    /** Money received from another person (shows the "receive" icon instead of the wallet-funding one). */
    val received: Boolean = false
)

fun Kind.icon(): List<Seg> = when (this) {
    Kind.Airtime -> AppIcons.Airtime
    Kind.Data -> AppIcons.Data
    Kind.Electricity -> AppIcons.Electricity
    Kind.Tv -> AppIcons.Tv
    Kind.Funding -> AppIcons.WalletIn
}

/** Maps a provider name to its logo. Add new networks here. */
object Logos {
    val Glo = R.drawable.net_glo
    val Airtel = R.drawable.net_airtel
    val Mtn = R.drawable.net_mtn
    val NineMobile = R.drawable.net_9mobile
    val StarTimes = R.drawable.net_startimes
    val GoTv = R.drawable.net_gotv
    val DsTv = R.drawable.net_dstv
    val PlugBill = R.drawable.plugbill_logo

    fun forName(name: String): Int? {
        val n = name.lowercase()
        return when {
            "glo" in n -> Glo
            "airtel" in n -> Airtel
            "mtn" in n -> Mtn
            "9mobile" in n || "etisalat" in n -> NineMobile
            "startimes" in n -> StarTimes
            "gotv" in n -> GoTv
            "dstv" in n -> DsTv
            "plugbill" in n -> PlugBill
            else -> null
        }
    }
}


/** Live transaction list, filled from wallet/history.php (newest first). Nothing is stored locally. */
object TxStore {
    val items = mutableStateListOf<Tx>()
    var page = 1
    var hasMore by androidx.compose.runtime.mutableStateOf(false)
    var loadingMore by androidx.compose.runtime.mutableStateOf(false)
    fun add(tx: Tx) { items.removeAll { it.reference == tx.reference }; items.add(0, tx) }
    fun replace(list: List<Tx>, hasMoreNow: Boolean) { items.clear(); items.addAll(list); page = 1; hasMore = hasMoreNow }
    fun append(list: List<Tx>, pageNo: Int, hasMoreNow: Boolean) {
        list.forEach { n -> if (items.none { it.reference == n.reference }) items.add(n) }
        page = pageNo; hasMore = hasMoreNow
    }
    fun clear() { items.clear(); page = 1; hasMore = false }
}

val allTx: List<Tx> get() = TxStore.items

private fun d(o: JSONObject, k: String): Double = if (o.isNull(k)) 0.0 else when (val v = o.opt(k)) { is Number -> v.toDouble(); is String -> v.toDoubleOrNull() ?: 0.0; else -> 0.0 }
private fun s(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.opt(k)?.toString() ?: ""

/** Maps one row of wallet/history.php (or a purchase response `transaction`) to the UI model. Same credit/status rules as api.ts. */
object TxMapper {
    fun fromJson(o: JSONObject): Tx {
        val stype = s(o, "service_type").lowercase()
        val credit = s(o, "transaction_type") == "credit" || stype == "wallet_funding" || stype == "fund" || s(o, "type") == "funding" || s(o, "type") == "credit"
        val net = s(o, "network").ifBlank { s(o, "provider").takeIf { it != "PlugBill" } ?: "" }
        val netName = when (net.lowercase()) { "mtn" -> "MTN"; "airtel" -> "Airtel"; "glo" -> "Glo"; "9mobile" -> "9mobile"; else -> net.uppercase() }
        val pkg = s(o, "package").ifBlank { s(o, "package_name") }
        val meta = o.optJSONObject("metadata")
        val kind = when {
            credit -> Kind.Funding
            stype.contains("airtime") -> Kind.Airtime
            stype == "data" || stype.contains("data") -> Kind.Data
            stype.contains("electric") -> Kind.Electricity
            stype.contains("cable") || stype.contains("tv") -> Kind.Tv
            else -> Kind.Airtime
        }
        val provName = meta?.let { s(it, "provider").takeIf { x -> x.isNotBlank() && x != "PlugBill" } } ?: ""
        val title = when {
            credit -> "Wallet Funded"
            kind == Kind.Airtime -> "$netName Airtime Top-up"
            kind == Kind.Data -> "$netName $pkg Data Plan".replace("  ", " ").trim()
            kind == Kind.Electricity -> (s(o, "network").ifBlank { provName }.uppercase() + " Electricity Token").trim()
            kind == Kind.Tv -> (pkg.ifBlank { s(o, "network").uppercase() } + " Subscription").trim()
            else -> s(o, "description").ifBlank { "Bill Payment" }
        }
        val recipient = s(o, "phone_number").ifBlank { s(o, "meter_number") }.ifBlank { s(o, "account_number") }.ifBlank { if (credit) "PlugBill Wallet" else "" }
        val created = s(o, "created_at")
        val dt = try { LocalDateTime.parse(created.replace(' ', 'T')) } catch (_: Exception) { LocalDateTime.now() }
        val en = Locale.ENGLISH
        val statusRaw = s(o, "status").lowercase()
        val status = when (statusRaw) { "successful", "success", "completed" -> "SUCCESSFUL"; "processing", "pending" -> "PENDING"; "failed", "reversed" -> "FAILED"; "" -> "SUCCESSFUL"; else -> statusRaw.uppercase() }
        val ref = s(o, "transaction_reference").ifBlank { s(o, "reference") }.ifBlank { "PB" + s(o, "id") }
        val token = (s(o, "token").ifBlank { meta?.let { s(it, "token") } ?: "" }).ifBlank { null }
        val units = (s(o, "units").ifBlank { meta?.let { s(it, "units") } ?: "" }).ifBlank { null }
        val serviceLabel = when (kind) {
            Kind.Funding -> "Wallet Funding"; Kind.Airtime -> "$netName Airtime"; Kind.Data -> "$netName Data"
            Kind.Electricity -> title.removeSuffix(" Token"); Kind.Tv -> title
        }
        return Tx(
            kind, title, if (credit) "Bank Transfer" else recipient,
            dt.format(DateTimeFormatter.ofPattern("yyyy MMMM dd", en)), dt.format(DateTimeFormatter.ofPattern("dd MMM yyyy", en)),
            dt.format(DateTimeFormatter.ofPattern("HH:mm")),
            String.format(Locale.US, "%,.2f", d(o, "amount")), credit,
            logo = if (credit) null else Logos.forName(net.ifBlank { pkg }),
            reference = ref, service = serviceLabel, recipient = recipient, status = status,
            customer = s(o, "customer_name").ifBlank { null }, packageName = pkg.ifBlank { null }, token = token, units = units
        )
    }
}

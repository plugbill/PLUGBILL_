package com.example.walletapp.ui

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class ToastKind { Error, Warning, Success, Info }

class ToastData(val id: Int, val message: String, val kind: ToastKind, val millis: Long)

/**
 * PlugBill's own drop-down toast (iOS style). Use it instead of Android Toasts and instead of red
 * text / red lines under inputs:
 *
 *   AppToast.error("Enter your phone number")
 *   AppToast.warning("Set a passcode first")
 *   AppToast.success("Account number copied")
 *   AppToast.info("Flights are coming soon")
 *
 * It drops from the top with a bounce, stays [millis] (3 s by default), then slides away.
 * Tap it or swipe it up to dismiss early. A new toast replaces the one on screen.
 */
object AppToast {
    var current by mutableStateOf<ToastData?>(null)
    private var seq = 0

    fun show(message: String, kind: ToastKind = ToastKind.Info, millis: Long = 3000L) {
        current = ToastData(++seq, message, kind, millis)
    }
    fun error(message: String, millis: Long = 3000L) = show(message, ToastKind.Error, millis)
    fun warning(message: String, millis: Long = 3000L) = show(message, ToastKind.Warning, millis)
    fun success(message: String, millis: Long = 3000L) = show(message, ToastKind.Success, millis)
    fun info(message: String, millis: Long = 3000L) = show(message, ToastKind.Info, millis)
    fun dismiss() { current = null }
}

private val ToastWarn = icon("M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z", "M12 9v4", "M12 17h.01")
private val ToastErr = icon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M15 9l-6 6", "M9 9l6 6")
private val ToastInfo = icon("M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M12 11v5", "M12 7.5h.01")
private val WifiOff = icon(
    "M1 1l22 22", "M16.72 11.06A10.94 10.94 0 0 1 19 12.55", "M5 12.55a10.94 10.94 0 0 1 5.17-2.39",
    "M10.71 5.05A16 16 0 0 1 22.58 9", "M1.42 9a15.91 15.91 0 0 1 4.7-2.88", "M8.53 16.11a6 6 0 0 1 6.95 0", "M12 20h.01"
)

private fun ToastKind.color() = when (this) {
    ToastKind.Error -> Color(0xFFFF5A5F)
    ToastKind.Warning -> Color(0xFFFFB020)
    ToastKind.Success -> Color(0xFF2ED47A)
    ToastKind.Info -> Color(0xFF5AA9FF)
}
private fun ToastKind.title() = when (this) {
    ToastKind.Error -> "Error"; ToastKind.Warning -> "Warning"; ToastKind.Success -> "Success"; ToastKind.Info -> "Notice"
}
private fun ToastKind.glyph() = when (this) {
    ToastKind.Error -> ToastErr; ToastKind.Warning -> ToastWarn; ToastKind.Success -> AppIcons.Check; ToastKind.Info -> ToastInfo
}

/**
 * Put once at the very top of the app (AppFrame does). [backdrop] is the recorded app content, which is
 * blurred thickly behind the toast so the glass looks real (Android 12+; older phones get solid dark glass).
 */
@Composable
fun ToastHost(backdrop: GraphicsLayer?) {
    val data = AppToast.current
    var last by remember { mutableStateOf(data) }
    if (data != null) last = data
    val shown = last

    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val hidden = with(density) { -240.dp.toPx() }
    val y = remember { Animatable(hidden) }
    val topPad = WindowInsets.statusBars.getTop(density).toFloat() + with(density) { 6.u().toPx() }
    val sidePad = with(density) { 16.u().toPx() }
    val blurred = rememberGraphicsLayer()
    val frosted = Build.VERSION.SDK_INT >= 31 && backdrop != null
    val dark = pal().dark
    val ink = if (dark) Color.White else Color(0xFF1C1C1E)

    LaunchedEffect(data?.id) {
        val d = data
        if (d == null) { y.animateTo(hidden, tween(260, easing = FastOutLinearInEasing)); last = null; return@LaunchedEffect }
        // drop in with a bounce (a replacing toast just gets a small nudge)
        if (y.value > hidden + 40f) y.snapTo(with(density) { -26.dp.toPx() }) else y.snapTo(hidden)
        y.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = 320f))
        delay(d.millis)
        y.animateTo(hidden, tween(300, easing = FastOutLinearInEasing))
        if (AppToast.current?.id == d.id) AppToast.current = null
    }

    if (shown != null) {
        val shape = RoundedCornerShape(26.u())
        val c = shown.kind.color()
        Box(
            Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.u(), start = 16.u(), end = 16.u())
                .graphicsLayer { translationY = y.value }
                .softShadow(shape, Color(if (dark) 0x66000000 else 0x30000000), 26.u(), 0.dp, 10.u())
                .clip(shape)
                .drawBehind {
                    if (frosted && backdrop != null) {
                        val r = 36.dp.toPx() // thick blur: what's behind is barely recognisable
                        blurred.renderEffect = BlurEffect(r, r, TileMode.Clamp)
                        blurred.record { translate(-sidePad, -(topPad + y.value)) { drawLayer(backdrop) } }
                        drawLayer(blurred)
                        // light mode: bright frosted glass, dark mode: dark frosted glass
                        drawRect(if (dark) Color(0xFF1B1C25).copy(alpha = 0.50f) else Color.White.copy(alpha = 0.58f))
                    } else drawRect(if (dark) Color(0xFF1B1C25).copy(alpha = 0.95f) else Color.White.copy(alpha = 0.95f))
                    drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.08f else 0.35f), Color.Transparent)))
                }
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.26f else 0.95f), Color.White.copy(alpha = if (dark) 0.06f else 0.35f))), shape)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, dy -> change.consume(); scope.launch { y.snapTo((y.value + dy).coerceAtMost(36f)) } },
                        onDragEnd = {
                            if (y.value < -with(density) { 28.dp.toPx() }) AppToast.dismiss()
                            else scope.launch { y.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 400f)) }
                        }
                    )
                }
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { AppToast.dismiss() }
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.u(), vertical = 13.u()), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.u()).background(c.copy(alpha = if (dark) 0.20f else 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                    SvgIcon(shown.kind.glyph(), 20.u(), c, 2.2f)
                }
                Spacer(Modifier.width(12.u()))
                Column(Modifier.weight(1f)) {
                    T(shown.kind.title(), 13.5f, FontWeight.Bold, ink, maxLines = 1)
                    Spacer(Modifier.height(1.u()))
                    T(shown.message, 12.5f, FontWeight.Normal, ink.copy(alpha = if (dark) 0.78f else 0.68f), maxLines = 3, lineHeight = 17f)
                }
            }
        }
    }
}

// ───────────── internet check ─────────────

object Network {
    fun isOnline(ctx: Context): Boolean = try {
        val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Exception) { true }
}

// ───────────── alert dialog ─────────────

enum class AlertTone { Error, Warning, Info, Success }

/**
 * Glass alert dialog with a bounce-in. [primary] is the big green button, [secondary] an optional text button.
 * Set [dismissible] = false to block back / outside taps (connection errors, forced actions).
 */
@Composable
fun AppAlertDialog(
    visible: Boolean,
    title: String,
    message: String,
    icon: List<Seg>,
    tone: AlertTone = AlertTone.Info,
    primary: String,
    onPrimary: () -> Unit,
    secondary: String? = null,
    onSecondary: () -> Unit = {},
    dismissible: Boolean = false,
    onDismiss: () -> Unit = {}
) {
    val p = pal()
    if (visible) BackHandler(enabled = true) { if (dismissible) onDismiss() }
    val accent = when (tone) {
        AlertTone.Error -> AppColors.ArrowUp; AlertTone.Warning -> Color(0xFFFFB020)
        AlertTone.Success -> AppColors.Accent; AlertTone.Info -> Color(0xFF5AA9FF)
    }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(220)), exit = fadeOut(tween(180))) {
            Box(
                Modifier.fillMaxSize().background(Color(if (p.dark) 0xB3000000 else 0x8C000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { if (dismissible) onDismiss() }
            )
        }
        AnimatedVisibility(
            visible, modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(200)) + scaleIn(spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.8f),
            exit = fadeOut(tween(150)) + scaleOut(tween(170), targetScale = 0.92f)
        ) {
            val shape = RoundedCornerShape(30.u())
            Column(
                Modifier.padding(horizontal = 28.u()).fillMaxWidth().glass(shape, solid = true).then(noRipple).padding(24.u()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(68.u()).background(accent.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(50.u()).background(accent.copy(alpha = 0.20f), CircleShape), contentAlignment = Alignment.Center) {
                        SvgIcon(icon, 26.u(), accent, 2f)
                    }
                }
                Spacer(Modifier.height(16.u()))
                T(title, 20f, FontWeight.Bold, align = TextAlign.Center)
                Spacer(Modifier.height(8.u()))
                T(message, 13.5f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 19f)
                Spacer(Modifier.height(22.u()))
                PrimaryButton(primary, onClick = onPrimary)
                if (secondary != null) {
                    Spacer(Modifier.height(4.u()))
                    Box(Modifier.fillMaxWidth().height(46.u()).pressable(0.97f, onSecondary), contentAlignment = Alignment.Center) {
                        T(secondary, 14f, FontWeight.SemiBold, p.textSecondary)
                    }
                }
            }
        }
    }
}

/** "No internet" dialog. Used on the splash screen; reuse anywhere a request can't reach the server. */
@Composable
fun ConnectionErrorDialog(visible: Boolean, onRetry: () -> Unit, onClose: (() -> Unit)? = null) {
    AppAlertDialog(
        visible = visible,
        title = "No internet connection",
        message = "PlugBill can't reach the internet. Check your Wi-Fi or mobile data, then try again.",
        icon = WifiOff, tone = AlertTone.Error,
        primary = "Try again", onPrimary = onRetry,
        secondary = if (onClose != null) "Close app" else null, onSecondary = { onClose?.invoke() }
    )
}

/** Finishes the host activity (for the dialog's "Close app"). */
fun Context.closeApp() { (this as? Activity)?.finishAffinity() }

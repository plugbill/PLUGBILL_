package com.example.walletapp.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Liquid pull-to-refresh: drag stretches a water drop, release makes it bounce, then [onRefresh] runs. */
class PullState(
    private val holdPx: Float,
    private val maxPx: Float,
    private val scope: CoroutineScope,
    private val onTick: () -> Unit,
    private val onRefresh: suspend () -> Unit
) {
    var offset by mutableFloatStateOf(0f); private set
    var refreshing by mutableStateOf(false); private set
    val hold: Float get() = holdPx
    private var crossed = false
    private var anim: Job? = null

    fun drag(dy: Float): Float {
        if (refreshing) return 0f
        anim?.cancel()
        val resist = 1f - 0.65f * (offset / maxPx).coerceIn(0f, 1f)
        val next = (offset + dy * resist).coerceIn(0f, maxPx)
        val changed = next != offset
        offset = next
        val over = offset >= holdPx
        if (over && !crossed) { crossed = true; onTick() } else if (!over) crossed = false
        return if (changed) dy else 0f
    }

    fun release() {
        if (refreshing || offset <= 0f) return
        anim?.cancel()
        anim = scope.launch {
            if (offset >= holdPx) {
                refreshing = true
                // let go and bounce like a water drop settling
                animate(offset, holdPx, animationSpec = spring(0.26f, Spring.StiffnessLow)) { v, _ -> offset = v.coerceAtLeast(0f) }
                try { onRefresh() } finally {
                    animate(offset, 0f, animationSpec = spring(0.55f, Spring.StiffnessMediumLow)) { v, _ -> offset = v.coerceAtLeast(0f) }
                    refreshing = false; crossed = false
                }
            } else {
                animate(offset, 0f, animationSpec = spring(0.6f, Spring.StiffnessMediumLow)) { v, _ -> offset = v.coerceAtLeast(0f) }
                crossed = false
            }
        }
    }

    /** Hook for the scrolling list below the header. */
    val connection = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
            if (available.y < 0f && offset > 0f) Offset(0f, drag(available.y)) else Offset.Zero

        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
            if (source == NestedScrollSource.UserInput && available.y > 0f) Offset(0f, drag(available.y)) else Offset.Zero

        override suspend fun onPreFling(available: Velocity): Velocity {
            if (offset > 0f && !refreshing) { release(); return available }
            return Velocity.Zero
        }
    }
}

/** The space between the top bar and the balance card; grows as you pull and draws the water drop. */
@Composable
fun PullZone(state: PullState, minHeight: androidx.compose.ui.unit.Dp) {
    val d = LocalDensity.current
    val t = rememberInfiniteTransition(label = "pullSpin")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "spin")
    val breathe by t.animateFloat(0f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "breathe")
    Box(Modifier.fillMaxWidth().height(minHeight + with(d) { state.offset.toDp() })) {
        Canvas(Modifier.fillMaxSize()) {
            val off = state.offset
            if (off < 1f) return@Canvas
            val prog = off / state.hold
            val p1 = prog.coerceIn(0f, 1f)
            val pinch = ((prog - 1f) / 0.3f).coerceIn(0f, 1f)
            val grow = if (state.refreshing) 1f + 0.07f * breathe else 1f
            val r = (6.dp.toPx() + 15.dp.toPx() * p1) * grow
            val cx = size.width / 2f
            val cy = (off * 0.85f + 4.dp.toPx()).coerceAtLeast(r)
            val base = 64.dp.toPx() * (0.30f + 0.70f * p1) * (1f - 0.4f * pinch)
            val drop = Path().apply {
                moveTo(cx - base, 0f)
                cubicTo(cx - base * 0.25f, cy * 0.35f, cx - r, cy * 0.45f, cx - r, cy)
                arcTo(Rect(cx - r, cy - r, cx + r, cy + r), 180f, -180f, false)
                cubicTo(cx + r, cy * 0.45f, cx + base * 0.25f, cy * 0.35f, cx + base, 0f)
                close()
            }
            drawPath(drop, Brush.verticalGradient(listOf(AppColors.Accent.copy(alpha = 0.55f), AppColors.GreenLight, AppColors.Accent), 0f, cy + r))
            // water highlight
            drawCircle(Color.White.copy(alpha = 0.38f), r * 0.22f, Offset(cx - r * 0.38f, cy - r * 0.38f))
            // spinner inside the drop while refreshing, otherwise a progress arc
            val arcR = r * 0.52f
            val sweep = if (state.refreshing) 250f else 300f * p1
            val start = if (state.refreshing) spin else -90f
            drawArc(
                Color.White, start, sweep, false,
                topLeft = Offset(cx - arcR, cy - arcR), size = Size(arcR * 2, arcR * 2),
                style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
}

package com.example.walletapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.runtime.DisposableEffect
import com.example.walletapp.data.SecurityGuard
import com.example.walletapp.data.Threat
import kotlinx.coroutines.delay

/** Wraps a screen: scans on open, on every resume and every 15 s, and covers the app while a threat is present. */
@Composable
fun SecurityGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var threat by remember { mutableStateOf<Threat?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    LaunchedEffect(tick) {
        while (true) {
            threat = SecurityGuard.scan(ctx.applicationContext)
            delay(15_000)
        }
    }
    Box(Modifier.fillMaxSize()) {
        content()
        threat?.let { t ->
            val p = pal()
            Box(Modifier.fillMaxSize().background(screenBackground()).then(noRipple), contentAlignment = Alignment.Center) {
                Column(Modifier.padding(horizontal = 32.u()), horizontalAlignment = Alignment.CenterHorizontally) {
                    GreenIcon(AppIcons.Shield, 72, 36)
                    Spacer(Modifier.height(20.u()))
                    T(t.title, 22f, FontWeight.Bold, align = TextAlign.Center)
                    Spacer(Modifier.height(10.u()))
                    T(t.userMessage, 14f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 14f * 1.5f)
                    Spacer(Modifier.height(26.u()))
                    if (t.hard) PrimaryButton("Close app") { ctx.findActivity()?.finishAffinity() }
                    else PrimaryButton("Try again") { threat = SecurityGuard.networkThreat(ctx.applicationContext); tick++ }
                }
            }
        }
    }
}

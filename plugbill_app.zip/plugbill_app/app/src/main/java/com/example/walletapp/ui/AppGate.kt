package com.example.walletapp.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign

/** An app update. [force] = true gives the non-closable version (no "Later", back button blocked). */
data class UpdateInfo(
    val versionName: String,
    val notes: List<String> = emptyList(),
    val force: Boolean = false,
    val storeUrl: String? = null
)

/** App is down for maintenance. [message] and [eta] come from the server. */
data class MaintenanceInfo(
    val title: String = "We'll be right back",
    val message: String = "PlugBill is getting some upgrades. Please check back shortly.",
    val eta: String? = null
)

/**
 * Remote gates (update dialog + maintenance screen). Both are READY but OFF: nothing shows until
 * something sets [update] / [maintenance]. Later, call these from your server / Remote Config:
 *
 *   AppGate.maintenance = MaintenanceInfo(message = "Back at 6pm", eta = "6:00 PM")   // show
 *   AppGate.maintenance = null                                                         // hide
 *   AppGate.update = UpdateInfo("2.1.0", listOf("Faster payments"), force = false)     // closable
 *   AppGate.update = UpdateInfo("2.1.0", force = true)                                 // non-closable
 *
 * or [applyRemote] with the raw values from the server.
 */
data class BlockedInfo(val title: String, val message: String)

object AppGate {
    var blocked by mutableStateOf<BlockedInfo?>(null)
    /** Shows the full-screen blocked / suspended / banned notice (used on login and when an open session is disabled). */
    fun showBlocked(status: String, serverMessage: String? = null) {
        val s = status.lowercase()
        val (title, word) = when {
            s.contains("ban") || s.contains("terminat") -> "Account banned" to "banned"
            s.contains("suspend") -> "Account suspended" to "suspended"
            else -> "Account disabled" to "disabled"
        }
        blocked = BlockedInfo(title, serverMessage?.takeIf { it.isNotBlank() } ?: "Your account has been $word. Please contact PlugBill support if you think this is a mistake.")
    }
    var update by mutableStateOf<UpdateInfo?>(null)
    var maintenance by mutableStateOf<MaintenanceInfo?>(null)
    /** "Later" on a closable update hides it for this run (and for that version name). */
    var dismissedVersion by mutableStateOf<String?>(null)
    /** Called by the maintenance screen's "Try again" so the app can re-check the server. Wire later. */
    var onRetry: (() -> Unit)? = null

    fun applyRemote(
        maintenanceOn: Boolean = false, maintenanceTitle: String? = null, maintenanceMessage: String? = null, maintenanceEta: String? = null,
        latestVersionName: String? = null, latestVersionCode: Int = 0, minVersionCode: Int = 0, notes: List<String> = emptyList(), storeUrl: String? = null,
        currentVersionCode: Int
    ) {
        maintenance = if (maintenanceOn) MaintenanceInfo(
            maintenanceTitle ?: MaintenanceInfo().title, maintenanceMessage ?: MaintenanceInfo().message, maintenanceEta
        ) else null
        update = when {
            latestVersionName == null -> null
            currentVersionCode < minVersionCode -> UpdateInfo(latestVersionName, notes, force = true, storeUrl = storeUrl)
            currentVersionCode < latestVersionCode -> UpdateInfo(latestVersionName, notes, force = false, storeUrl = storeUrl)
            else -> null
        }
    }

    fun openStore(ctx: Context, url: String?) {
        val target = url ?: "market://details?id=${ctx.packageName}"
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            openUrl(ctx, "https://play.google.com/store/apps/details?id=${ctx.packageName}")
        }
    }
}

/** Sits on top of the whole app. Shows nothing unless [AppGate] has been set. */
@Composable
fun AppGateHost() {
    val m = AppGate.maintenance
    val u = AppGate.update
    val showUpdate = m == null && u != null && (u.force || AppGate.dismissedVersion != u.versionName)

    val b = AppGate.blocked
    if (b != null && m == null) {
        BackHandler(enabled = true) { AppGate.blocked = null }
        BlockedScreen(b, onClose = { AppGate.blocked = null })
    }
    if (m != null) {
        BackHandler(enabled = true) { /* maintenance can't be closed */ }
        MaintenanceScreen(m, onRetry = { AppGate.onRetry?.invoke() })
    }
    if (showUpdate && u != null) {
        if (u.force) BackHandler(enabled = true) { }
        else BackHandler(enabled = true) { AppGate.dismissedVersion = u.versionName }
    }
    UpdateDialog(
        info = u, visible = showUpdate,
        onUpdate = { }, onLater = { u?.let { AppGate.dismissedVersion = it.versionName } }
    )
}

// ───────────── update dialog (closable + non-closable) ─────────────

@Composable
fun UpdateDialog(info: UpdateInfo?, visible: Boolean, onUpdate: () -> Unit, onLater: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    // keep the last info so the content survives the exit animation
    var last by remember { mutableStateOf(info) }
    if (info != null) last = info
    val shown = last

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(220)), exit = fadeOut(tween(200))) {
            Box(
                Modifier.fillMaxSize().background(Color(if (p.dark) 0xB3000000 else 0x8C000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { if (shown?.force == false) onLater() }
            )
        }
        AnimatedVisibility(
            visible, modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.9f),
            exit = fadeOut(tween(160)) + scaleOut(tween(180), targetScale = 0.92f)
        ) {
            if (shown != null) {
                val shape = RoundedCornerShape(30.u())
                Column(
                    Modifier.padding(horizontal = 28.u()).fillMaxWidth().glass(shape, solid = true).then(noRipple).padding(22.u()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    GreenIcon(AppIcons.Bills, 60, 30)
                    Spacer(Modifier.height(14.u()))
                    T(if (shown.force) "Update required" else "Update available", 20f, FontWeight.Bold)
                    Spacer(Modifier.height(4.u()))
                    T("Version ${shown.versionName}", 12f, FontWeight.Medium, AppColors.Accent)
                    Spacer(Modifier.height(10.u()))
                    T(
                        if (shown.force) "This version is no longer supported. Please update to keep using PlugBill."
                        else "A newer version of PlugBill is ready with improvements and fixes.",
                        13f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 18.5f
                    )
                    if (shown.notes.isNotEmpty()) {
                        Spacer(Modifier.height(14.u()))
                        Column(
                            Modifier.fillMaxWidth().background(p.divider.copy(alpha = 0.35f), RoundedCornerShape(16.u())).padding(14.u()),
                            verticalArrangement = Arrangement.spacedBy(6.u())
                        ) {
                            shown.notes.take(5).forEach { n ->
                                Row(verticalAlignment = Alignment.Top) {
                                    SvgIcon(AppIcons.Check, 14.u(), AppColors.Accent, 2.6f)
                                    Spacer(Modifier.width(8.u()))
                                    T(n, 12.5f, FontWeight.Normal, lineHeight = 17f)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.u()))
                    PrimaryButton("Update now") { AppGate.openStore(ctx, shown.storeUrl); onUpdate() }
                    if (!shown.force) {
                        Spacer(Modifier.height(8.u()))
                        Box(Modifier.fillMaxWidth().height(44.u()).pressable(0.97f, onLater), contentAlignment = Alignment.Center) {
                            T("Maybe later", 13.5f, FontWeight.SemiBold, p.textSecondary)
                        }
                    }
                }
            }
        }
    }
}

// ───────────── maintenance (full screen, can't be closed) ─────────────

@Composable
fun MaintenanceScreen(info: MaintenanceInfo, onRetry: () -> Unit) {
    val p = pal()
    Box(Modifier.fillMaxSize().background(screenBackground()).then(noRipple).statusBarsPadding().navigationBarsPadding()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 32.u()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            GreenIcon(AppIcons.Support, 84, 42)
            Spacer(Modifier.height(26.u()))
            T(info.title, 24f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(10.u()))
            T(info.message, 14f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 20f)
            if (!info.eta.isNullOrBlank()) {
                Spacer(Modifier.height(18.u()))
                Box(Modifier.background(AppColors.Accent.copy(alpha = 0.14f), RoundedCornerShape(50)).padding(horizontal = 16.u(), vertical = 8.u())) {
                    T("Back by ${info.eta}", 12.5f, FontWeight.Bold, AppColors.Accent)
                }
            }
            Spacer(Modifier.height(32.u()))
            PrimaryButton("Try again", onClick = onRetry)
        }
    }
}


/** Full-screen notice for banned / suspended / disabled accounts. The session is already cleared when this shows. */
@Composable
fun BlockedScreen(info: BlockedInfo, onClose: () -> Unit) {
    val p = pal()
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().background(screenBackground()).then(noRipple).statusBarsPadding().navigationBarsPadding()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 32.u()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            GreenIcon(AppIcons.Lock, 84, 42)
            Spacer(Modifier.height(26.u()))
            T(info.title, 24f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(10.u()))
            T(info.message, 14f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 20f)
            Spacer(Modifier.height(32.u()))
            PrimaryButton("Contact support") { openUrl(ctx, "mailto:support@plugbill.com") }
            Spacer(Modifier.height(10.u()))
            T("Back to sign in", 14f, FontWeight.SemiBold, p.textSecondary, Modifier.pressable(onClick = onClose).padding(12.u()))
        }
    }
}

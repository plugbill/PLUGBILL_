package com.example.walletapp.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.walletapp.R
import com.example.walletapp.data.ZaraAPI
import com.example.walletapp.data.ZaraMsg
import com.example.walletapp.data.ZaraStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val TrashIcon = icon("M4 7h16", "M10 11v6", "M14 11v6", "M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12", "M9 7V4h6v3")
private val MicIcon = icon("M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z", "M5 11a7 7 0 0 0 14 0", "M12 18v3")
private val PlayIcon = listOf(Seg("M8 5v14l11-7z", fill = true))
private val PauseIcon = listOf(Seg("M7 5h4v14H7z", fill = true), Seg("M13 5h4v14h-4z", fill = true))
private const val MAX_VOICE_MS = 120_000L

@Composable
fun ZaraScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val scope = rememberCoroutineScope()
    val saved = remember { ZaraStore.load(ctx) }
    val msgs = remember { mutableStateListOf<ZaraMsg>().also { it.addAll(saved.msgs) } }
    var rev by remember { mutableIntStateOf(0) }
    var thinking by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var payFor by remember { mutableStateOf<ZaraMsg?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var micDenied by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val recorder = remember { VoiceRecorder(ctx) }
    val levels = remember { mutableStateListOf<Float>() }
    var recMs by remember { mutableStateOf(0L) }

    fun persist() {
        saved.msgs.clear(); saved.msgs.addAll(msgs)
        ZaraStore.save(ctx, saved)
    }

    fun addMsg(m: ZaraMsg) { msgs.add(m); persist() }

    /** Sends the chat window (and a voice note, when there is one) to Zara and adds her reply. */
    fun deliver(voice: ZaraMsg?, file: File?) {
        thinking = true
        scope.launch {
            if (!Network.isOnline(ctx)) {
                thinking = false
                addMsg(ZaraMsg("e" + System.nanoTime(), "assistant", "I can't reach the internet right now. Check your connection and send that again.", error = true))
                return@launch
            }
            saved.msgs.clear(); saved.msgs.addAll(msgs)
            val (window, older, winStart) = ZaraStore.buildRequest(saved, false)
            val r = ZaraAPI.chat(window, older, saved.summary, file)
            thinking = false
            if (!r.success) {
                val why = r.errors?.optString("reason").orEmpty()
                addMsg(ZaraMsg("e" + System.nanoTime(), "assistant", r.message.ifBlank { "I couldn't answer just now. Please try again." } + if (why.isNotBlank()) "\n($why)" else "", error = true))
                return@launch
            }
            val o = r.obj ?: JSONObject()
            if (o.has("summary") && !o.isNull("summary")) { saved.summary = o.optString("summary"); saved.folded = winStart }
            if (voice != null) {
                val t = if (o.isNull("transcript")) "" else o.optString("transcript")
                voice.text = t
                rev++
                if (o.optBoolean("unclear") || t.isBlank()) {
                    addMsg(ZaraMsg("e" + System.nanoTime(), "assistant", "I couldn't hear that clearly. Could you record it again, or type it?", error = true))
                    return@launch
                }
            }
            val action = o.optJSONObject("action")
            var text = o.optString("message").trim()
            if (text.isEmpty() && action != null) text = "Here's what I've prepared. Check it and confirm when you're ready."
            if (text.isEmpty()) text = "Hmm, I didn't quite get that. Can you say it another way?"
            addMsg(ZaraMsg("z" + System.nanoTime(), "assistant", text, action = action))
        }
    }

    fun sendText() {
        val t = input.trim()
        if (t.isEmpty() || thinking) return
        input = ""
        addMsg(ZaraMsg("u" + System.nanoTime(), "user", t))
        deliver(null, null)
    }

    fun finishRecording(send: Boolean) {
        recording = false
        if (!send) { recorder.cancel(); levels.clear(); return }
        val res = recorder.stop(); levels.clear()
        if (res == null) { AppToast.info("Hold on a bit longer to record a voice note"); return }
        val (f, dur) = res
        val m = ZaraMsg("u" + System.nanoTime(), "user", "", audioFile = f.name, durationMs = dur)
        addMsg(m)
        deliver(m, f)
    }

    fun startRecording() {
        if (thinking) return
        VoicePlayer.stop()
        if (recorder.start()) { levels.clear(); recMs = 0; recording = true; Haptics.tick(ctx) }
        else AppToast.error("Couldn't start the microphone. Please try again.")
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else micDenied = true
    }
    fun onMic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
        else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(recording) {
        while (recording) {
            levels.add(recorder.level()); if (levels.size > 40) levels.removeAt(0)
            recMs = recorder.elapsedMs
            if (recMs >= MAX_VOICE_MS) { finishRecording(true); break }
            delay(80)
        }
    }

    DisposableEffect(Unit) { onDispose { recorder.cancel(); VoicePlayer.stop() } }

    val visibleCount = msgs.count { !it.hidden }
    LaunchedEffect(msgs.size, thinking, recording) {
        val n = msgs.size + (if (thinking) 1 else 0)
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    fun note(text: String) { msgs.add(ZaraMsg("h" + System.nanoTime(), "user", text, hidden = true)); persist() }

    Box(Modifier.fillMaxSize().background(screenBackground())) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            // ── top bar: back · Zara · clear ──
            Row(Modifier.fillMaxWidth().padding(start = 16.u(), end = 16.u(), top = 10.u(), bottom = 8.u()), verticalAlignment = Alignment.CenterVertically) {
                FloatSurface(Modifier.size(44.u()), RoundedCornerShape(15.u()), onBack) { SvgIcon(AppIcons.Back, 21.u(), p.text, 2f) }
                Spacer(Modifier.width(12.u()))
                Box(Modifier.weight(1f)) { T("Zara", 19f, FontWeight.Bold) }
                FloatSurface(Modifier.size(44.u()), RoundedCornerShape(15.u()), { if (visibleCount > 0) confirmClear = true else AppToast.info("Nothing to clear") }) {
                    SvgIcon(TrashIcon, 20.u(), p.text, 1.9f)
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (visibleCount == 0 && !thinking) EmptyState()
                LazyColumn(
                    state = listState, modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.u(), vertical = 10.u()),
                    verticalArrangement = Arrangement.spacedBy(8.u())
                ) {
                    items(msgs.filter { !it.hidden }, key = { it.id }) { m ->
                        MessageRow(m, rev, onAuthorize = { payFor = it }, onCancelAction = { c ->
                            c.actionState = "cancelled"; rev++; persist()
                            val id = c.action?.optString("intent_id").orEmpty()
                            scope.launch { if (id.isNotEmpty()) ZaraAPI.dismiss(id) }
                            note("[I cancelled the payment dialog]")
                        })
                    }
                    if (thinking) item(key = "typing") { TypingBubble() }
                }
            }

            // ── input ──
            if (recording) RecordingBar(levels, recMs, onCancel = { finishRecording(false) }, onSend = { finishRecording(true) })
            else InputBar(input, { input = it }, thinking, onSend = { sendText() }, onMic = { onMic() })
        }

        payFor?.let { m ->
            PayPinFlow(onVerified = { pin ->
                payFor = null
                val id = m.action?.optString("intent_id").orEmpty()
                m.actionState = "working"; rev++
                scope.launch {
                    val r = ZaraAPI.authorize(id, pin)
                    if (r.success) {
                        m.actionState = "done"; m.actionNote = r.message
                        Haptics.success(ctx)
                        note("[Payment dialog result: authorized and completed. ${r.message}]")
                        scope.launch { com.example.walletapp.data.Sync.refresh(ctx) }
                    } else {
                        m.actionState = "failed"; m.actionNote = r.message
                        Haptics.reject(ctx)
                        note("[Payment dialog result: not completed. ${r.message}]")
                    }
                    rev++; persist()
                }
            }, onCancel = { payFor = null })
        }

        AppAlertDialog(
            visible = confirmClear, title = "Clear this chat?",
            message = "Your conversation with Zara is removed from this phone. Zara will start fresh.",
            icon = TrashIcon, tone = AlertTone.Warning, primary = "Clear chat",
            onPrimary = {
                confirmClear = false
                VoicePlayer.stop(); msgs.clear(); saved.summary = ""; saved.folded = 0; saved.msgs.clear()
                ZaraStore.clear(ctx); input = ""
            },
            secondary = "Cancel", onSecondary = { confirmClear = false }, dismissible = true, onDismiss = { confirmClear = false }
        )
        AppAlertDialog(
            visible = micDenied, title = "Microphone is off",
            message = "To send Zara voice notes, allow microphone access for PlugBill in your phone settings.",
            icon = MicIcon, tone = AlertTone.Info, primary = "Open settings",
            onPrimary = {
                micDenied = false
                ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            secondary = "Not now", onSecondary = { micDenied = false }, dismissible = true, onDismiss = { micDenied = false }
        )
    }
}

@Composable
private fun EmptyState() {
    val p = pal()
    Column(Modifier.fillMaxSize().padding(horizontal = 36.u()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Image(
            painter = androidx.compose.ui.res.painterResource(R.drawable.zara_avatar), contentDescription = "Zara",
            contentScale = ContentScale.Crop, modifier = Modifier.size(64.u()).clip(CircleShape)
        )
        Spacer(Modifier.height(14.u()))
        val first = Session.firstName.trim().ifBlank { "there" }
        T("Hello, $first", 22f, FontWeight.Bold, align = TextAlign.Center)
        Spacer(Modifier.height(6.u()))
        T("I'm your personal AI assistant.", 13.5f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center)
        Spacer(Modifier.height(60.u()))
    }
}

private fun rich(text: String, bold: Color): AnnotatedString = buildAnnotatedString {
    val parts = text.split("**")
    parts.forEachIndexed { i, s ->
        if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = bold)) { append(s) } else append(s)
    }
}

@Composable
private fun MessageRow(m: ZaraMsg, rev: Int, onAuthorize: (ZaraMsg) -> Unit, onCancelAction: (ZaraMsg) -> Unit) {
    val p = pal()
    val mine = m.role == "user"
    val tail = 6.u(); val big = 20.u()
    val shape = if (mine) RoundedCornerShape(big, big, tail, big) else RoundedCornerShape(big, big, big, tail)
    val bg = if (mine) AppColors.Accent else p.surface
    val fg = if (mine) Color.White else p.text
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Column(
            Modifier.widthIn(max = 290.u()).then(if (mine) Modifier else Modifier.border(1.dp, p.divider.copy(alpha = 0.5f), shape))
                .background(if (m.error) AppColors.ArrowUp.copy(alpha = 0.10f) else bg, shape)
                .padding(horizontal = 14.u(), vertical = 10.u())
        ) {
            if (m.audioFile != null) {
                VoiceBubble(m, fg)
                if (m.text.isNotBlank()) {
                    Spacer(Modifier.height(6.u()))
                    BasicText(m.text, style = TextStyle(fontFamily = AppFont, fontSize = 12.5f.usp(), color = fg.copy(alpha = 0.85f)))
                }
            } else {
                BasicText(rich(m.text, fg), style = TextStyle(fontFamily = AppFont, fontSize = 15f.usp(), lineHeight = 21f.usp(), color = if (m.error) AppColors.ArrowUp else fg))
            }
        }
        if (!mine && m.action != null) {
            Spacer(Modifier.height(8.u()))
            ActionCard(m, rev, onAuthorize, onCancelAction)
        }
        Spacer(Modifier.height(2.u()))
        T(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(m.ts)), 9.5f, FontWeight.Normal, p.textLight, Modifier.padding(horizontal = 6.u()))
    }
}

@Composable
private fun VoiceBubble(m: ZaraMsg, fg: Color) {
    val ctx = LocalContext.current
    val id = m.id
    val playing = VoicePlayer.playingId == id
    val prog = if (playing) VoicePlayer.progress else 0f
    val bars = remember(id) { val r = java.util.Random(id.hashCode().toLong()); List(30) { 0.25f + r.nextFloat() * 0.75f } }
    val file = remember(id) { File(ZaraStore.audioDir(ctx), m.audioFile ?: "") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.u()).background(Color.White, CircleShape).pressable { if (file.exists()) VoicePlayer.toggle(id, file) else AppToast.info("This voice note is no longer on the phone") },
            contentAlignment = Alignment.Center
        ) { SvgIcon(if (playing) PauseIcon else PlayIcon, 18.u(), AppColors.Accent, 1f) }
        Spacer(Modifier.width(10.u()))
        Canvas(Modifier.width(120.u()).height(28.u())) {
            val n = bars.size; val gap = size.width / n; val w = gap * 0.55f
            bars.forEachIndexed { i, h ->
                val done = (i + 1f) / n <= prog
                val bh = size.height * h
                drawRoundRect(
                    color = if (done) fg else fg.copy(alpha = 0.45f),
                    topLeft = Offset(i * gap, (size.height - bh) / 2f), size = Size(w, bh), cornerRadius = CornerRadius(w / 2f)
                )
            }
        }
        Spacer(Modifier.width(10.u()))
        T(fmtDur(m.durationMs), 11.5f, FontWeight.SemiBold, fg)
    }
}

private fun fmtDur(ms: Long): String { val s = (ms / 1000).toInt(); return "%d:%02d".format(s / 60, s % 60) }

@Composable
private fun ActionCard(m: ZaraMsg, rev: Int, onAuthorize: (ZaraMsg) -> Unit, onCancel: (ZaraMsg) -> Unit) {
    val p = pal()
    val a = m.action ?: return
    val c = a.optJSONObject("confirm") ?: return
    if (rev < 0) return
    val expiresMs = m.ts + c.optLong("expires_in", 300) * 1000
    val state = if (m.actionState.isEmpty() && System.currentTimeMillis() > expiresMs) "expired" else m.actionState
    val shape = RoundedCornerShape(22.u())
    Column(
        Modifier.widthIn(max = 300.u()).fillMaxWidth().background(p.surface, shape).border(1.dp, AppColors.Accent.copy(alpha = 0.35f), shape).padding(16.u())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GreenIcon(AppIcons.Shield, 34, 17)
            Spacer(Modifier.width(10.u()))
            Column(Modifier.weight(1f)) {
                T("Authorize payment", 10.5f, FontWeight.SemiBold, p.textSecondary, spacing = 0.4f)
                T(c.optString("title"), 14.5f, FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.u()))
        val rows = c.optJSONArray("rows")
        if (rows != null) for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            Row(Modifier.fillMaxWidth().padding(vertical = 3.u())) {
                Box(Modifier.weight(1f)) { T(r.optString("label"), 12.5f, FontWeight.Normal, p.textSecondary) }
                T(r.optString("value"), 12.5f, FontWeight.SemiBold, align = TextAlign.End, modifier = Modifier.widthIn(max = 170.u()))
            }
        }
        Spacer(Modifier.height(8.u()))
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.divider.copy(alpha = 0.6f)))
        Spacer(Modifier.height(8.u()))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { T("You pay", 13f, FontWeight.SemiBold) }
            T(c.optString("total_text"), 17f, FontWeight.Bold, AppColors.Accent)
        }
        Spacer(Modifier.height(14.u()))
        when (state) {
            "" -> {
                PrimaryButton("Authorize", overlay = false) { onAuthorize(m) }
                Spacer(Modifier.height(4.u()))
                T("Cancel", 13.5f, FontWeight.SemiBold, p.textSecondary, Modifier.fillMaxWidth().pressable { onCancel(m) }.padding(8.u()), align = TextAlign.Center)
            }
            "working" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Spinner(size = 18); Spacer(Modifier.width(10.u())); T("Processing…", 13f, FontWeight.SemiBold, p.textSecondary)
            }
            "done" -> T("Paid. " + m.actionNote, 13f, FontWeight.SemiBold, AppColors.Accent)
            "failed" -> T(m.actionNote.ifBlank { "The payment could not be completed." }, 13f, FontWeight.SemiBold, AppColors.ArrowUp)
            "cancelled" -> T("Cancelled", 13f, FontWeight.SemiBold, p.textSecondary)
            else -> T("This request expired. Ask Zara to set it up again.", 13f, FontWeight.SemiBold, p.textSecondary)
        }
    }
}

@Composable
private fun TypingBubble() {
    val p = pal()
    val shape = RoundedCornerShape(20.u(), 20.u(), 20.u(), 6.u())
    val t = rememberInfiniteTransition(label = "typing")
    Row(Modifier.background(p.surface, shape).border(1.dp, p.divider.copy(alpha = 0.5f), shape).padding(horizontal = 16.u(), vertical = 14.u()), horizontalArrangement = Arrangement.spacedBy(5.u())) {
        repeat(3) { i ->
            val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 160, easing = LinearEasing), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(7.u()).alpha(a).background(p.textSecondary, CircleShape))
        }
    }
}

@Composable
private fun InputBar(value: String, onChange: (String) -> Unit, busy: Boolean, onSend: () -> Unit, onMic: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(26.u())
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.u(), vertical = 10.u()), verticalAlignment = Alignment.Bottom) {
        Box(
            Modifier.weight(1f).background(p.surface, shape).border(1.dp, p.divider.copy(alpha = 0.6f), shape)
                .padding(horizontal = 18.u(), vertical = 13.u())
        ) {
            if (value.isEmpty()) T("Message Zara", 15f, FontWeight.Normal, p.textLight)
            BasicTextField(
                value = value, onValueChange = { if (it.length <= 1500) onChange(it) },
                textStyle = TextStyle(fontFamily = AppFont, fontSize = 15f.usp(), color = p.text),
                cursorBrush = SolidColor(AppColors.Accent), maxLines = 5, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default)
            )
        }
        Spacer(Modifier.width(8.u()))
        val hasText = value.isNotBlank()
        Box(
            Modifier.size(48.u()).background(Brush.linearGradient(listOf(AppColors.GreenLight, AppColors.GreenDeep)), CircleShape)
                .alpha(if (busy && hasText) 0.5f else 1f).pressable { if (hasText) onSend() else onMic() },
            contentAlignment = Alignment.Center
        ) { if (hasText) SvgIcon(AppIcons.ArrowUp, 22.u(), Color.White, 2.4f) else SvgIcon(MicIcon, 22.u(), Color.White, 2f) }
    }
}

@Composable
private fun RecordingBar(levels: List<Float>, ms: Long, onCancel: () -> Unit, onSend: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(26.u())
    val pulse by rememberInfiniteTransition(label = "rec").animateFloat(0.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse")
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.u(), vertical = 10.u()), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.u()).background(p.surface, CircleShape).border(1.dp, p.divider.copy(alpha = 0.6f), CircleShape).pressable { onCancel() }, contentAlignment = Alignment.Center) {
            SvgIcon(TrashIcon, 20.u(), AppColors.ArrowUp, 1.9f)
        }
        Spacer(Modifier.width(8.u()))
        Row(
            Modifier.weight(1f).height(48.u()).background(AppColors.Accent.copy(alpha = 0.14f), shape).border(1.dp, AppColors.Accent.copy(alpha = 0.5f), shape).padding(horizontal = 16.u()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.u()).alpha(pulse).background(AppColors.Accent, CircleShape))
            Spacer(Modifier.width(10.u()))
            T(fmtDur(ms), 14f, FontWeight.SemiBold)
            Spacer(Modifier.width(12.u()))
            Canvas(Modifier.weight(1f).height(30.u())) {
                val n = 40; val gap = size.width / n; val w = gap * 0.55f
                val start = n - levels.size
                for (i in 0 until n) {
                    val lv = if (i >= start) levels[i - start] else 0f
                    val h = size.height * (0.12f + 0.88f * lv)
                    drawRoundRect(AppColors.Accent, Offset(i * gap, (size.height - h) / 2f), Size(w, h), CornerRadius(w / 2f))
                }
            }
        }
        Spacer(Modifier.width(8.u()))
        Box(Modifier.size(48.u()).background(Brush.linearGradient(listOf(AppColors.GreenLight, AppColors.GreenDeep)), CircleShape).pressable { onSend() }, contentAlignment = Alignment.Center) {
            SvgIcon(AppIcons.ArrowUp, 22.u(), Color.White, 2.4f)
        }
    }
}

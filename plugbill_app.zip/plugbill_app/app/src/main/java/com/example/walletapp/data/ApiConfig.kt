package com.example.walletapp.data

/** Single place to change the backend. Same default as the web app (appConfig.ts DEFAULT_LIVE_API_URL). */
object ApiConfig {
    const val BASE_URL = "https://plugbill.linexware.net.ng/api"
    const val SITE_URL = "https://plugbill.linexware.net.ng"
    const val PRIVACY_URL = "$SITE_URL/privacy-policy.html"
    const val TERMS_URL = "$SITE_URL/terms-conditions.html"
    const val CONNECT_TIMEOUT_MS = 20_000
    /** Purchases hold funds server-side while the provider answers, so reads get a long timeout. */
    const val READ_TIMEOUT_MS = 60_000
}

package com.example.walletapp.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.walletapp.services.Push

class PlugBillBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        context ?: return
        val action = intent?.action
        Log.d("PlugBillBootReceiver", "Device boot/restart event received with action: $action")

        try {
            // 1. Ensure all high importance notification channels exist
            PlugBillNotificationHelper.ensureAllNotificationChannels(context)

            // 2. Re-schedule local background engagement notifications
            PlugBillNotificationScheduler.scheduleAll(context)

            // 3. Re-verify FCM token and topic subscriptions
            Push.registerTopics(context)
        } catch (e: Exception) {
            Log.e("PlugBillBootReceiver", "Error handling boot broadcast", e)
        }
    }
}

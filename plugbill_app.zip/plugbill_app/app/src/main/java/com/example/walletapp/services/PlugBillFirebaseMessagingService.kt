package com.example.walletapp.services

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.walletapp.MainActivity
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.example.walletapp.R
import org.json.JSONObject
import com.example.walletapp.services.NotificationStore
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class PlugBillFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("PlugBillFCM", "New FCM Token received: $token")

        val prefs = getSharedPreferences("plugbill_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("fcm_token", token).apply()
        Push.registerWithBackend(applicationContext)

        if (Push.ensureFirebase(this)) {
            try {
                FirebaseMessaging.getInstance().subscribeToTopic("all_users")
                FirebaseMessaging.getInstance().subscribeToTopic("plugbill_global")
                val savedAccountId = prefs.getString("user_account_id", null)
                if (!savedAccountId.isNullOrEmpty()) {
                    FirebaseMessaging.getInstance().subscribeToTopic("user_$savedAccountId")
                }
            } catch (e: Exception) {
                Log.w("PlugBillFCM", "FCM token refresh subscription notice", e)
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("PlugBillFCM", "High-Priority FCM Message received from: ${remoteMessage.from}")

        // Acquire a temporary 5-second WakeLock to guarantee background CPU execution during doze mode
        var wakeLock: PowerManager.WakeLock? = null
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PlugBill:FCMWakeLock")
            wakeLock?.acquire(5000L)
        } catch (e: Exception) {
            Log.w("PlugBillFCM", "Could not acquire WakeLock", e)
        }

        try {
            val dataMap = remoteMessage.data
            val notificationType = dataMap["notification_type"] ?: dataMap["type"] ?: dataMap["category"] ?: "broadcast"
            val otpCode = dataMap["otp"] ?: dataMap["code"] ?: dataMap["otp_code"]

            val defaultTitle = when (notificationType) {
                "otp", "verification" -> "🔑 Verification Code"
                "payment_received", "payment" -> "💰 Payment Received"
                "engagement" -> "🎁 Special Offer"
                else -> "⚡ PlugBill Notification"
            }

            val defaultBody = when {
                !otpCode.isNullOrEmpty() -> "Your PlugBill verification code is $otpCode"
                notificationType == "payment_received" -> "Your wallet has been credited successfully."
                else -> "You have a new update from PlugBill."
            }

            val title = dataMap["title"] ?: remoteMessage.notification?.title ?: defaultTitle
            val body = dataMap["body"] ?: remoteMessage.notification?.body ?: defaultBody

            // Extract image URL from FCM data or notification payload
            val imageUrl = dataMap["image"] ?: dataMap["imageUrl"] ?: dataMap["image_url"]
                ?: dataMap["picture"] ?: dataMap["banner"] ?: remoteMessage.notification?.imageUrl?.toString()

            // 1. Keep a copy in the in-app inbox (Notifications screen)
            val inboxType = when (notificationType) {
                "payment_received", "payment", "wallet" -> "wallet"
                "otp", "verification", "security" -> "security"
                "engagement", "broadcast" -> "general"
                else -> "services"
            }
            // transactions already live in Transaction history, so payment / wallet pushes are not kept in the bell
            if (inboxType != "wallet") NotificationStore.add(applicationContext, title, body, inboxType, imageUrl)

            // 2. Display System Notification Tray Alert with Image support
            showSystemNotification(title, body, notificationType, otpCode, imageUrl, dataMap)

            // 3. Money / purchase pushes: update the wallet like the web's handleIncomingPayment (optimistic balance, then full refresh)
            if (notificationType in setOf("payment_received", "payment", "wallet_credit", "wallet", "transaction", "transaction_update") &&
                com.example.walletapp.data.ApiClient.token != null) {
                dataMap["new_balance"]?.replace(Regex("[^0-9.]"), "")?.toDoubleOrNull()?.let { com.example.walletapp.ui.Session.balance = it }
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    try { com.example.walletapp.data.Sync.refresh(applicationContext) } catch (_: Exception) {}
                }
            }
        } finally {
            if (wakeLock?.isHeld == true) {
                try {
                    wakeLock.release()
                } catch (_: Exception) {}
            }
        }
    }

    private fun downloadImageBitmap(imageUrl: String?): Bitmap? {
        if (imageUrl.isNullOrBlank()) return null
        return try {
            val url = URL(imageUrl.trim())
            val connection = url.openConnection() as HttpURLConnection
            connection.doInput = true
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.instanceFollowRedirects = true
            connection.connect()
            val input = connection.inputStream
            BitmapFactory.decodeStream(input)
        } catch (e: Exception) {
            Log.w("PlugBillFCM", "Could not fetch image for notification from: $imageUrl", e)
            null
        }
    }

    private fun showSystemNotification(
        title: String,
        body: String,
        notificationType: String,
        otpCode: String?,
        imageUrl: String?,
        data: Map<String, String>
    ) {
        val isOtp = notificationType == "otp" || notificationType == "verification" || !otpCode.isNullOrEmpty()
        val isPayment = notificationType == "payment_received"
        val channelId = when {
            isOtp -> PlugBillNotificationHelper.CHANNEL_OTP
            isPayment -> PlugBillNotificationHelper.CHANNEL_PAYMENTS
            else -> PlugBillNotificationHelper.CHANNEL_BROADCASTS
        }
        PlugBillNotificationHelper.ensureAllNotificationChannels(this)

        val targetUrl = data["target_url"] ?: data["action_url"] ?: data["url"]

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("notification_data", JSONObject(data).toString())
            putExtra("notification_type", notificationType)
            if (!otpCode.isNullOrEmpty()) {
                putExtra("otp_code", otpCode)
            }
            if (!targetUrl.isNullOrEmpty()) {
                putExtra("target_url", targetUrl)
            }
        }

        val notificationId = (System.currentTimeMillis() % 100000).toInt()
        val pendingIntent = PendingIntent.getActivity(
            this,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val customSoundId = if (isPayment) resources.getIdentifier("payment_chime", "raw", packageName) else 0
        val soundUri = if (customSoundId != 0) {
            android.net.Uri.parse("android.resource://$packageName/$customSoundId")
        } else {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        }
        val vibrationPattern = when {
            isOtp -> longArrayOf(0, 250, 100, 250)
            isPayment -> longArrayOf(0, 200, 100, 200)
            else -> longArrayOf(0, 150, 100, 150)
        }

        // Try downloading image if provided
        val imageBitmap = downloadImageBitmap(imageUrl)

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(androidx.core.content.ContextCompat.getColor(this, R.color.plugbill_green))
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setVibrate(vibrationPattern)
            .setContentIntent(pendingIntent)

        if (imageBitmap != null) {
            builder.setLargeIcon(imageBitmap)
            builder.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(imageBitmap)
                    .setBigContentTitle(title)
                    .setSummaryText(body)
            )
        } else {
            builder.setStyle(NotificationCompat.BigTextStyle().bigText(body))
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(notificationId, builder.build())
    }

    companion object {
        fun ensureAllNotificationChannels(context: Context) {
            PlugBillNotificationHelper.ensureAllNotificationChannels(context)
        }
    }
}

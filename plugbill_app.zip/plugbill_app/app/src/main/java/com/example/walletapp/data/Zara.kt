package com.example.walletapp.data

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One chat line. Lives only on this phone (never saved in the server database). */
class ZaraMsg(
    val id: String,
    val role: String,                 // "user" | "assistant"
    var text: String,
    val ts: Long = System.currentTimeMillis(),
    val audioFile: String? = null,    // voice note file name inside zara_audio/
    var durationMs: Long = 0,
    var action: JSONObject? = null,   // payment proposal from Zara
    var actionState: String = "",     // "" pending | "done" | "failed" | "cancelled" | "expired"
    var actionNote: String = "",
    val hidden: Boolean = false,      // context note for Zara, not shown
    val error: Boolean = false        // local error bubble, never sent or saved
) {
    fun toJson() = JSONObject().put("id", id).put("role", role).put("text", text).put("ts", ts)
        .put("audio", audioFile ?: JSONObject.NULL).put("dur", durationMs)
        .put("action", action ?: JSONObject.NULL).put("as", actionState).put("an", actionNote).put("hidden", hidden)

    companion object {
        fun fromJson(j: JSONObject) = ZaraMsg(
            j.getString("id"), j.getString("role"), j.optString("text"), j.optLong("ts"),
            if (j.isNull("audio")) null else j.optString("audio"), j.optLong("dur"),
            j.optJSONObject("action"), j.optString("as"), j.optString("an"), j.optBoolean("hidden")
        )
    }
}

/** Chat history on the phone + the rolling summary used to give Zara memory without sending the whole chat. */
object ZaraStore {
    const val WINDOW = 12            // recent messages sent with every request
    private const val FILE = "zara_chat.json"

    fun audioDir(ctx: Context) = File(ctx.filesDir, "zara_audio").also { it.mkdirs() }

    class Saved(val msgs: MutableList<ZaraMsg>, var summary: String, var folded: Int)

    fun load(ctx: Context): Saved = try {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) Saved(mutableListOf(), "", 0) else {
            val j = JSONObject(f.readText())
            val a = j.optJSONArray("m") ?: JSONArray()
            val list = mutableListOf<ZaraMsg>()
            for (i in 0 until a.length()) list.add(ZaraMsg.fromJson(a.getJSONObject(i)))
            Saved(list, j.optString("s"), j.optInt("f"))
        }
    } catch (_: Exception) { Saved(mutableListOf(), "", 0) }

    fun save(ctx: Context, s: Saved) {
        try {
            val arr = JSONArray()
            s.msgs.filter { !it.error }.takeLast(300).forEach { arr.put(it.toJson()) }
            File(ctx.filesDir, FILE).writeText(JSONObject().put("m", arr).put("s", s.summary).put("f", s.folded).toString())
        } catch (_: Exception) {}
    }

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, FILE).delete() } catch (_: Exception) {}
        try { audioDir(ctx).listFiles()?.forEach { it.delete() } } catch (_: Exception) {}
    }

    private fun asCtx(m: ZaraMsg) = JSONObject().put("role", m.role).put("content", m.text)

    /**
     * Builds what is sent to the server: the last [WINDOW] messages, the stored summary, and any older messages
     * that have not been folded into the summary yet. [exceptLast] leaves out the voice note being sent (the server adds its transcript).
     */
    fun buildRequest(s: Saved, exceptLast: Boolean): Triple<JSONArray, JSONArray, Int> {
        val usable = s.msgs.filter { !it.error && it.text.isNotBlank() }
        val list = if (exceptLast) usable.dropLast(0) else usable
        val winStart = maxOf(0, list.size - WINDOW)
        val folded = minOf(s.folded, winStart)
        val older = JSONArray(); list.subList(folded, winStart).takeLast(40).forEach { older.put(asCtx(it)) }
        val window = JSONArray(); list.subList(winStart, list.size).forEach { window.put(asCtx(it)) }
        return Triple(window, older, winStart)
    }
}

object ZaraAPI {
    /** Text (or the typed part) is already inside [window]; a voice note is sent as [audio] and transcribed by the server. */
    suspend fun chat(window: JSONArray, older: JSONArray, summary: String, audio: File?): ApiResult {
        val b = JSONObject().put("messages", window).put("summary", summary)
        if (older.length() > 0) b.put("older", older)
        if (audio != null) {
            val bytes = audio.readBytes()
            b.put("audio", JSONObject().put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("mime", "audio/mp4"))
        }
        return ApiClient.post("/ai/chat.php", b, idempotent = false)
    }
    suspend fun authorize(intentId: String, pin: String) =
        ApiClient.post("/ai/authorize.php", JSONObject().put("intent_id", intentId).put("pin", pin), idempotent = false)
    suspend fun dismiss(intentId: String) =
        ApiClient.post("/ai/dismiss.php", JSONObject().put("intent_id", intentId), idempotent = false)
}

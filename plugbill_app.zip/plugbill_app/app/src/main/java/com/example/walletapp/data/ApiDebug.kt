package com.example.walletapp.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Debug helper: when a request fails with a server/network problem, or the app crashes, the details are copied to the
 * clipboard so they can be pasted to support. Passwords/PINs/tokens are never included (request bodies are not logged).
 * Set ApiConfig.DEBUG_COPY_ERRORS = false to switch it off before a wide public launch.
 */
object ApiDebug {
    private const val PREFS = "plugbill_debug"
    private const val KEY_CRASH = "pending_crash"
    private var app: Context? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val report = header("CRASH on thread ${t.name}") + android.util.Log.getStackTraceString(e)
                ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CRASH, report).commit()
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    private fun header(label: String): String {
        val ver = try { app?.packageManager?.getPackageInfo(app!!.packageName, 0)?.versionName } catch (_: Exception) { "?" }
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        return "PlugBill debug report - $label\nApp $ver | Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | ${Build.MANUFACTURER} ${Build.MODEL} | $time\n\n"
    }

    /** Copy a failed-request report. */
    fun report(label: String, details: String) {
        if (!ApiConfig.DEBUG_COPY_ERRORS) return
        copy(header(label) + details)
    }

    /** Called when the app window gets focus: copies the crash saved by the last run (clipboard needs a focused app). */
    fun flushPendingCrash(ctx: Context) {
        if (!ApiConfig.DEBUG_COPY_ERRORS) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val crash = p.getString(KEY_CRASH, null) ?: return
        p.edit().remove(KEY_CRASH).apply()
        copy(crash)
    }

    private fun copy(text: String) {
        val c = app ?: return
        Handler(Looper.getMainLooper()).post {
            try {
                val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("PlugBill error", text.take(6000)))
                Toast.makeText(c, "Error details copied to clipboard - paste them to support", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {}
        }
    }
}

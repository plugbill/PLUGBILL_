package com.example.walletapp.ui

import androidx.compose.foundation.border
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import kotlinx.coroutines.launch
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.walletapp.services.NotificationStore

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        AppToast.error("No app found to open this link")
    }
}

@Composable
fun ProfileScreen(
    dark: Boolean,
    onDark: (Boolean) -> Unit,
    onHistory: () -> Unit,
    onFund: () -> Unit,
    onNotifications: () -> Unit,
    onExpenses: () -> Unit,
    onSecurity: () -> Unit,
    onReferral: () -> Unit,
    onAccount: () -> Unit,
    onSupport: () -> Unit,
    onLogout: () -> Unit,
    onDelete: () -> Unit = {}
) {
    val p = pal()
    val scroll = rememberScrollState()
    // same bar as the other screens (e.g. Profile details): just a centred title on frosted glass
    val headerH = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 62.u()
    FrostedBarArea(
        barHeight = headerH,
        modifier = Modifier.fillMaxSize(),
        scrollOffset = { scroll.value },
        tint = 0.35f,
        blur = 26.dp,
        bar = {
            T("Profile", 18f, FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 14.u()))
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(1.dp)
                    .background(p.divider.copy(alpha = (scroll.value / 40f).coerceIn(0f, 1f)))
            )
        }
    ) {
        Box(Modifier.fillMaxSize().elastic()) {
            Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
                ProfileList(headerH, dark, onDark, onHistory, onFund, onNotifications, onExpenses, onSecurity, onReferral, onAccount, onSupport, onLogout, onDelete)
            }
        }
    }
}

@Composable
private fun ProfileList(
    top: Dp,
    dark: Boolean,
    onDark: (Boolean) -> Unit,
    onHistory: () -> Unit,
    onFund: () -> Unit,
    onNotifications: () -> Unit,
    onExpenses: () -> Unit,
    onSecurity: () -> Unit,
    onReferral: () -> Unit,
    onAccount: () -> Unit,
    onSupport: () -> Unit,
    onLogout: () -> Unit,
    onDelete: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val p = pal()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val unread = NotificationStore.unread
    Column(Modifier.fillMaxWidth().padding(horizontal = 21.u())) {
        Spacer(Modifier.height(top + 10.u()))

        // account card: first item of the list (scrolls under the top bar). Display only.
        FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(26.u())) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.u(), vertical = 22.u()), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(68.u())
                        .softShadow(CircleShape, AppColors.Accent.copy(alpha = 0.32f), 10.u(), 0.dp, 4.u())
                        .background(Brush.linearGradient(listOf(AppColors.GreenLight, AppColors.GreenDeep)), CircleShape),
                    contentAlignment = Alignment.Center
                ) { T(Session.initial, 28f, FontWeight.Bold, Color.White) }
                Spacer(Modifier.width(16.u()))
                Column(Modifier.weight(1f)) {
                    T(Session.fullName, 17.5f, FontWeight.Bold, maxLines = 1)
                    Spacer(Modifier.height(3.u()))
                    T(Session.email.ifBlank { "No email" }, 12f, FontWeight.Normal, p.textSecondary, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(22.u()))

        SectionTitle("Account")
        Group {
            ProfileRow(AppIcons.Profile, "Profile", "Your personal details", onClick = onAccount) { Chevron() }
            ProfileRow(AppIcons.Chart, "Expenses", "Airtime, data & utility spending", onClick = onExpenses) { Chevron() }
            ProfileRow(AppIcons.Bell, "Notifications", if (unread > 0) "$unread unread" else "You're all caught up", onClick = onNotifications) { Chevron() }
            ProfileRow(AppIcons.Shield, "Security & PIN", "Passcode, fingerprint, OTP login", onClick = onSecurity) { Chevron() }
        }
        Spacer(Modifier.height(18.u()))

        SectionTitle("Preferences")
        Group {
            ProfileRow(AppIcons.Gift, "Referral & bonus", "Invite friends and earn", onClick = onReferral) { Chevron() }
            ProfileRow(AppIcons.Moon, "Dark mode", null, onClick = { onDark(!dark) }) { PBSwitch(dark) }
        }
        Spacer(Modifier.height(18.u()))

        SectionTitle("Support")
        Group {
            ProfileRow(AppIcons.Lock, "Privacy policy", null, onClick = { openUrl(ctx, "https://plugbill.linexware.net.ng/privacy-policy.html") }) { Chevron() }
            ProfileRow(AppIcons.Document, "Terms & conditions", null, onClick = { openUrl(ctx, "https://plugbill.linexware.net.ng/terms-conditions.html") }) { Chevron() }
            ProfileRow(AppIcons.Support, "Contact support", "WhatsApp, email or call", onClick = onSupport) { Chevron() }
        }
        Spacer(Modifier.height(18.u()))

        SectionTitle("Session")
        Group {
            ProfileRow(AppIcons.Logout, "Log out", null, tint = AppColors.ArrowUp, onClick = onLogout) {}
        }
        Spacer(Modifier.height(14.u()))
        T("PlugBill v2.0.0", 10.5f, FontWeight.Normal, p.textLight, Modifier.fillMaxWidth(), align = TextAlign.Center)
        Spacer(Modifier.height(120.u() + navInset))
    }
}

/** Grey label above a card group (Account, Preferences, Support...). */
@Composable
private fun SectionTitle(text: String) {
    T(text, 13f, FontWeight.Medium, pal().textSecondary, Modifier.padding(start = 6.u(), bottom = 8.u()))
}

@Composable
private fun Group(content: @Composable () -> Unit) {
    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(24.u())) {
        Column(Modifier.fillMaxWidth().padding(vertical = 4.u())) { content() }
    }
}

@Composable
private fun ProfileRow(
    icon: List<Seg>,
    label: String,
    sub: String?,
    tint: Color = Color.Unspecified,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit
) {
    val p = pal()
    val c = if (tint == Color.Unspecified) p.text else tint
    Row(
        Modifier.fillMaxWidth().pressable(0.98f, onClick).padding(horizontal = 16.u(), vertical = 10.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GreenIcon(icon, 38, 20)
        Spacer(Modifier.width(14.u()))
        Column(Modifier.weight(1f)) {
            T(label, 13.5f, FontWeight.SemiBold, c)
            if (sub != null) {
                Spacer(Modifier.height(2.u()))
                T(sub, 10.5f, FontWeight.Normal, p.textSecondary, maxLines = 1)
            }
        }
        trailing()
    }
}

@Composable
private fun Chevron() {
    SvgIcon(AppIcons.Chevron, 18.u(), pal().textSecondary, 2f)
}

// ───────────── sheet contents (rendered inside the glass bottom sheet) ─────────────

@Composable
fun ProfileDetailsScreen(onBack: () -> Unit, onDeleted: () -> Unit = {}) {
    val p = pal()
    var confirmDelete by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    val delScope = androidx.compose.runtime.rememberCoroutineScope()
    LoadingEffect(deleting)
    val scroll = rememberScrollState()
    FrostedScreen("Profile", onBack, scrollOffset = { scroll.value }) { top ->
      Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
        Spacer(Modifier.height(top))
        Column(Modifier.padding(horizontal = 21.u()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(6.u()))
            Box(
                Modifier.size(84.u())
                    .softShadow(RoundedCornerShape(28.u()), AppColors.Accent.copy(alpha = 0.35f), 14.u(), 0.dp, 6.u())
                    .background(Brush.linearGradient(listOf(AppColors.GreenLight, AppColors.GreenDeep)), RoundedCornerShape(28.u())),
                contentAlignment = Alignment.Center
            ) { T(Session.initial, 36f, FontWeight.Bold, Color.White) }
            Spacer(Modifier.height(14.u()))
            T(Session.fullName, 20f, FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.height(4.u()))
            T(Session.email.ifBlank { "No email" }, 12.5f, FontWeight.Normal, p.textSecondary, maxLines = 1)
            Spacer(Modifier.height(24.u()))
            ProfileInfoCard(AppIcons.Profile, "Full name", Session.fullName, false)
            Spacer(Modifier.height(12.u()))
            ProfileInfoCard(AppIcons.Mail, "Email address", Session.email.ifBlank { "-" }, Session.email.isNotBlank())
            Spacer(Modifier.height(12.u()))
            ProfileInfoCard(AppIcons.Phone, "Phone number", Session.phone.ifBlank { "Not added" }, Session.phone.isNotBlank())
            Spacer(Modifier.height(12.u()))
            ProfileInfoCard(AppIcons.Shield, "Account ID", Session.accountId.ifBlank { "-" }, Session.accountId.isNotBlank())
            Spacer(Modifier.height(44.u()))
            T("Delete account", 13f, FontWeight.Medium, AppColors.ArrowUp.copy(alpha = 0.85f), Modifier.pressable(0.97f) { confirmDelete = true }.padding(horizontal = 16.u(), vertical = 10.u()), underline = true)
            Spacer(Modifier.height(18.u()))
        }
      }
    }
    AppAlertDialog(
        visible = confirmDelete, title = "Delete account?",
        message = "This permanently removes your PlugBill account and wallet. This cannot be undone.",
        icon = AppIcons.Logout, tone = AlertTone.Error, primary = "Delete", onPrimary = {
            confirmDelete = false
            delScope.launch {
                deleting = true
                val r = com.example.walletapp.data.UserAPI.deleteAccount()
                deleting = false
                if (r.success) { AppToast.success(r.message); onDeleted() } else AppToast.error(r.message)
            }
        },
        secondary = "Cancel", onSecondary = { confirmDelete = false }, dismissible = true, onDismiss = { confirmDelete = false }
    )
}

/** One profile field in its own card, with an optional copy button. */
@Composable
fun ProfileInfoCard(icon: List<Seg>, label: String, value: String, copy: Boolean) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(22.u())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.u(), vertical = 14.u()), verticalAlignment = Alignment.CenterVertically) {
            GreenIcon(icon, 42, 21)
            Spacer(Modifier.width(14.u()))
            Column(Modifier.weight(1f)) {
                T(label.uppercase(), 9.5f, FontWeight.SemiBold, p.textSecondary, spacing = 0.5f)
                Spacer(Modifier.height(3.u()))
                T(value, 15f, FontWeight.Bold, maxLines = 2)
            }
            if (copy) {
                Box(
                    Modifier.size(40.u()).pressable {
                        clip.setText(AnnotatedString(value))
                        Haptics.tick(ctx)
                        AppToast.success("$label copied")
                    }.background(AppColors.Accent.copy(alpha = 0.12f), RoundedCornerShape(13.u())),
                    contentAlignment = Alignment.Center
                ) { SvgIcon(AppIcons.Copy, 18.u(), AppColors.Accent, 2f) }
            }
        }
    }
}

@Composable
fun SupportScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val scroll = rememberScrollState()
    FrostedScreen("Contact support", onBack, scrollOffset = { scroll.value }) { top ->
      Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
        Spacer(Modifier.height(top))
        Column(Modifier.padding(horizontal = 21.u())) {
            T("We reply fast, every day. Pick the way that suits you.", 12.5f, FontWeight.Normal, p.textSecondary)
            Spacer(Modifier.height(18.u()))
            SupportRow(AppIcons.Phone, "WhatsApp chat", "+234 805 123 0433") { openUrl(ctx, "https://wa.me/2348051230433") }
            SupportRow(AppIcons.Mail, "Email us", "support@plugbill.com") { openUrl(ctx, "mailto:support@plugbill.com") }
            SupportRow(AppIcons.Phone, "Call us", "+234 805 123 0433") { openUrl(ctx, "tel:+2348051230433") }
        }
      }
    }
}

@Composable
private fun SupportRow(icon: List<Seg>, title: String, sub: String, onClick: () -> Unit) {
    val p = pal()
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.u()).pressable(0.98f, onClick)
            .background(p.surface, RoundedCornerShape(20.u())).padding(14.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GreenIcon(icon, 40, 20)
        Spacer(Modifier.width(14.u()))
        Column(Modifier.weight(1f)) {
            T(title, 13.5f, FontWeight.Bold)
            T(sub, 11.5f, FontWeight.Normal, p.textSecondary)
        }
        SvgIcon(AppIcons.Chevron, 16.u(), p.textSecondary, 2f)
    }
}

@Composable
fun LogoutContent(onCancel: () -> Unit, onConfirm: () -> Unit, title: String = "Log out?", text: String = "You'll need to sign in again to use your wallet.", confirm: String = "Log out") {
    val p = pal()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        GreenIcon(AppIcons.Logout, 56, 28)
        Spacer(Modifier.height(14.u()))
        T(title, 20f, FontWeight.Bold)
        Spacer(Modifier.height(6.u()))
        T(text, 13f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center)
        Spacer(Modifier.height(20.u()))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.u())) {
            Box(
                Modifier.weight(1f).height(54.u()).pressable(0.97f, onCancel).background(p.divider.copy(alpha = 0.5f), RoundedCornerShape(18.u())),
                contentAlignment = Alignment.Center
            ) { T("Cancel", 14.5f, FontWeight.SemiBold) }
            Box(
                Modifier.weight(1f).height(54.u()).pressable(0.97f, onConfirm).background(AppColors.ArrowUp, RoundedCornerShape(18.u())),
                contentAlignment = Alignment.Center
            ) { T(confirm, 14.5f, FontWeight.SemiBold, Color.White) }
        }
    }
}

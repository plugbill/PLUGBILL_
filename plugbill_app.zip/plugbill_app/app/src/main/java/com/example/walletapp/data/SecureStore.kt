package com.example.walletapp.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Small AES-GCM store backed by the Android Keystore (no extra library, keeps the APK small).
 * Used for the session token, the cached user and the transaction PIN. Values never leave the device unencrypted.
 */
object SecureStore {
    private const val ALIAS = "plugbill_secure_key"
    private const val PREFS = "plugbill_secure"
    private lateinit var app: Context

    fun init(ctx: Context) { if (!::app.isInitialized) app = ctx.applicationContext }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return gen.generateKey()
    }

    @Synchronized fun put(name: String, value: String?) {
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (value == null) { p.edit().remove(name).apply(); return }
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val out = c.iv + c.doFinal(value.toByteArray(Charsets.UTF_8))
            p.edit().putString(name, Base64.encodeToString(out, Base64.NO_WRAP)).apply()
        } catch (_: Exception) { p.edit().remove(name).apply() }
    }

    @Synchronized fun get(name: String): String? {
        val raw = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(name, null) ?: return null
        return try {
            val b = Base64.decode(raw, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
            String(c.doFinal(b.copyOfRange(12, b.size)), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }

    fun clearAll() { if (::app.isInitialized) app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply() }
}

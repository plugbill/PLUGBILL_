package com.example.walletapp.ui

import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.horizontalScroll
import android.content.Context
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import android.content.ContextWrapper
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.example.walletapp.R

// ───────────────────────── helpers ─────────────────────────

fun Context.findActivity(): FragmentActivity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is FragmentActivity) return c
        c = c.baseContext
    }
    return null
}

object Haptics {
    private fun vib(ctx: Context): Vibrator? = ctx.getSystemService(Vibrator::class.java)
    @Suppress("DEPRECATION")
    private fun pattern(ctx: Context, timings: LongArray, amps: IntArray?) {
        val v = vib(ctx) ?: return
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val e = if (amps != null) VibrationEffect.createWaveform(timings, amps, -1) else VibrationEffect.createWaveform(timings, -1)
            v.vibrate(e)
        } else v.vibrate(timings, -1) // Android 7: VibrationEffect does not exist
    }
    @Suppress("DEPRECATION")
    fun tick(ctx: Context) {
        try {
            val v = vib(ctx) ?: return
            if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(18, 120)) else v.vibrate(18)
        } catch (_: Exception) {}
    }
    /** Little "da-dum" pattern for a successful purchase (same feel as the web app's CONFIRM haptic). */
    fun success(ctx: Context) {
        try { pattern(ctx, longArrayOf(0, 28, 70, 38, 70, 90), intArrayOf(0, 120, 0, 170, 0, 255)) } catch (_: Exception) {}
    }
    fun reject(ctx: Context) {
        try { pattern(ctx, longArrayOf(0, 60, 50, 60), null) } catch (_: Exception) {}
    }
}

/** Fingerprint / biometric prompt (ported from the web wrapper's authenticateBiometric bridge). */
object Biometrics {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK

    fun available(ctx: Context): Boolean = try {
        BiometricManager.from(ctx).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS
    } catch (_: Exception) { false }

    fun prompt(ctx: Context, title: String, subtitle: String, onResult: (Boolean) -> Unit) {
        val act = ctx.findActivity()
        if (act == null || !available(ctx)) { onResult(false); return }
        Haptics.tick(ctx)
        val prompt = BiometricPrompt(act, androidx.core.content.ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                Haptics.success(ctx); onResult(true)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                Haptics.reject(ctx); onResult(false)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title).setSubtitle(subtitle)
            .setAllowedAuthenticators(AUTH)
            .setNegativeButtonText("Cancel")
            .build()
        prompt.authenticate(info)
    }
}

// ───────────────────────── glass ─────────────────────────

/** Rounded body with a small triangle pointer under the centre (the "arrow down" of the bill pop-up). */
class BubbleShape(private val corner: Dp, private val arrowW: Dp, private val arrowH: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { corner.toPx() }
        val aw = with(density) { arrowW.toPx() }
        val ah = with(density) { arrowH.toPx() }
        val bodyH = size.height - ah
        val body = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, bodyH, CornerRadius(c, c))) }
        val arrow = Path().apply {
            moveTo(size.width / 2f - aw / 2f, bodyH - 1f)
            lineTo(size.width / 2f, size.height)
            lineTo(size.width / 2f + aw / 2f, bodyH - 1f)
            close()
        }
        val out = Path()
        out.op(body, arrow, PathOperation.Union)
        return Outline.Generic(out)
    }
}

/** iOS-style frosted glass: translucent fill + bright top edge. The backdrop blur is applied by the screen behind it. */
@Composable
fun Modifier.glass(shape: Shape, solid: Boolean = false): Modifier {
    val p = pal()
    val blurOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val fill = if (p.dark) Color(0xFF1E2029).copy(alpha = if (solid) 0.97f else if (blurOk) 0.62f else 0.93f)
    else Color.White.copy(alpha = if (solid) 0.98f else if (blurOk) 0.66f else 0.95f)
    val edge = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = if (p.dark) 0.34f else 0.95f), Color.White.copy(alpha = if (p.dark) 0.06f else 0.30f))
    )
    return this
        .softShadow(shape, Color(0x40000000), 34.u(), 0.dp, 14.u())
        .clip(shape)
        .background(fill)
        .background(Brush.verticalGradient(listOf(AppColors.Accent.copy(alpha = if (p.dark) 0.16f else 0.12f), Color.Transparent)))
        .border(1.dp, edge, shape)
}

val noRipple: Modifier @Composable get() = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}

/** Glass bottom sheet with scrim. Place inside a full-screen Box (it fills it). Drag it down (or fling) to dismiss. */
@Composable
fun GlassSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val p = pal()
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val drag = remember { androidx.compose.animation.core.Animatable(0f) }
    var sheetH by remember { mutableStateOf(1) }
    val dismissNow by androidx.compose.runtime.rememberUpdatedState(onDismiss)

    // after the sheet is gone, put the drag offset back so it opens normally next time
    androidx.compose.runtime.LaunchedEffect(visible) {
        if (!visible) { kotlinx.coroutines.delay(400); drag.snapTo(0f) }
    }

    fun settle(velocity: Float) {
        scope.launch {
            val far = drag.value > sheetH * 0.30f || velocity > 1400f
            if (far) {
                drag.animateTo(sheetH.toFloat() + 80f, tween(180))
                dismissNow()
            } else drag.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium))
        }
    }

    // lets the sheet follow the finger when its content is already at the top (or has nothing to scroll)
    val connection = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): Offset {
                if (available.y < 0f && drag.value > 0f) {
                    val d = maxOf(available.y, -drag.value)
                    scope.launch { drag.snapTo(drag.value + d) }
                    return Offset(0f, d)
                }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): Offset {
                if (available.y > 0f && source == androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput) {
                    scope.launch { drag.snapTo(drag.value + available.y) }
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }
            override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                if (drag.value > 0f) { settle(available.y); return available }
                return androidx.compose.ui.unit.Velocity.Zero
            }
        }
    }
    // the handle area always drags the sheet, even if the content is scrollable
    val handleDrag = androidx.compose.foundation.gestures.rememberDraggableState { d ->
        scope.launch { drag.snapTo((drag.value + d).coerceAtLeast(0f)) }
    }

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(220)), exit = fadeOut(tween(200))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = (1f - drag.value / sheetH.coerceAtLeast(1)).coerceIn(0f, 1f) }
                    .background(Color(if (p.dark) 0xB3000000 else 0x8C000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() }
            )
        }
        AnimatedVisibility(
            visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(230)) { it } + fadeOut(tween(160))
        ) {
            val shape = RoundedCornerShape(topStart = 32.u(), topEnd = 32.u())
            Column(
                Modifier
                    .offset { androidx.compose.ui.unit.IntOffset(0, drag.value.toInt()) }
                    .fillMaxWidth()
                    .glass(shape, solid = true)
                    .then(noRipple)
                    .navigationBarsPadding()
                    .imePadding()
                    .onSizeChanged { sheetH = it.height }
                    .nestedScroll(connection)
                    .padding(horizontal = 22.u())
                    .padding(top = 10.u(), bottom = 18.u())
                    .heightIn(max = 680.u())
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    Modifier.fillMaxWidth()
                        .draggable(handleDrag, Orientation.Vertical, onDragStopped = { settle(it) })
                        .padding(top = 4.u(), bottom = 12.u()),
                    contentAlignment = Alignment.Center
                ) { Box(Modifier.width(40.u()).height(5.u()).background(pal().divider, CircleShape)) }
                content()
            }
        }
    }
}

// ───────────────────────── components ─────────────────────────

/** Green card with a white icon; follows light/dark (deeper green in dark mode). */
@Composable
fun GreenIcon(icon: List<Seg>, tile: Number = 38, glyph: Number = 20) {
    val dark = pal().dark
    val c1 = if (dark) Color(0xFF12A56D) else AppColors.GreenLight
    val c2 = if (dark) Color(0xFF007A4C) else AppColors.Accent
    val shape = RoundedCornerShape((tile.toFloat() * 0.32f).u())
    Box(
        Modifier
            .size(tile.u())
            .softShadow(shape, c2.copy(alpha = 0.35f), 8.u(), 0.dp, 3.u())
            .background(Brush.linearGradient(listOf(c1, c2)), shape),
        contentAlignment = Alignment.Center
    ) { SvgIcon(icon, glyph.u(), Color.White, 2f) }
}

@Composable
fun PBSwitch(on: Boolean) {
    val p = pal()
    val x by animateDpAsState(if (on) 20.u() else 2.u(), tween(200), label = "knob")
    Box(Modifier.width(44.u()).height(26.u()).background(if (on) AppColors.Accent else p.divider, CircleShape)) {
        Box(
            Modifier.offset(x = x, y = 3.u()).size(20.u())
                .softShadow(CircleShape, Color(0x33000000), 4.u(), 0.dp, 1.u())
                .background(Color.White, CircleShape)
        )
    }
}

/** [blockedMessage]: shown as a drop-down error toast when the button is tapped while [enabled] is false. */
@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, loading: Boolean = false, overlay: Boolean = true, blockedMessage: String? = null, onClick: () -> Unit) {
    // loading shows the app-wide blurred logo loader; payments pass overlay = false to keep the button spinner
    LoadingEffect(loading && overlay)
    val btn = RoundedCornerShape(18.u())
    val bg = if (enabled) Brush.verticalGradient(listOf(AppColors.GreenLight, AppColors.Accent))
    else Brush.verticalGradient(listOf(pal().divider, pal().divider))
    Box(
        modifier
            .fillMaxWidth()
            .height(56.u())
            .then(
                if (enabled && !loading) Modifier.pressable(0.98f, onClick)
                else if (!enabled && !loading && blockedMessage != null) Modifier.pressable(0.98f) { AppToast.error(blockedMessage) }
                else Modifier
            )
            .softShadow(btn, if (enabled) AppColors.Accent.copy(alpha = 0.32f) else Color.Transparent, 18.u(), 0.dp, 8.u())
            .background(bg, btn),
        contentAlignment = Alignment.Center
    ) {
        if (loading && !overlay) Spinner(Color.White) else T(text, 16f, FontWeight.SemiBold, if (enabled) Color.White else pal().textSecondary)
    }
}

@Composable
fun Spinner(color: Color = AppColors.Accent, size: Number = 22) {
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "spin")
    val a by t.animateFloat(0f, 360f, androidx.compose.animation.core.infiniteRepeatable(tween(800, easing = androidx.compose.animation.core.LinearEasing)), label = "a")
    androidx.compose.foundation.Canvas(Modifier.size(size.u()).rotate(a)) {
        drawArc(color, 0f, 270f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}


@Composable
fun PBField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    maxLen: Int = 60,
    icon: List<Seg>? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val p = pal()
    var focused by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(18.u())
    val hideText = password && !show
    Row(
        modifier
            .fillMaxWidth()
            .height(56.u())
            .softShadow(shape, p.shadow, 12.u(), 0.dp, 4.u())
            .background(p.surface, shape)
            .border(1.5.dp, if (focused) AppColors.Accent else Color.Transparent, shape)
            .padding(horizontal = 16.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            SvgIcon(icon, 20.u(), if (focused) AppColors.Accent else p.textSecondary, 1.8f)
            Spacer(Modifier.width(12.u()))
        }
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) T(hint, 14f, FontWeight.Normal, p.textLight)
            BasicTextField(
                value = value,
                onValueChange = { if (it.length <= maxLen) onChange(it) },
                singleLine = true,
                textStyle = TextStyle(color = if (hideText) Color.Transparent else p.text, fontSize = 14.5f.usp(), fontWeight = FontWeight.Medium, fontFamily = AppFont),
                keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
                visualTransformation = if (hideText) PasswordVisualTransformation() else VisualTransformation.None,
                cursorBrush = SolidColor(if (hideText) Color.Transparent else AppColors.Accent),
                modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
            )
            // hidden passwords are drawn as thick animated dots instead of the system bullets
            if (hideText && (value.isNotEmpty() || focused)) PasswordDots(value.length, focused, Modifier.align(Alignment.CenterStart))
        }
        if (password) {
            Box(Modifier.pressable { show = !show }.padding(4.u())) {
                SvgIcon(if (show) AppIcons.EyeOff else AppIcons.Eye, 20.u(), p.textSecondary, 1.8f)
            }
        }
        trailing?.invoke()
    }
}

@Composable
fun FieldLabel(text: String) {
    T(text, 11.5f, FontWeight.SemiBold, pal().textSecondary, Modifier.padding(start = 4.u(), bottom = 6.u()))
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val p = pal()
    val shape = RoundedCornerShape(14.u())
    Box(
        Modifier
            .pressable(0.95f, onClick)
            .background(if (selected) AppColors.Accent else p.surface, shape)
            .border(1.dp, if (selected) AppColors.Accent else p.divider.copy(alpha = 0.6f), shape)
            .padding(horizontal = 14.u(), vertical = 9.u()),
        contentAlignment = Alignment.Center
    ) { T(text, 12.5f, FontWeight.SemiBold, if (selected) Color.White else p.text, maxLines = 1) }
}

/** Looping-once green success animation (the same JSON the web app uses). */
@Composable
fun SuccessLottie(size: Number = 130) {
    val comp by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.success_anim))
    val prog by animateLottieCompositionAsState(comp, iterations = 1)
    LottieAnimation(composition = comp, progress = { prog }, modifier = Modifier.size(size.u()))
}

@Composable
fun BackRow(title: String, onBack: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    val p = pal()
    Row(
        Modifier.fillMaxWidth().padding(start = 21.u(), end = 21.u(), top = 20.u(), bottom = 14.u()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FloatSurface(Modifier.size(52.u()), RoundedCornerShape(18.u()), onBack) { SvgIcon(AppIcons.Back, 22.u(), p.text, 2f) }
        Spacer(Modifier.width(14.u()))
        Box(Modifier.weight(1f)) { T(title, 20f, FontWeight.Bold) }
        trailing?.invoke()
    }
}


@Composable
private fun PasswordDots(count: Int, focused: Boolean, modifier: Modifier = Modifier) {
    val scroll = rememberScrollState()
    androidx.compose.runtime.LaunchedEffect(count) { scroll.animateScrollTo(scroll.maxValue) }
    Row(modifier.fillMaxWidth().horizontalScroll(scroll, enabled = false), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { i -> androidx.compose.runtime.key(i) { PasswordDot() } }
        if (focused) {
            val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "caret")
            val a by t.animateFloat(
                1f, 0f,
                androidx.compose.animation.core.infiniteRepeatable(tween(520), androidx.compose.animation.core.RepeatMode.Reverse),
                label = "caretA"
            )
            Box(Modifier.width(2.u()).height(20.u()).alpha(a).background(AppColors.Accent, CircleShape))
        }
    }
}

/** One thick dot: pops in with a spring, starts green and settles to the text colour. */
@Composable
private fun PasswordDot() {
    val p = pal()
    var on by remember { mutableStateOf(false) }
    var settled by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(Unit) { on = true; kotlinx.coroutines.delay(380); settled = true }
    val s by androidx.compose.animation.core.animateFloatAsState(
        if (on) 1f else 0f, spring(dampingRatio = 0.38f, stiffness = Spring.StiffnessMedium), label = "dotS"
    )
    val c by androidx.compose.animation.animateColorAsState(if (settled) p.text else AppColors.Accent, tween(320), label = "dotC")
    Box(Modifier.padding(end = 7.u()).size(12.u()).scale(s).background(c, CircleShape))
}

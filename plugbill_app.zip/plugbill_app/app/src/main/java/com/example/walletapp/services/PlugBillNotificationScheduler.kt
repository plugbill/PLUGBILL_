package com.example.walletapp.services

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object PlugBillNotificationScheduler {

    private const val TAG = "PlugBillScheduler"
    private const val WORK_ENGAGEMENT_TAG = "plugbill_engagement_work"

    fun scheduleAll(context: Context) {
        try {
            scheduleWorkManagerEngagement(context)
            scheduleAlarmManagerNotifications(context)
            Log.d(TAG, "All background engagement notifications scheduled successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Error scheduling notifications", e)
        }
    }

    private fun scheduleWorkManagerEngagement(context: Context) {
        try {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build()

            // Periodically trigger engagement checks every 12 hours
            val periodicWorkRequest = PeriodicWorkRequestBuilder<PlugBillLocalNotificationWorker>(
                12, TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .addTag(WORK_ENGAGEMENT_TAG)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_ENGAGEMENT_TAG,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWorkRequest
            )
            Log.d(TAG, "WorkManager engagement worker enqueued.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enqueue WorkManager engagement worker", e)
        }
    }

    private fun scheduleAlarmManagerNotifications(context: Context) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            val notificationTypes = arrayOf("discount", "fast_topup", "cashback")
            val delaysInHours = longArrayOf(6, 24, 48)

            for (i in notificationTypes.indices) {
                val intent = Intent(context, PlugBillAlarmReceiver::class.java).apply {
                    action = "com.plugbill.ACTION_LOCAL_ENGAGEMENT_NOTIFICATION"
                    putExtra("notification_type", notificationTypes[i])
                    putExtra("notification_index", i)
                }

                val requestCode = 1000 + i
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val triggerAtMillis = System.currentTimeMillis() + (delaysInHours[i] * 60 * 60 * 1000)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try {
                        alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMillis,
                            pendingIntent
                        )
                    } catch (_: SecurityException) {
                        alarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMillis,
                            pendingIntent
                        )
                    }
                } else {
                    alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                }
            }
            Log.d(TAG, "AlarmManager local engagement alarms registered.")
        } catch (e: Exception) {
            Log.e(TAG, "Error registering AlarmManager alarms", e)
        }
    }
}

package com.example.walletapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp

/** Logo: two folded ribbon pieces forming a left-pointing chevron. */
@Composable
fun AppLogo(modifier: Modifier = Modifier, size: Number = 44) {
    androidx.compose.foundation.Image(
        painter = androidx.compose.ui.res.painterResource(com.example.walletapp.R.drawable.plugbill_logo),
        contentDescription = "PlugBill",
        modifier = modifier.size(size.u())
    )
}

/** Rounded gradient tile with a white icon (quick actions, bill menu). */
@Composable
fun ActionIcon(c1: Color, c2: Color, icon: List<Seg>, tile: Float = 32f, glyph: Float = 18f) {
    val shape = RoundedCornerShape((tile * 0.3f).u())
    Box(
        Modifier
            .size(tile.u())
            .softShadow(shape, c2.copy(alpha = 0.4f), 8.u(), 0.dp, 2.u())
            .background(Brush.linearGradient(listOf(c1, c2)), shape),
        contentAlignment = Alignment.Center
    ) {
        SvgIcon(icon, glyph.u(), Color.White, 2f)
    }
}

/** Illustrated profile photo placeholder: young man, dark hair, glasses, maroon sweater. */
@Composable
fun AvatarIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF8A6A5C), Color(0xFF4A3A36))))
        drawOval(Color(0xFF7A1F2B), Offset(w * 0.06f, h * 0.68f), Size(w * 0.88f, h * 0.62f))
        drawRoundRect(Color(0xFFC98E6F), Offset(w * 0.42f, h * 0.55f), Size(w * 0.16f, h * 0.2f))
        drawOval(Color(0xFFE0AC8C), Offset(w * 0.30f, h * 0.22f), Size(w * 0.40f, h * 0.46f))
        drawArc(Color(0xFF1E1614), 180f, 180f, true, Offset(w * 0.28f, h * 0.17f), Size(w * 0.44f, h * 0.34f))
        val glass = Color(0xFF222222)
        val gw = w * 0.022f
        drawCircle(glass, w * 0.075f, Offset(w * 0.42f, h * 0.46f), style = Stroke(gw))
        drawCircle(glass, w * 0.075f, Offset(w * 0.58f, h * 0.46f), style = Stroke(gw))
        drawLine(glass, Offset(w * 0.495f, h * 0.46f), Offset(w * 0.505f, h * 0.46f), strokeWidth = gw)
        drawLine(Color(0xFF9B5F4A), Offset(w * 0.45f, h * 0.60f), Offset(w * 0.55f, h * 0.60f), strokeWidth = gw, cap = StrokeCap.Round)
    }
}

package com.example.walletapp.ui

import com.example.walletapp.data.SocialAPI
import com.example.walletapp.data.WalletAPI
import com.example.walletapp.data.dbl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.blur
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.walletapp.services.AppNotification
import com.example.walletapp.services.NotificationStore
import com.example.walletapp.services.PlugBillNotificationHelper

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60_000
    return when {
        m < 1 -> "Just now"
        m < 60 -> "${m}m ago"
        m < 1440 -> "${m / 60}h ago"
        else -> "${m / 1440}d ago"
    }
}

// ───────────── Notifications (web: NotificationScreen) ─────────────

@Composable
fun NotificationsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    var filter by remember { mutableStateOf("All") }
    androidx.compose.runtime.LaunchedEffect(Unit) { try { com.example.walletapp.data.Sync.pullNotifications(ctx) } catch (_: Exception) {} }
    val all = NotificationStore.items
    val list = all.filter {
        when (filter) {
            "Unread" -> !it.read
            "Security" -> it.type == "security"
            "Updates" -> it.type != "security"
            else -> true
        }
    }
    var sel by remember { mutableStateOf<AppNotification?>(null) }
    var shown by remember { mutableStateOf<AppNotification?>(null) }
    if (sel != null) shown = sel
    androidx.activity.compose.BackHandler(enabled = sel != null) { sel = null }
    val blurR by androidx.compose.animation.core.animateDpAsState(
        if (sel != null && android.os.Build.VERSION.SDK_INT >= 31) 24.dp else 0.dp, androidx.compose.animation.core.tween(260), label = "nBlur"
    )
    val lazy = androidx.compose.foundation.lazy.rememberLazyListState()
    Box(Modifier.fillMaxSize().background(screenBackground())) {
    Box(Modifier.fillMaxSize().blur(blurR)) {
    FrostedScreen(
        "Notifications", onBack,
        scrollOffset = { lazy.firstVisibleItemIndex * 100000 + lazy.firstVisibleItemScrollOffset },
        trailing = { T("Mark all read", 12f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable { NotificationStore.markAllRead(ctx); CoroutineScope(Dispatchers.IO).launch { try { SocialAPI.markNotificationsRead(null) } catch (_: Exception) {} } }) }
    ) { top ->
        val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        LazyColumn(
            Modifier.fillMaxSize(),
            state = lazy,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 21.u(), end = 21.u(), top = top + 4.u(), bottom = 16.u() + navInset),
            verticalArrangement = Arrangement.spacedBy(12.u())
        ) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.u())) {
                    listOf("All", "Unread", "Updates", "Security").forEach { f -> Chip(f, filter == f) { filter = f } }
                }
            }
            if (list.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(top = 60.u()), contentAlignment = Alignment.Center) {
                        T("No notifications here", 13f, FontWeight.Medium, p.textSecondary)
                    }
                }
            } else {
                items(list, key = { it.id }) { n -> NotifRow(n) { NotificationStore.markRead(ctx, n.id); if (n.id.startsWith("srv_")) CoroutineScope(Dispatchers.IO).launch { try { SocialAPI.markNotificationsRead(n.id.removePrefix("srv_")) } catch (_: Exception) {} }; sel = n } }
            }
        }
    }
    }
    GlassSheet(visible = sel != null, onDismiss = { sel = null }) {
        shown?.let { NotifDetail(it) { sel = null } }
    }
    }
}

@Composable
private fun NotifDetail(n: AppNotification, onClose: () -> Unit) {
    val p = pal()
    val icon = when (n.type) { "wallet" -> AppIcons.WalletIn; "security" -> AppIcons.Shield; "services" -> AppIcons.Bills; else -> AppIcons.Bell }
    val label = when (n.type) { "wallet" -> "Wallet"; "security" -> "Security"; "services" -> "Services"; else -> "General" }
    val whenText = java.text.SimpleDateFormat("d MMM yyyy \u2022 h:mm a", java.util.Locale.getDefault()).format(java.util.Date(n.time))
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        GreenIcon(icon, 56, 28)
        if (!n.imageUrl.isNullOrBlank()) { Spacer(Modifier.height(14.u())); NotifBanner(n.imageUrl, Modifier.fillMaxWidth().height(150.u())) }
        Spacer(Modifier.height(12.u()))
        Box(Modifier.background(AppColors.Accent.copy(alpha = 0.14f), RoundedCornerShape(50)).padding(horizontal = 12.u(), vertical = 4.u())) {
            T(label, 11f, FontWeight.Bold, AppColors.Accent)
        }
        Spacer(Modifier.height(12.u()))
        T(n.title, 19f, FontWeight.Bold, align = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(6.u()))
        T(whenText, 11.5f, FontWeight.Medium, p.textLight)
        Spacer(Modifier.height(16.u()))
        Column(Modifier.fillMaxWidth().background(p.surface.copy(alpha = 0.95f), RoundedCornerShape(18.u())).padding(16.u())) {
            T(n.body, 14f, FontWeight.Normal, p.text, lineHeight = 14f * 1.5f)
        }
        Spacer(Modifier.height(18.u()))
        PrimaryButton("Close", onClick = onClose)
    }
}

@Composable
private fun NotifRow(n: AppNotification, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val icon = when (n.type) { "wallet" -> AppIcons.WalletIn; "security" -> AppIcons.Shield; "services" -> AppIcons.Bills; else -> AppIcons.Bell }
    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(20.u()), onOpen) {
        Row(Modifier.padding(14.u()), verticalAlignment = Alignment.Top) {
            GreenIcon(icon, 40, 20)
            Spacer(Modifier.width(12.u()))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(n.title, 13f, FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                    if (!n.read) {
                        Spacer(Modifier.width(6.u()))
                        Box(Modifier.size(8.u()).background(AppColors.Accent, CircleShape))
                    }
                }
                if (!n.imageUrl.isNullOrBlank()) { Spacer(Modifier.height(8.u())); NotifBanner(n.imageUrl, Modifier.fillMaxWidth().height(110.u())) }
                Spacer(Modifier.height(3.u()))
                T(n.body, 12f, FontWeight.Normal, p.textSecondary, lineHeight = 16.5f)
                Spacer(Modifier.height(6.u()))
                T(ago(n.time), 10.5f, FontWeight.Medium, p.textLight)
            }
            Box(Modifier.size(28.u()).pressable { NotificationStore.remove(ctx, n.id); if (n.id.startsWith("srv_")) CoroutineScope(Dispatchers.IO).launch { try { SocialAPI.deleteNotification(n.id.removePrefix("srv_")) } catch (_: Exception) {} } }, contentAlignment = Alignment.Center) {
                SvgIcon(AppIcons.Close, 14.u(), p.textLight, 2.2f)
            }
        }
    }
}

// ───────────── Expenses (web: ExpensesScreen) ─────────────

@Composable
fun ExpensesScreen(onBack: () -> Unit) {
    val p = pal()
    val ctx = LocalContext.current
    var exp by remember { mutableStateOf(mapOf<String, Double>()) }
    var loaded by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (Network.isOnline(ctx)) {
            val r = WalletAPI.getExpenses()
            if (r.success) r.obj?.let { o -> exp = mapOf("airtime" to o.dbl("airtime"), "data" to o.dbl("data"), "cable_tv" to o.dbl("cable_tv"), "electricity" to o.dbl("electricity")) }
            else AppToast.error(r.message)
        } else AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK)
        loaded = true
    }
    fun keyOf(k: Kind) = when (k) { Kind.Airtime -> "airtime"; Kind.Data -> "data"; Kind.Tv -> "cable_tv"; Kind.Electricity -> "electricity"; else -> "" }
    val total = exp.values.sum()
    val cats = listOf(
        Triple("Airtime recharges", Kind.Airtime, AppIcons.Airtime),
        Triple("Data bundles", Kind.Data, AppIcons.Data),
        Triple("Cable TV", Kind.Tv, AppIcons.Tv),
        Triple("Electricity bills", Kind.Electricity, AppIcons.Electricity)
    )
    val scroll = rememberScrollState()
    FrostedScreen("Expenses", onBack, scrollOffset = { scroll.value }) { top ->
      Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
        Spacer(Modifier.height(top))
        Column(Modifier.padding(horizontal = 21.u())) {
            Spacer(Modifier.height(4.u()))
            if (!loaded) {
                repeat(cats.size) { ExpenseSkeleton() }
            }
            if (loaded) cats.forEachIndexed { idx, (label, kind, icon) ->
                val sum = exp[keyOf(kind)] ?: 0.0
                val share = if (total > 0) (sum / total).toFloat() else 0f
                DropIn(idx) {
                FloatSurface(Modifier.fillMaxWidth().padding(bottom = 12.u()), RoundedCornerShape(20.u())) {
                    Column(Modifier.padding(16.u())) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GreenIcon(icon, 40, 20)
                            Spacer(Modifier.width(12.u()))
                            Column(Modifier.weight(1f)) {
                                T(label, 13.5f, FontWeight.Bold)
                                T("${(share * 100).toInt()}% of spending", 10.5f, FontWeight.Normal, p.textSecondary)
                            }
                            T(naira(sum), 13f, FontWeight.Bold)
                        }
                        Spacer(Modifier.height(12.u()))
                        Box(Modifier.fillMaxWidth().height(6.u()).background(p.divider.copy(alpha = 0.6f), CircleShape)) {
                            Box(Modifier.fillMaxWidth(share.coerceIn(0f, 1f)).height(6.u()).background(AppColors.Accent, CircleShape))
                        }
                    }
                }
                }
            }
            Spacer(Modifier.height(24.u()))
        }
      }
    }
}

@Composable
private fun ExpenseSkeleton() {
    FloatSurface(Modifier.fillMaxWidth().padding(bottom = 12.u()), RoundedCornerShape(20.u())) {
        Column(Modifier.padding(16.u())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.u()).shimmer(RoundedCornerShape(12.u())))
                Spacer(Modifier.width(12.u()))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.width(120.u()).height(12.u()).shimmer())
                    Spacer(Modifier.height(7.u()))
                    Box(Modifier.width(80.u()).height(9.u()).shimmer())
                }
                Box(Modifier.width(56.u()).height(13.u()).shimmer())
            }
            Spacer(Modifier.height(12.u()))
            Box(Modifier.fillMaxWidth().height(6.u()).shimmer(CircleShape))
        }
    }
}

// ───────────── Referral (web: ReferralScreen) ─────────────

@Composable
fun ReferralScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    var bonus by remember { mutableStateOf(Session.bonusBalance) }
    var friends by remember { mutableStateOf(0) }
    var code by remember { mutableStateOf(Session.referralCode) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (Network.isOnline(ctx)) {
            val r = SocialAPI.getReferrals()
            if (r.success) r.obj?.let { o ->
                bonus = o.dbl("bonusBalance", bonus); friends = o.optInt("totalReferrals", 0)
                o.optString("referralCode").takeIf { it.isNotBlank() && it != "null" }?.let { code = it }
            }
        }
    }
    val scroll = rememberScrollState()
    FrostedScreen("Referral & Bonus", onBack, scrollOffset = { scroll.value }) { top ->
      Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
        Spacer(Modifier.height(top))
        Column(Modifier.padding(horizontal = 21.u()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(10.u()))
            GreenIcon(AppIcons.Gift, 84, 44)
            Spacer(Modifier.height(18.u()))
            T("Invite friends, earn bonuses", 20f, FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(6.u()))
            T("Share your code. You both get a bonus on their first purchase.", 13f, FontWeight.Normal, p.textSecondary, align = TextAlign.Center, lineHeight = 18f)
            Spacer(Modifier.height(24.u()))
            FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(22.u())) {
                Row(Modifier.padding(horizontal = 18.u(), vertical = 16.u()), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T("YOUR CODE", 9.5f, FontWeight.SemiBold, p.textSecondary, spacing = 0.5f)
                        Spacer(Modifier.height(3.u()))
                        T(code, 22f, FontWeight.Bold, AppColors.Accent, spacing = 2f)
                    }
                    Box(
                        Modifier.size(42.u()).pressable {
                            clip.setText(AnnotatedString(code)); AppToast.success("Code copied")
                        }.background(AppColors.Accent.copy(alpha = 0.12f), RoundedCornerShape(14.u())),
                        contentAlignment = Alignment.Center
                    ) { SvgIcon(AppIcons.Copy, 20.u(), AppColors.Accent, 2f) }
                }
            }
            Spacer(Modifier.height(12.u()))
            FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(22.u())) {
                Row(Modifier.padding(18.u()), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T("Bonus earned", 11.5f, FontWeight.Medium, p.textSecondary)
                        T(naira(bonus), 18f, FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        T("Friends joined", 11.5f, FontWeight.Medium, p.textSecondary)
                        T(friends.toString(), 18f, FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(24.u()))
            if (bonus > 0) {
                var claiming by remember { mutableStateOf(false) }
                PrimaryButton("Claim bonus to wallet", loading = claiming) {
                    if (claiming) return@PrimaryButton
                    claiming = true
                    CoroutineScope(Dispatchers.Main).launch {
                        val r = SocialAPI.claimReferralBonus()
                        claiming = false
                        if (r.success) { AppToast.success(r.message); bonus = 0.0; com.example.walletapp.data.Sync.refresh(ctx) } else AppToast.error(r.message)
                    }
                }
                Spacer(Modifier.height(12.u()))
            }
            PrimaryButton("Share my code") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Join me on PlugBill - cheap airtime, data, electricity & TV. Use my code $code when you sign up.")
                }
                ctx.startActivity(Intent.createChooser(send, "Share code"))
            }
            Spacer(Modifier.height(24.u()))
        }
      }
    }
}

// ───────────── Security & PIN (web: PinManagementScreen) ─────────────

private fun pushFlag(key: String, v: Int) {
    CoroutineScope(Dispatchers.IO).launch { try { com.example.walletapp.data.UserAPI.updateProfile(org.json.JSONObject().put(key, v)) } catch (_: Exception) {} }
}

@Composable
fun SecurityScreen(onBack: () -> Unit, onSetPasscode: () -> Unit) {
    val ctx = LocalContext.current
    val p = pal()
    val bioAvail = remember { Biometrics.available(ctx) }
    var flow by remember { mutableStateOf<String?>(null) }   // null | "pin" | "passcode"
    var verified by remember { mutableStateOf(false) }
    androidx.activity.compose.BackHandler(enabled = flow != null) { flow = null; verified = false }
    val blurR by androidx.compose.animation.core.animateDpAsState(
        if (flow != null && android.os.Build.VERSION.SDK_INT >= 31) 24.dp else 0.dp, androidx.compose.animation.core.tween(260), label = "secBlur"
    )
    androidx.compose.runtime.LaunchedEffect(verified, flow) {
        if (verified && flow == "passcode") { flow = null; verified = false; onSetPasscode() }
    }
    val card = RoundedCornerShape(22.u())
    val scroll = rememberScrollState()
    Box(Modifier.fillMaxSize().background(screenBackground())) {
      Box(Modifier.fillMaxSize().blur(blurR)) {
        FrostedScreen("Security & PIN", onBack, scrollOffset = { scroll.value }) { top ->
          Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
            Spacer(Modifier.height(top))
            Column(Modifier.padding(horizontal = 21.u())) {
                FloatSurface(Modifier.fillMaxWidth(), card) {
                    SecRow(
                        AppIcons.Key, if (Session.hasPayPin) "Change transaction PIN" else "Set transaction PIN",
                        if (Session.hasPayPin) "Verify with your PIN or account password" else "Authorizes every purchase",
                        onClick = { verified = !Session.hasPayPin; flow = "pin" }
                    ) { SvgIcon(AppIcons.Chevron, 18.u(), p.textSecondary, 2f) }
                }
                Spacer(Modifier.height(12.u()))
                FloatSurface(Modifier.fillMaxWidth(), card) {
                    SecRow(
                        AppIcons.Lock, if (Session.hasPasscode) "Change login passcode" else "Set login passcode",
                        if (Session.hasPasscode) "Verify with your passcode or account password" else "Create a 4-digit passcode",
                        onClick = { if (Session.hasPasscode) { verified = false; flow = "passcode" } else onSetPasscode() }
                    ) { SvgIcon(AppIcons.Chevron, 18.u(), p.textSecondary, 2f) }
                }
                Spacer(Modifier.height(12.u()))
                FloatSurface(Modifier.fillMaxWidth(), card) {
                    SecRow(
                        AppIcons.Shield, "Passcode on startup", "Ask for passcode when the app opens",
                        onClick = {
                            if (!Session.hasPasscode) AppToast.warning("Set a 4-digit passcode first")
                            else {
                                Session.passcodeEnabled = !Session.passcodeEnabled; Session.save(ctx)
                                val st = if (Session.passcodeEnabled) "active" else "inactive"
                                CoroutineScope(Dispatchers.IO).launch { try { com.example.walletapp.data.UserAPI.setPasscodeStatus(st, Session.email, Session.accountId) } catch (_: Exception) {} }
                            }
                        }
                    ) { PBSwitch(Session.passcodeEnabled && Session.hasPasscode) }
                }
                Spacer(Modifier.height(12.u()))
                FloatSurface(Modifier.fillMaxWidth(), card) {
                    SecRow(
                        AppIcons.Fingerprint, "Fingerprint",
                        if (bioAvail) "Unlock the app and confirm payments" else "Not available on this device",
                        onClick = {
                            if (!bioAvail) { AppToast.warning("No fingerprint enrolled on this device") }
                            else if (Session.biometricEnabled) { Session.biometricEnabled = false; Session.save(ctx); pushFlag("biometric_enabled", 0) }
                            else Biometrics.prompt(ctx, "Enable fingerprint", "Touch the sensor to confirm") { ok ->
                                if (ok) { Session.biometricEnabled = true; Session.save(ctx); pushFlag("biometric_enabled", 1) }
                            }
                        }
                    ) { PBSwitch(Session.biometricEnabled && bioAvail) }
                }
                Spacer(Modifier.height(12.u()))
                FloatSurface(Modifier.fillMaxWidth(), card) {
                    SecRow(
                        AppIcons.Key, "OTP on every login", if (Session.twoFactor) "OTP code required on every login" else "Direct password login enabled",
                        onClick = { Session.twoFactor = !Session.twoFactor; Session.save(ctx); pushFlag("two_factor_enabled", if (Session.twoFactor) 1 else 0) }
                    ) { PBSwitch(Session.twoFactor) }
                }
                Spacer(Modifier.height(14.u()))
                T(
                    "Your transaction PIN, passcode and fingerprint never leave your phone.",
                    11.5f, FontWeight.Normal, p.textSecondary, lineHeight = 16f
                )
                Spacer(Modifier.height(24.u()))
            }
          }
        }
      }
        when {
            flow != null && !verified -> VerifyCodeSheet(flow!!, onVerified = { verified = true }, onCancel = { flow = null; verified = false })
            flow == "pin" && verified -> CreatePinSheet(
                onDone = { flow = null; verified = false; AppToast.success("Transaction PIN saved") },
                onDismiss = { flow = null; verified = false }
            )
        }
    }
}

@Composable
private fun SecRow(icon: List<Seg>, title: String, sub: String, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    val p = pal()
    Row(Modifier.fillMaxWidth().pressable(0.98f, onClick).padding(horizontal = 16.u(), vertical = 12.u()), verticalAlignment = Alignment.CenterVertically) {
        GreenIcon(icon, 38, 20)
        Spacer(Modifier.width(14.u()))
        Column(Modifier.weight(1f)) {
            T(title, 13.5f, FontWeight.SemiBold)
            Spacer(Modifier.height(2.u()))
            T(sub, 10.5f, FontWeight.Normal, p.textSecondary, lineHeight = 14f)
        }
        Spacer(Modifier.width(8.u()))
        trailing()
    }
}

/** Banner image sent with a server notification. Loads quietly; shows nothing if it can't be fetched. */
@Composable
private fun NotifBanner(url: String, modifier: Modifier) {
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, url) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val c = java.net.URL(url.trim()).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
            } catch (_: Exception) { null }
        }
    }
    val shape = RoundedCornerShape(16.u())
    val b = bmp
    if (b != null) {
        androidx.compose.foundation.Image(
            bitmap = b.asImageBitmap(), contentDescription = null, modifier = modifier.clip(shape),
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
    } else Box(modifier.clip(shape).shimmer(shape))
}

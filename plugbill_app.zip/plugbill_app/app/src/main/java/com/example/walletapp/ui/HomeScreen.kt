package com.example.walletapp.ui

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import android.widget.Toast
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.walletapp.services.NotificationStore

@Composable
fun HomeScreen(onFund: () -> Unit, onHistory: () -> Unit, onNotifications: () -> Unit, onLock: () -> Unit) {
    val ctx = LocalContext.current
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val p = pal()

    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val holdPx = with(density) { 72.u().toPx() }
    val maxPx = with(density) { 150.u().toPx() }
    val pull = remember(holdPx, maxPx) {
        PullState(holdPx, maxPx, scope, onTick = { Haptics.tick(ctx) }, onRefresh = {
            if (Network.isOnline(ctx)) com.example.walletapp.data.Sync.refresh(ctx) else AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK)
            Haptics.success(ctx)
        })
    }

    val lazy = rememberLazyListState()
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    // the whole top of the dashboard (top bar, balance, quick actions, "Last Transactions") is ONE frosted glass:
    // transactions slide under it and get blurred, and the glass fades out softly below the title row
    val fade = 12.u()
    var topPx by remember { mutableIntStateOf(0) }
    val topH = with(density) { topPx.toDp() }
    val barH = if (topPx == 0) 330.u() else topH

    Box(Modifier.fillMaxSize().nestedScroll(pull.connection)) {
        FrostedBarArea(
            barHeight = barH,
            modifier = Modifier.fillMaxSize(),
            scrollOffset = { lazy.firstVisibleItemIndex * 100000 + lazy.firstVisibleItemScrollOffset },
            tint = 0.34f,
            blur = 40.dp,
            fadeBottom = fade,
            bar = {
                Column(
                    Modifier.fillMaxWidth()
                        .wrapContentHeight(Alignment.Top, unbounded = true)
                        .onSizeChanged { topPx = it.height }
                        .draggable(rememberDraggableState { pull.drag(it) }, Orientation.Vertical, onDragStopped = { pull.release() })
                ) {
                    Spacer(Modifier.height(statusTop + 12.u()))
                    TopBar(onNotifications)
                    PullZone(pull, 18.u())
                    BalanceCard(onFund = onFund, onLock = onLock)
                    Spacer(Modifier.height(12.u()))
                    QuickActions(onFund, onHistory)
                    Spacer(Modifier.height(14.u()))
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 34.u()),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        T("Last Transactions", 14.5f, FontWeight.Bold)
                        Box(
                            Modifier.pressable(onClick = onHistory)
                                .background(AppColors.Accent.copy(alpha = 0.14f), RoundedCornerShape(50))
                                .border(1.dp, AppColors.Accent.copy(alpha = 0.30f), RoundedCornerShape(50))
                                .padding(horizontal = 13.u(), vertical = 5.u())
                        ) { T("See All", 11.5f, FontWeight.Bold, AppColors.Accent) }
                    }
                    Spacer(Modifier.height(fade))
                }
            }
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                state = lazy,
                contentPadding = PaddingValues(start = 21.u(), end = 21.u(), top = barH + 2.u(), bottom = 120.u() + navInset),
                verticalArrangement = Arrangement.spacedBy(12.u())
            ) {
                val recent = allTx.take(4)
                if (recent.isEmpty()) {
                    item {
                        FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(20.u())) {
                            T("No transactions yet", 12f, FontWeight.Medium, p.textSecondary, Modifier.padding(vertical = 24.u()))
                        }
                    }
                }
                items(recent) { tx ->
                    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(20.u())) {
                        Box(Modifier.fillMaxWidth().padding(horizontal = 16.u(), vertical = 14.u())) { TxRow(tx, p) { openReceipt(ctx, tx) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(onNotifications: () -> Unit) {
    val btn = RoundedCornerShape(18.u())
    val p = pal()
    val unread = NotificationStore.unread
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 21.u()),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.u())
                    .softShadow(CircleShape, AppColors.Accent.copy(alpha = 0.35f), 10.u(), 0.dp, 4.u())
                    .background(Brush.linearGradient(listOf(AppColors.GreenLight, AppColors.GreenDeep)), CircleShape),
                contentAlignment = Alignment.Center
            ) { T(Session.initial, 21f, FontWeight.Bold, Color.White) }
            Spacer(Modifier.width(12.u()))
            Column(Modifier.weight(1f)) {
                T("Hello, ${Session.firstName.ifBlank { "there" }}", 19f, FontWeight.Bold, maxLines = 1)
                Spacer(Modifier.height(2.u()))
                T("What would you like to pay today?", 12f, FontWeight.Normal, p.textSecondary, maxLines = 1)
            }
            Spacer(Modifier.width(10.u()))
        }
        Box(Modifier.size(52.u())) {
            FloatSurface(Modifier.size(52.u()), btn, onNotifications) {
                SvgIcon(AppIcons.Bell, 22.u(), p.text, 1.9f)
            }
            if (unread > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 2.u(), y = (-2).u()).size(16.u()).background(AppColors.ArrowUp, CircleShape),
                    contentAlignment = Alignment.Center
                ) { T(if (unread > 9) "9+" else unread.toString(), 8.5f, FontWeight.Bold, Color.White) }
            }
        }
    }
}

@Composable
private fun BalanceCard(onFund: () -> Unit, onLock: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    val shape = RoundedCornerShape(32.u())
    val number = Session.accountNumber
    Box(
        Modifier
            .padding(horizontal = 21.u())
            .fillMaxWidth()
            .softShadow(shape, AppColors.Accent.copy(alpha = if (p.dark) 0.20f else 0.34f), 30.u(), 0.dp, 14.u())
            .clip(shape)
            .background(Brush.linearGradient(listOf(AppColors.GreenDeep, AppColors.Accent, AppColors.GreenLight)))
            .border(1.dp, Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x00FFFFFF))), shape)
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.10f), size.width * 0.38f, Offset(size.width * 0.95f, size.height * 0.05f))
            drawCircle(Color.White.copy(alpha = 0.07f), size.width * 0.30f, Offset(size.width * 0.02f, size.height * 1.0f))
        }
        Column(Modifier.fillMaxWidth().padding(20.u())) {
            T("Total balance", 11.5f, FontWeight.Medium, Color(0xFFD8FFEE))
            Spacer(Modifier.height(4.u()))
            Row(verticalAlignment = Alignment.CenterVertically) {
                T(
                    if (Session.balanceHidden) "\u2022\u2022\u2022\u2022\u2022\u2022\u2022" else naira(Session.balance),
                    36f, FontWeight.Bold, Color.White, spacing = -0.5f, maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier.size(40.u()).pressable { Session.balanceHidden = !Session.balanceHidden; Session.save(ctx)
                        val hide = if (Session.balanceHidden) 1 else 0
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { try { com.example.walletapp.data.UserAPI.updateProfile(org.json.JSONObject().put("hide_balance", hide)) } catch (_: Exception) {} } }
                        .background(Color(0x26FFFFFF), RoundedCornerShape(14.u())),
                    contentAlignment = Alignment.Center
                ) { SvgIcon(if (Session.balanceHidden) AppIcons.EyeOff else AppIcons.Eye, 20.u(), Color.White, 1.9f) }
            }
            Spacer(Modifier.height(20.u()))
            Row(
                Modifier.fillMaxWidth().background(Color(0x26FFFFFF), RoundedCornerShape(20.u())).padding(start = 16.u(), end = 8.u(), top = 8.u(), bottom = 8.u()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    T("9PSB \u2022 ACCOUNT NUMBER", 9f, FontWeight.SemiBold, Color(0xFFD8FFEE), spacing = 0.4f)
                    Spacer(Modifier.height(2.u()))
                    T(number ?: "Not generated yet", 16f, FontWeight.Bold, Color.White, spacing = if (number != null) 1.5f else 0f, maxLines = 1)
                }
                Box(
                    Modifier.height(38.u()).pressable {
                        if (number != null) {
                            clip.setText(AnnotatedString(number)); Haptics.tick(ctx)
                            AppToast.success("Account number copied")
                        } else onFund()
                    }.background(Color.White, RoundedCornerShape(14.u())).padding(horizontal = 16.u()),
                    contentAlignment = Alignment.Center
                ) { T(if (number != null) "Copy" else "Generate", 12.5f, FontWeight.Bold, AppColors.Accent) }
            }
        }
    }
}

@Composable
private fun QuickActions(onFund: () -> Unit, onHistory: () -> Unit) {
    val shape = RoundedCornerShape(20.u())
    Row(Modifier.fillMaxWidth().padding(horizontal = 21.u()), horizontalArrangement = Arrangement.spacedBy(12.u())) {
        FloatSurface(Modifier.weight(1f).height(56.u()), shape, onFund) {
            Row(Modifier.padding(horizontal = 10.u()), verticalAlignment = Alignment.CenterVertically) {
                GreenIcon(AppIcons.WalletIn, 34, 19)
                Spacer(Modifier.width(8.u()))
                T("Fund Wallet", 12.5f, FontWeight.SemiBold, maxLines = 2, lineHeight = 15f)
            }
        }
        FloatSurface(Modifier.weight(1f).height(56.u()), shape, onHistory) {
            Row(Modifier.padding(horizontal = 10.u()), verticalAlignment = Alignment.CenterVertically) {
                GreenIcon(AppIcons.History, 34, 19)
                Spacer(Modifier.width(8.u()))
                T("History", 12.5f, FontWeight.SemiBold, maxLines = 2, lineHeight = 15f)
            }
        }
    }
}

@Composable
private fun TxRow(tx: Tx, p: Palette, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().pressable(0.98f, onClick), verticalAlignment = Alignment.CenterVertically) {
        TxIcon(tx, size = 52, corner = 16)
        Spacer(Modifier.width(14.u()))
        Column(Modifier.weight(1f)) {
            T(tx.title, 12.5f, FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(3.u()))
            T("${tx.shortDate}-${tx.time}", 10f, FontWeight.Normal, p.textLight, maxLines = 1)
        }
        Spacer(Modifier.width(8.u()))
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SvgIcon(
                    if (tx.incoming) AppIcons.ArrowDown else AppIcons.ArrowUp, 12.u(),
                    if (tx.incoming) AppColors.ArrowDown else AppColors.ArrowUp, 2.4f
                )
                Spacer(Modifier.width(10.u()))
                T(tx.amount, 13f, FontWeight.Bold, maxLines = 1)
            }
            Spacer(Modifier.height(2.u()))
            T("NGN", 9f, FontWeight.Normal, p.textLight)
        }
    }
}

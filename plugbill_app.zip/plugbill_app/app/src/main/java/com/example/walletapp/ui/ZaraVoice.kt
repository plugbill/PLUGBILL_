package com.example.walletapp.ui

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.walletapp.data.ZaraStore
import java.io.File

/** Records a voice note as AAC / .m4a (small, and the server's speech-to-text reads it directly). */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    val elapsedMs: Long get() = if (rec == null) 0 else System.currentTimeMillis() - startedAt

    @Suppress("DEPRECATION")
    fun start(): Boolean {
        val f = File(ZaraStore.audioDir(ctx), "vn_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare(); r.start()
            rec = r; file = f; startedAt = System.currentTimeMillis(); true
        } catch (_: Exception) {
            try { r.release() } catch (_: Exception) {}
            f.delete(); false
        }
    }

    /** 0..1 loudness for the live animation. */
    fun level(): Float = try { ((rec?.maxAmplitude ?: 0) / 12000f).coerceIn(0f, 1f) } catch (_: Exception) { 0f }

    /** Returns the file and its length, or null when too short / failed. */
    fun stop(): Pair<File, Long>? {
        val r = rec ?: return null
        val f = file
        val dur = System.currentTimeMillis() - startedAt
        rec = null; file = null
        return try {
            r.stop(); r.release()
            if (f != null && dur >= 700) f to dur else { f?.delete(); null }
        } catch (_: Exception) {
            try { r.release() } catch (_: Exception) {}
            f?.delete(); null
        }
    }

    fun cancel() {
        val r = rec ?: return
        val f = file
        rec = null; file = null
        try { r.stop() } catch (_: Exception) {}
        try { r.release() } catch (_: Exception) {}
        f?.delete()
    }
}

/** One voice note plays at a time; [progress] drives the waveform in the bubble that is playing. */
object VoicePlayer {
    var playingId by mutableStateOf<String?>(null)
    var progress by mutableStateOf(0f)
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val p = mp ?: return
            try { if (p.duration > 0) progress = p.currentPosition.toFloat() / p.duration } catch (_: Exception) {}
            h.postDelayed(this, 80)
        }
    }

    fun toggle(id: String, file: File) {
        if (playingId == id) { stop(); return }
        stop()
        try {
            val p = MediaPlayer()
            p.setDataSource(file.absolutePath)
            p.setOnCompletionListener { stop() }
            p.prepare(); p.start()
            mp = p; playingId = id; progress = 0f
            h.post(tick)
        } catch (_: Exception) { stop() }
    }

    fun stop() {
        h.removeCallbacks(tick)
        try { mp?.stop() } catch (_: Exception) {}
        try { mp?.release() } catch (_: Exception) {}
        mp = null; playingId = null; progress = 0f
    }
}

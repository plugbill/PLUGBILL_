package com.example.walletapp.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.example.walletapp.data.SocialAPI
import com.example.walletapp.data.dbl
import com.example.walletapp.data.str
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private class Ref(val name: String, val handle: String, val date: String, val rewarded: Boolean, val reward: Double)

private fun parseRefs(arr: org.json.JSONArray?): List<Ref> {
    if (arr == null) return emptyList()
    return (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val full = (o.str("first_name") + " " + o.str("last_name")).trim()
        val user = o.str("username")
        val raw = o.str("joined_at").ifBlank { o.str("created_at") }
        val date = try { LocalDateTime.parse(raw.replace(' ', 'T')).format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)) } catch (_: Exception) { raw.take(10) }
        Ref(full.ifBlank { user.ifBlank { "PlugBill user" } }, if (user.isNotBlank()) "@$user" else "", date, o.str("reward_status") == "credited", o.dbl("reward_amount"))
    }
}

@Composable
fun ReferralScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val p = pal()
    var bonus by remember { mutableStateOf(Session.bonusBalance) }
    var code by remember { mutableStateOf(Session.referralCode) }
    var total by remember { mutableStateOf(0) }
    var rewardedCount by remember { mutableStateOf(0) }
    var earned by remember { mutableStateOf(0.0) }
    var minClaim by remember { mutableStateOf(10.0) }
    var refs by remember { mutableStateOf<List<Ref>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    var claiming by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (Network.isOnline(ctx)) {
            val r = SocialAPI.getReferrals()
            if (r.success) r.obj?.let { o ->
                bonus = o.dbl("bonusBalance", bonus); total = o.optInt("totalReferrals", 0)
                rewardedCount = o.optInt("totalSuccessfulReferrals", 0); earned = o.dbl("totalEarned"); minClaim = o.dbl("minClaimAmount", 10.0)
                o.optString("referralCode").takeIf { it.isNotBlank() && it != "null" }?.let { code = it }
                refs = parseRefs(o.optJSONArray("referrals"))
            } else AppToast.error(r.message)
        } else AppToast.error(com.example.walletapp.data.ErrorText.NO_NETWORK)
        loaded = true
    }

    val canClaim = bonus >= minClaim && bonus > 0
    val scroll = rememberScrollState()
    Box(Modifier.fillMaxSize()) {
        FrostedScreen("Referral & Bonus", onBack, scrollOffset = { scroll.value }) { top ->
            Column(Modifier.fillMaxSize().navigationBarsPadding().verticalScroll(scroll)) {
                Spacer(Modifier.height(top))
                Column(Modifier.padding(horizontal = 21.u())) {
                    Spacer(Modifier.height(6.u()))

                    // ── reward + claim ──
                    val hero = RoundedCornerShape(26.u())
                    Column(
                        Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(AppColors.GreenLight, AppColors.Accent, AppColors.GreenDeep)), hero).padding(20.u())
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(40.u()).background(Color.White.copy(alpha = 0.22f), CircleShape), contentAlignment = Alignment.Center) {
                                SvgIcon(AppIcons.Gift, 22.u(), Color.White, 2f)
                            }
                            Spacer(Modifier.width(12.u()))
                            T("Referral bonus", 13f, FontWeight.SemiBold, Color.White.copy(alpha = 0.92f))
                        }
                        Spacer(Modifier.height(14.u()))
                        T(naira(bonus), 32f, FontWeight.Bold, Color.White)
                        Spacer(Modifier.height(2.u()))
                        T(
                            if (canClaim) "Ready to move to your wallet" else "Claim from ${naira(minClaim)}. Keep inviting friends",
                            12f, FontWeight.Medium, Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.height(18.u()))
                        Box(
                            Modifier.fillMaxWidth().height(52.u())
                                .background(Color.White.copy(alpha = if (canClaim) 1f else 0.32f), RoundedCornerShape(17.u()))
                                .then(
                                    if (canClaim && !claiming) Modifier.pressable(0.97f) {
                                        claiming = true
                                        CoroutineScope(Dispatchers.Main).launch {
                                            val r = SocialAPI.claimReferralBonus()
                                            claiming = false
                                            if (r.success) { AppToast.success(r.message); bonus = 0.0; Haptics.success(ctx); com.example.walletapp.data.Sync.refresh(ctx) }
                                            else AppToast.error(r.message)
                                        }
                                    } else if (!canClaim) Modifier.pressable(0.99f) { AppToast.warning("Minimum claim is ${naira(minClaim)}. Your bonus is ${naira(bonus)}.") }
                                    else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            T(
                                if (claiming) "Claiming..." else if (canClaim) "Claim ${naira(bonus)}" else "Claim bonus",
                                15f, FontWeight.Bold, if (canClaim) AppColors.GreenDeep else Color.White
                            )
                        }
                    }

                    Spacer(Modifier.height(14.u()))
                    // ── stats ──
                    Row(horizontalArrangement = Arrangement.spacedBy(10.u())) {
                        StatTile("Invited", total.toString(), Modifier.weight(1f))
                        StatTile("Rewarded", rewardedCount.toString(), Modifier.weight(1f))
                        StatTile("Total earned", naira(earned), Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(14.u()))
                    // ── code ──
                    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(22.u())) {
                        Row(Modifier.padding(horizontal = 18.u(), vertical = 14.u()), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                T("YOUR CODE", 9.5f, FontWeight.SemiBold, p.textSecondary, spacing = 0.5f)
                                Spacer(Modifier.height(3.u()))
                                T(code.ifBlank { "..." }, 22f, FontWeight.Bold, AppColors.Accent, spacing = 2f)
                            }
                            Box(
                                Modifier.size(42.u()).pressable { clip.setText(AnnotatedString(code)); AppToast.success("Code copied") }
                                    .background(AppColors.Accent.copy(alpha = 0.12f), RoundedCornerShape(14.u())),
                                contentAlignment = Alignment.Center
                            ) { SvgIcon(AppIcons.Copy, 20.u(), AppColors.Accent, 2f) }
                            Spacer(Modifier.width(8.u()))
                            Box(
                                Modifier.size(42.u()).pressable {
                                    val send = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "Join me on PlugBill - cheap airtime, data, electricity & TV. Use my code $code when you sign up.")
                                    }
                                    ctx.startActivity(Intent.createChooser(send, "Share code"))
                                }.background(AppColors.Accent.copy(alpha = 0.12f), RoundedCornerShape(14.u())),
                                contentAlignment = Alignment.Center
                            ) { SvgIcon(AppIcons.Share, 20.u(), AppColors.Accent, 2f) }
                        }
                    }

                    Spacer(Modifier.height(22.u()))
                    // ── recent referrals (3) + See more ──
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        T("People you invited", 15f, FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (loaded && refs.size > 3) T("See more", 13f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable { showAll = true }.padding(6.u()))
                    }
                    Spacer(Modifier.height(10.u()))
                    if (!loaded) {
                        Spacer(Modifier.height(1.u()))
                    } else if (refs.isEmpty()) {
                        FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(20.u())) {
                            T("No one has joined with your code yet.\nShare it and earn when they make their first purchase.", 12f, FontWeight.Medium, p.textSecondary,
                                Modifier.padding(vertical = 24.u(), horizontal = 18.u()), align = TextAlign.Center, lineHeight = 17f)
                        }
                    } else {
                        refs.take(3).forEach { RefRow(it); Spacer(Modifier.height(10.u())) }
                        if (refs.size > 3) {
                            FloatSurface(Modifier.fillMaxWidth().height(46.u()), RoundedCornerShape(16.u()), onClick = { showAll = true }) {
                                T("See all ${refs.size} referrals", 13f, FontWeight.SemiBold, AppColors.Accent)
                            }
                        }
                    }
                    Spacer(Modifier.height(28.u()))
                }
            }
        }
        GlassSheet(visible = showAll, onDismiss = { showAll = false }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("All referrals (${refs.size})", 17f, FontWeight.Bold, modifier = Modifier.weight(1f))
                T("Close", 13f, FontWeight.SemiBold, AppColors.Accent, Modifier.pressable { showAll = false }.padding(6.u()))
            }
            Spacer(Modifier.height(12.u()))
            Column(Modifier.fillMaxWidth().heightIn(max = 440.u()).verticalScroll(rememberScrollState())) {
                refs.forEach { RefRow(it, flat = true); Spacer(Modifier.height(8.u())) }
            }
            Spacer(Modifier.height(8.u()))
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    val p = pal()
    FloatSurface(modifier, RoundedCornerShape(18.u())) {
        Column(Modifier.padding(horizontal = 8.u(), vertical = 12.u()), horizontalAlignment = Alignment.CenterHorizontally) {
            T(value, 15f, FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.height(3.u()))
            T(label, 10.5f, FontWeight.Medium, p.textSecondary, maxLines = 1)
        }
    }
}

@Composable
private fun RefRow(r: Ref, flat: Boolean = false) {
    val p = pal()
    val shape = RoundedCornerShape(18.u())
    val body: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.u(), vertical = 12.u()), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.u()).background(AppColors.Accent.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
                T(r.name.firstOrNull()?.uppercase() ?: "P", 16f, FontWeight.Bold, AppColors.Accent)
            }
            Spacer(Modifier.width(12.u()))
            Column(Modifier.weight(1f)) {
                T(r.name, 13f, FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.height(3.u()))
                T("Joined ${r.date}" + if (r.handle.isNotBlank()) "  •  ${r.handle}" else "", 10.5f, FontWeight.Normal, p.textSecondary, maxLines = 1)
            }
            Spacer(Modifier.width(8.u()))
            val c = if (r.rewarded) AppColors.Accent else Color(0xFFB7791F)
            Box(Modifier.background(c.copy(alpha = 0.14f), RoundedCornerShape(10.u())).padding(horizontal = 9.u(), vertical = 5.u())) {
                T(if (r.rewarded) "+${naira(r.reward)}" else "Pending", 10.5f, FontWeight.Bold, c, maxLines = 1)
            }
        }
    }
    if (flat) Box(Modifier.fillMaxWidth().background(p.surface, shape)) { body() }
    else FloatSurface(Modifier.fillMaxWidth(), shape) { body() }
}

@Composable
private fun RefSkeleton() {
    FloatSurface(Modifier.fillMaxWidth(), RoundedCornerShape(18.u())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.u(), vertical = 12.u()), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.u()).shimmer(CircleShape))
            Spacer(Modifier.width(12.u()))
            Column(Modifier.weight(1f)) {
                Box(Modifier.width(120.u()).height(12.u()).shimmer())
                Spacer(Modifier.height(7.u()))
                Box(Modifier.width(150.u()).height(9.u()).shimmer())
            }
            Box(Modifier.width(52.u()).height(20.u()).shimmer())
        }
    }
}
